import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddVisitorComponent } from '../visitor/add-visitor/add-visitor.component';
import { ListVisitorComponent } from '../visitor/list-visitor/list-visitor.component';
import { EditVisitorComponent } from '../visitor/edit-visitor/edit-visitor.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VisitorService } from '../visitor/visitor.service';



@NgModule({
  declarations: [AddVisitorComponent,
    ListVisitorComponent,
    EditVisitorComponent],
    imports: [
      CommonModule,
      FormsModule,
      ReactiveFormsModule
    ],
    providers:[VisitorService],
    exports: [AddVisitorComponent,
      ListVisitorComponent,
      EditVisitorComponent]
})
export class VisitorModule { }
