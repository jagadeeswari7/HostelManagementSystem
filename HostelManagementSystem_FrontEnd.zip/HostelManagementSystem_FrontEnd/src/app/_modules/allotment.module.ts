import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListAllotmentComponent } from '../allotment/list-allotment/list-allotment.component';
import { EditAllotmentComponent } from '../allotment/edit-allotment/edit-allotment.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AllotmentService } from '../allotment/allotment.service';
import { AddAllotmentComponent } from '../allotment/add-allotment/add-allotment.component';
import { AllotmentListComponent } from '../warden/allotment-list/allotment-list.component';



@NgModule({
  declarations: [ListAllotmentComponent,EditAllotmentComponent,AddAllotmentComponent,
  AllotmentListComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers:[AllotmentService],
  exports: [ListAllotmentComponent,EditAllotmentComponent,AddAllotmentComponent]
})
export class AllotmentModule { }
