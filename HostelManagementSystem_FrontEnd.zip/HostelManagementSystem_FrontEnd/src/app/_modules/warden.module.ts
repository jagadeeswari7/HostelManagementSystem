import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddWardenComponent } from '../warden/add-warden/add-warden.component';
import { ListWardenComponent } from '../warden/list-warden/list-warden.component';
import { EditWardenComponent } from '../warden/edit-warden/edit-warden.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FeeService } from '../fee/fee.service';
import { ApplicationListComponent } from '../warden/application-list/application-list.component';



@NgModule({
  declarations: [AddWardenComponent,
    ListWardenComponent,
    EditWardenComponent,ApplicationListComponent],
    imports: [
      CommonModule,
      FormsModule,
      ReactiveFormsModule
    ],
    providers:[FeeService],
    exports: [AddWardenComponent,
      ListWardenComponent,
      EditWardenComponent]
})
export class WardenModule { }
