import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HostelService } from '../hostel/hostel.service';
import { AddHostelComponent } from '../hostel/add-hostel/add-hostel.component';
import { ListHostelComponent } from '../hostel/list-hostel/list-hostel.component';
import { EditHostelComponent } from '../hostel/edit-hostel/edit-hostel.component';
import { StudentHostelListComponent } from '../student/student-hostel-list/student-hostel-list.component';

@NgModule({
  declarations: [AddHostelComponent,
    ListHostelComponent,
    EditHostelComponent,StudentHostelListComponent],
    imports: [
      CommonModule,
      FormsModule,
      ReactiveFormsModule
    ],
    providers:[HostelService],
    exports: [AddHostelComponent,
      ListHostelComponent,
      EditHostelComponent]
    })
export class HostelModule { }
