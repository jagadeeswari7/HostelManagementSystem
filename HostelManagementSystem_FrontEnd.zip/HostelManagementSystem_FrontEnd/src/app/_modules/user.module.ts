import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RegisterComponent } from '../user/register/register.component';
import { UserService } from '../user/user.service';
import { ListUserComponent } from '../user/list-user/list-user.component';
import { EditUserComponent } from '../user/edit-user/edit-user.component';
import { ForgotPasswordComponent } from '../user/forgot-password/forgot-password.component';
import { ViewUserComponent } from '../user/view-user/view-user.component';


@NgModule({
  declarations: [RegisterComponent,ListUserComponent, EditUserComponent,
                 ForgotPasswordComponent, ViewUserComponent],
  imports: [
    CommonModule, 
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [UserService],
  exports:[RegisterComponent,ListUserComponent, EditUserComponent,
    ForgotPasswordComponent, ViewUserComponent]
})
export class UserModule { }
