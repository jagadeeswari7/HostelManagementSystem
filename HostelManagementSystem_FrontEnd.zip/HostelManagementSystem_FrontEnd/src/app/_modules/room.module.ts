import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddRoomComponent } from '../room/add-room/add-room.component';
import { EditRoomComponent } from '../room/edit-room/edit-room.component';
import { ListRoomComponent } from '../room/list-room/list-room.component';
import { ViewRoomComponent } from '../room/view-room/view-room.component';
import { RoomService } from '../room/room.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RoomListComponent } from '../warden/room-list/room-list.component';
import { StudentRoomListComponent } from '../student/student room fee/student-room-list/student-room-list.component';



@NgModule({
  declarations: [AddRoomComponent,
    EditRoomComponent,
    ListRoomComponent,
    ViewRoomComponent,RoomListComponent,StudentRoomListComponent
  ],
  imports: [
    CommonModule,FormsModule,ReactiveFormsModule
  ],
  providers:[RoomService],
  exports:[AddRoomComponent,
    EditRoomComponent,
    ListRoomComponent,
    ViewRoomComponent]
})
export class RoomModule { }
