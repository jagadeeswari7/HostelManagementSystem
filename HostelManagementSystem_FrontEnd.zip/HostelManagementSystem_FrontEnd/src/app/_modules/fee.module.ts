import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddFeeComponent } from '../fee/add-fee/add-fee.component';
import { EditFeeComponent } from '../fee/edit-fee/edit-fee.component';
import { ListFeeComponent } from '../fee/list-fee/list-fee.component';
import { ViewFeeComponent } from '../fee/view-fee/view-fee.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FeeService } from '../fee/fee.service';
import { FeeListComponent } from '../warden/fee-list/fee-list.component';
import { StudentFeeListComponent } from '../student/student room fee/student-fee-list/student-fee-list.component';



@NgModule({
  declarations: [StudentFeeListComponent ,AddFeeComponent, FeeListComponent ,EditFeeComponent,ListFeeComponent,ViewFeeComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers:[FeeService],
  exports: [AddFeeComponent, EditFeeComponent,ListFeeComponent,ViewFeeComponent]
})
export class FeeModule { }
