import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/user/user.service';
import { User } from 'src/app/_models/user';

@Component({
  selector: 'app-warden',
  templateUrl: './warden.component.html',
  styleUrls: ['./warden.component.css']
})
export class WardenComponent implements OnInit {
  users!: User[];

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit() {
    if(localStorage.getItem("userId")!=null){
     
    this.userService.getUsers().subscribe(data=> {
        this.users = data;
      });
    }
    else
    this.router.navigate(['/login']);
    
  }

  // logOff user
  logOutUser():void{
    if(localStorage.getItem("userId")!=null){
      localStorage.removeItem("userId");
      this.router.navigate(['/login']);
    }
}



// View User List
viewUser():void{
  this.router.navigate(['application-list']);
};

viewAllotment():void{
  this.router.navigate(['allotment-list']);
};

viewRoom():void{
  this.router.navigate(['room-list']);
};

viewFee():void{
  this.router.navigate(['fee-list']);
};

viewHostel():void{
  this.router.navigate(['hostel-list']);
};

addVisitor():void{
  this.router.navigate(['add-visitor']);
};

viewVisitor():void{
  this.router.navigate(['list-visitor']);
};

}