import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/user/user.service';
import { User } from 'src/app/_models/user';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  users!: User[];

  constructor(private router: Router, private userService: UserService,private route:ActivatedRoute) { 
  }

  ngOnInit() {
    if(localStorage.getItem("username")!=null){
     
    this.userService.getUsers().subscribe(data=> {
        this.users = data;
      });
    }
    else
    this.router.navigate(['/login']);
    
  }

  // logOff user
  logOutUser():void{
    if(localStorage.getItem("username")!=null){
      localStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
}

// View User List
viewUser():void{
  this.router.navigate(['list-user']);
};

addHostel(): void {
  this.router.navigate(['add-hostel']);
};

viewHostel():void{
  this.router.navigate(['list-hostel']);
};



viewRoom():void{
  this.router.navigate(['list-room']);
};

viewWarden():void{
  this.router.navigate(['list-warden']);
};

viewAllotment():void{
  this.router.navigate(['list-allotment']);
};

viewFee():void{
  this.router.navigate(['list-fee']);
};

}
