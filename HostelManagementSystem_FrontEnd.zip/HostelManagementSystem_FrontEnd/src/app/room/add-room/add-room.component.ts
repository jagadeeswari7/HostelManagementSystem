import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { RoomService } from '../room.service';

@Component({
  selector: 'app-add-room',
  templateUrl: './add-room.component.html',
  styleUrls: ['./add-room.component.css']
})
export class AddRoomComponent implements OnInit {

  addRoomForm: FormGroup;
  submitted: boolean = false;
  
  constructor(private formBuilder: FormBuilder, private router: Router, 
    private roomService: RoomService) {
      this.addRoomForm = this.formBuilder.group({
        roomId:['', Validators.required],
        number:['', Validators.required],
        description: ['', Validators.required]
      });
     }

  ngOnInit() {

  }

  onSubmit() {
    this.submitted = true;
    alert('Entered details');
    console.log(this.addRoomForm);
    if(this.addRoomForm.invalid){
      alert('Invalid details')
      return;
    }
    this.roomService.createRoom(this.addRoomForm.value)
      .subscribe( data => {
        this.router.navigate(['list-room']);
      });
  }

}
