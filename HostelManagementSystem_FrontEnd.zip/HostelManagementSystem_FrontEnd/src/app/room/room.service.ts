import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Room } from '../_models/room';

@Injectable({
  providedIn: 'root'
})
export class RoomService {

  constructor(private http:HttpClient) { }
  
  // for Java service
  baseUrl :string = "http://localhost:7070/rooms";

  rooms:Room[]=[];
 
  // for Json - Server uncomment following url
  //baseUrl:string = 'http://localhost:3000/rooms';

  // Create Room
  createRoom(room:Room):Observable<string>{
    return this.http.post(this.baseUrl+'/',room,{responseType :"text"});
  }

  // Get All Rooms
  getRooms():Observable<Room[]>{
    return this.http.get<Room[]>(this.baseUrl+'/Search');
  }

  // Get Room By Id
  getRoomById(roomId: number):Observable<Room>{
    return this.http.get<Room>(this.baseUrl+'/RoomId'+'/'+roomId);
  }
  
  // Modify Room user details
  updateRoom(room: Room):Observable<string>{
    return this.http.put(this.baseUrl +'/'+room.roomId, room,{responseType :"text"});
  }

  // Delete Room user details
  deleteRoom(roomId: number):Observable<string>{
    return this.http.delete(this.baseUrl +'/'+roomId,{responseType : "text"});
  }
  
  
}
