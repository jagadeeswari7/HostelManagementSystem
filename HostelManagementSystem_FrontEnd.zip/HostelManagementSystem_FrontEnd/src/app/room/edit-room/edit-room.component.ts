import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RoomService } from '../room.service';
import { Room } from 'src/app/_models/room';

@Component({
  selector: 'app-edit-room',
  templateUrl: './edit-room.component.html',
  styleUrls: ['./edit-room.component.css']
})
export class EditRoomComponent implements OnInit {

  room!: Room;
  editForm: FormGroup;
  submitted: boolean = false;
  constructor(private formBuilder: FormBuilder,private router: Router, 
    private roomService: RoomService) {
      this.editForm = this.formBuilder.group({
        roomId:['', Validators.required],
        number: ['', Validators.required],
        description: ['', Validators.required]
      });
    }
  
  ngOnInit(): void { 
    let roomId = localStorage.getItem("editRoomId");
    if(!roomId) {
      alert("Invalid action.")
      this.router.navigate(['list-room']);
      return;
    }
    
    this.roomService.getRoomById(+roomId)
      .subscribe( data => {
        this.editForm.setValue(data);
      });
  }

  onSubmit() {
    this.submitted=true;
    if(this.editForm.invalid){
      alert('invalid editform');
      return ;
    }
    this.roomService.updateRoom(this.editForm.value).subscribe(
        data => {
          this.router.navigate(['list-room']);
        },
        error => {
          alert('error: '+error.url);
        });
  }
 
}
