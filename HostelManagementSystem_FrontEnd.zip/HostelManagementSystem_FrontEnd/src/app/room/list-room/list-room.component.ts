import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Room } from 'src/app/_models/room';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-list-room',
  templateUrl: './list-room.component.html',
  styleUrls: ['./list-room.component.css']
})
export class ListRoomComponent implements OnInit {
  rooms!: Room[];

  // first one to execute and after that ngOnInit
  constructor(private router: Router, private roomService: RoomService) { 
  }

  // Initialize with default list of users
  ngOnInit() {
    this.roomService.getRooms().subscribe(data=> {
      this.rooms = data;
      });
  }

// Delete user from room
deleteRoom(room: Room): void {
    let result = confirm('Do you want to disable this room?')
     if(result)
      {
        this.roomService.deleteRoom(room.roomId)
          .subscribe( data => {
            //alert('Deleted');
          this.rooms = this.rooms.filter(r => r !== room);
          });
        }
};

//Modify User details
editRoom(room: Room): void {
  localStorage.removeItem("editRoomId");
  localStorage.setItem("editRoomId", room.roomId.toString());
  this.router.navigate(['edit-room']);
};

// Add New Room
addRoom(): void {
 this.router.navigate(['admin']);
};

viewRoom(roomId:number){
  this.router.navigate(['view-room',roomId]);
}

addAllotment():void{
  this.router.navigate(['add-allotment']);
}

}
