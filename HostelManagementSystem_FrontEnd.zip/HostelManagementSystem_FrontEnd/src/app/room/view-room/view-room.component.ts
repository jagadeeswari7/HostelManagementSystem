import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from 'src/app/_models/room';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-view-room',
  templateUrl: './view-room.component.html',
  styleUrls: ['./view-room.component.css']
})
export class ViewRoomComponent implements OnInit {

  roomId!:number;
  room!:Room;
  constructor(private route : ActivatedRoute, private service:RoomService, private router:Router) { }

  ngOnInit(){
    this.route.paramMap.subscribe(
      () =>{
        this.getRoomInfo();
      }
    )
  }
  getRoomInfo(){
    this.roomId=this.route.snapshot.params['roomId'];
    this.service.getRoomById(this.roomId).subscribe(
      data => {
        console.log(data);
        this.room=data;
      },
      error => console.log(error)
    );
  }

}
