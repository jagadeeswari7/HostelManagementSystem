import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Visitor } from '../_models/visitor';

@Injectable({
  providedIn: 'root'
})
export class VisitorService {

  constructor(private http:HttpClient) { }

  baseUrl:string='http://localhost:7070/visitor';
  
  createVisitor(visitor:Visitor)
  {
    return this.http.post(this.baseUrl+'/',visitor);
  }
  getVisitors()
  {
    return this.http.get<Visitor[]>(this.baseUrl+'/');
  }
  deleteVisitor(visitorId: number) :Observable<String> {
    return this.http.delete(this.baseUrl + '/' + visitorId,{responseType:'text'});
  }
  updateVisitor(visitor: Visitor):Observable<String> {
    return this.http.put(this.baseUrl +'/'+visitor.visitorId, visitor,{responseType:"text"});
  }
  getVisitorById(visitorId:number)
  {
    return this.http.get<Visitor>(this.baseUrl+'/Id/'+visitorId);
  }
}
