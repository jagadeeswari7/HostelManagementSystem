import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { VisitorService } from '../visitor.service';

@Component({
  selector: 'app-add-visitor',
  templateUrl: './add-visitor.component.html',
  styleUrls: ['./add-visitor.component.css']
})
export class AddVisitorComponent implements OnInit {
 
 addVisitorForm!:FormGroup;
  submitted:boolean=false;
  constructor(private formBuilder:FormBuilder,private router:Router,
    private visitorService:VisitorService) {
      this.addVisitorForm=this.formBuilder.group(
        {
         visitorId:['',Validators.required],
         name:['',Validators.required],
         contactNo:['',Validators.required],
         studentName:['',Validators.required],
         address:['',Validators.required],
         relation:['',Validators.required],
         purpose:['',Validators.required]
        }
      )
     }

  ngOnInit(){
   
  }
  onSubmit()
  {
    this.submitted=true;
    if(this.addVisitorForm.invalid)
    {
      alert('Not a valid form');
      return;
    }
    this.visitorService.createVisitor(this.addVisitorForm.value)
    .subscribe(data =>{
      alert('form is validated');
        this.router.navigate(['list-visitor']);
       // this.router.navigate(['/dashboard']);
    });
  }

}
