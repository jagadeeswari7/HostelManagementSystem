
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Visitor } from 'src/app/_models/visitor';
import { VisitorService } from '../visitor.service';

@Component({
  selector: 'app-list-visitor',
  templateUrl: './list-visitor.component.html',
  styleUrls: ['./list-visitor.component.css']
})
export class ListVisitorComponent implements OnInit {
 
  visitors!: Visitor[];
  constructor(private router:Router,private visitorService:VisitorService) { }

  ngOnInit(){
   
    {
      this.visitorService.getVisitors().subscribe(data=>
        {this.visitors=data;}
        );
    }

  }
  deleteVisitor(visitor:Visitor): void {
    let result = confirm('Do you want to delete the visitor?')
    if(result)
    {
      this.visitorService.deleteVisitor(visitor.visitorId)
        .subscribe( data => {
          this.visitors = this.visitors.filter(v => v !== visitor);
        });
      }
};
editVisitor(visitor:Visitor): void {
  localStorage.removeItem("editVisitorId");
  localStorage.setItem("editVisitorId",visitor.visitorId.toString());
  this.router.navigate(['edit-visitor']);
};
  
  addVisitor():void
  {
    this.router.navigate(['add-visitor']);
  }
  home():void{
    this.router.navigate(['dashboard']);

  }
}
