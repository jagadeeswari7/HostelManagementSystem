
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { VisitorService } from '../visitor.service';
import {first} from 'rxjs/operators';
import { Visitor } from 'src/app/_models/visitor';

@Component({
  selector: 'app-edit-visitor',
  templateUrl: './edit-visitor.component.html',
  styleUrls: ['./edit-visitor.component.css']
})
export class EditVisitorComponent implements OnInit {

  visitor!: Visitor;
  editForm!: FormGroup;
  submitted:boolean=false;
 
  constructor(private formBuilder: FormBuilder,private router: Router,
    private visitorService:VisitorService) { }

  ngOnInit() {
  // if(localStorage.getItem("name")!=null)
  let visitorId=localStorage.getItem("editVisitorId");
  if(!visitorId)
   {
     alert("invalid action.")
     this.router.navigate(['list-visitor']);
     return;
   }
    this.editForm=this.formBuilder.group(
      {
        visitorId:['',Validators.required],
        name:['',Validators.required],
       contactNo:['',Validators.required],
       studentName:['',Validators.required],
       address:['',Validators.required],
       relation:['',Validators.required],
       purpose:['',Validators.required]

      });
    this.visitorService.getVisitorById(+visitorId).subscribe(
      data => { this.editForm.setValue(data);}
    );
  }

  onSubmit()
  {
    this.submitted=true;
    if(this.editForm.invalid)
    {
      alert('invalid form');
      return;
    }
    this.visitorService.updateVisitor(this.editForm.value).pipe(first()).
    subscribe(data => 
      {this.router.navigate(['list-visitor']);},
      error =>{
        alert('error: '+error.url);
      }
      );
  }
}
