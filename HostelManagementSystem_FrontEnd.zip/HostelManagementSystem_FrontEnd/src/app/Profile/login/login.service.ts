import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from 'src/app/_models/user';
import { UserCredentials } from 'src/app/_models/usercredentials';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  
  
  constructor(private httpclient:HttpClient,private router:Router) { }

  baseUrl="http://localhost:7070/users";

  public  login(userCredentials:UserCredentials):Observable<User>{
    return this.httpclient.post<User>(this.baseUrl+'/login',userCredentials)
  }
  /*
  public forgotPassword(login:string):Observable<string>{
    return this.httpclient.post(this.baseUrl+'/forgetPassword/'+login);
  }
  */
}
