import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/_models/user';
import { LoginService } from './login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  loginForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false;
  user!:User;
  roleName!:string;

  constructor(private formBuilder: FormBuilder, private router: Router,private service:LoginService) { 
    this.loginForm = this.formBuilder.group({
      login: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit(){
    this.service.login(this.loginForm.value).subscribe(
      data => {
        this.user = data;
        let userId = this.user.userId+"";
        console.log(this.user);
        localStorage.setItem("userId",userId);
        this.roleName=this.user.roleName.toUpperCase();

        alert('check');
        console.log(this.roleName);
        if(this.roleName=="USER"){
          this.router.navigate(['/student']);
        }else{
          this.router.navigate(['/warden']);
        }
      },
      _error => {
        alert('Invalid Login');

      }
      )
      
  }

  ngOnInit() {
  }

 
}
