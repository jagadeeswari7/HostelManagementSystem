import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllotmentService } from '../allotment.service';
import {first} from 'rxjs/operators';
import { Allotment } from 'src/app/_models/allotment';



@Component({
  selector: 'app-edit-allotment',
  templateUrl: './edit-allotment.component.html',
  styleUrls: ['./edit-allotment.component.scss']
})
export class EditAllotmentComponent implements OnInit {

  allotment!: Allotment;
  editForm!: FormGroup;
  submitted: boolean = false;
  constructor(private formBuilder: FormBuilder,private router: Router, 
    private allotmentService: AllotmentService) { 
      
    }
  

    ngOnInit() {
     //if(localStorage.getItem("name")!=null){
      let allotId = localStorage.getItem("editAllotId");
      if(!allotId) {
        alert("Invalid action.")
        this.router.navigate(['list-allotment']);
        return;
      }
      this.editForm = this.formBuilder.group({
        allotId:['', Validators.required],
        hostelId:['', Validators.required],
        hostelName: ['', Validators.required],
        userId:['', Validators.required],
        name: ['', Validators.required],
   });
  
      this.allotmentService.getAllotmentById(+allotId)
        .subscribe( data => {
          this.editForm.setValue(data);
        });
      }
    
     //else
       //  this.router.navigate(['/login']);
   // }
  
    onSubmit() {
      this.submitted = true;
      if(this.editForm.invalid){
        alert('invalid editform');
        return;
      }
      this.allotmentService.updateAllotment(this.editForm.value)
        .pipe(first())
        .subscribe(
          data => {
            this.router.navigate(['list-allotment']);
          },
          error => {
            alert('error: '+error.url);
          });
    }
  
     // logOff hostel
     logOutHostel():void{
      if(localStorage.getItem("name")!=null){
        localStorage.removeItem("name");
        this.router.navigate(['/login']);
      }
  }
  
  }
