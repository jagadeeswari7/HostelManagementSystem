import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Allotment } from '../_models/allotment';

@Injectable({
  providedIn: 'root'
})
export class AllotmentService {
  constructor(private http:HttpClient) { }
  
  baseUrl:string = 'http://localhost:7070/Allotment';

  // Create Allotment
  createAllotment(allotment: Allotment):Observable<string>{
    return this.http.post(this.baseUrl, allotment,{responseType :"text"});
  }
  // Get All Allotments
  getAllotments(){
    return this.http.get<Allotment[]>(this.baseUrl+'/');
  }
  // Get Allotment By Id
  getAllotmentById(allotId: number){
    return this.http.get<Allotment>(this.baseUrl+'/AllotmentId/'+allotId);
  }
   //Delete Allotment
   deleteAllotment(allotId: number): Observable<string> {
    return this.http.delete(this.baseUrl + '/' + allotId,{responseType :"text"});
  }
  // Modify Allotment
  updateAllotment(allotment: Allotment): Observable<string> {
    return this.http.put(this.baseUrl +'/'+allotment.allotId, allotment,{responseType :"text"});
  }
  // Get Allotment By Name
  getAllotmentByName(name: string){
    return this.http.get<Allotment>(this.baseUrl+'/Name/'+name);
  }
  
  
}
