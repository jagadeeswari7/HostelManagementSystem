import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllotmentService } from '../allotment.service';


@Component({
  selector: 'app-add-allotment',
  templateUrl: './add-allotment.component.html',
  styleUrls: ['./add-allotment.component.scss']
})
export class AddAllotmentComponent implements OnInit {

  addForm!: FormGroup;
  submitted: boolean = false;


  constructor(private formBuilder: FormBuilder, private router: Router, 
    private allotmentService: AllotmentService) {
      this.addForm = this.formBuilder.group({
        allotId:['', Validators.required],
        hostelId:['', Validators.required],
        hostelName: ['', Validators.required],
        userId:['', Validators.required],
        name: ['', Validators.required],
      });
      
     }

  ngOnInit() {
   
  }

  onSubmit() {
    this.submitted = true;
    if(this.addForm.invalid){
      return;
    }
    this.allotmentService.createAllotment(this.addForm.value)
      .subscribe( data => {
        this.router.navigate(['list-allotment']);
      });
  }
}

