import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Allotment } from 'src/app/_models/allotment';
import { AllotmentService } from '../allotment.service';


@Component({
  selector: 'app-list-allotment',
  templateUrl: './list-allotment.component.html',
  styleUrls: ['./list-allotment.component.scss']
})
export class ListAllotmentComponent implements OnInit {

  allotments!: Allotment[];

  constructor(private router: Router,private allotmentService: AllotmentService) { }

  ngOnInit() {
        
    this.allotmentService.getAllotments().subscribe(data=> {
      
        this.allotments = data;
      });
   
   
  }
  
  deleteAllotment(allotment: Allotment): void {
    let result = confirm('Do you want to delete the allotment details?')
    if(result)
    {
      this.allotmentService.deleteAllotment(allotment.allotId)
        .subscribe( data => {
          this.allotments = this.allotments.filter(u => u !== allotment);
        });
      }
  };
  editAllotment(allotment: Allotment): void {
    localStorage.removeItem("editAllotId");
    localStorage.setItem("editAllotId", allotment.allotId.toString());
    this.router.navigate(['edit-allotment']);
  };
  
}