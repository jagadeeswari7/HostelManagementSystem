import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListAllotmentComponent } from './list-allotment.component';

describe('ListAllotmentComponent', () => {
  let component: ListAllotmentComponent;
  let fixture: ComponentFixture<ListAllotmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListAllotmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListAllotmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
