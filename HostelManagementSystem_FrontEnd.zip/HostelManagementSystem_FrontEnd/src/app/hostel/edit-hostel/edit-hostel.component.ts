import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Hostel } from 'src/app/_models/hostel';
import { HostelService } from '../hostel.service';

@Component({
  selector: 'app-edit-hostel',
  templateUrl: './edit-hostel.component.html',
  styleUrls: ['./edit-hostel.component.css']
})
export class EditHostelComponent implements OnInit {
  hostel!: Hostel;
  editForm!: FormGroup;
  submitted: boolean = false;
  constructor(private formBuilder: FormBuilder,private router: Router, 
    private hostelService: HostelService) { 
      
    }
  

    ngOnInit() {
     //if(localStorage.getItem("name")!=null){
      let hostelId = localStorage.getItem("editHostelId");
      if(!hostelId) {
        alert("Invalid action.")
        this.router.navigate(['list-hostel']);
        return;
      }
      this.editForm = this.formBuilder.group({
        hostelId:['', Validators.required],
        name: ['', Validators.required],
       type:['', Validators.required],
        contact: ['', Validators.required],
        address:['', Validators.required],
        description:['', Validators.required],
        fee:['', Validators.required]
        });
  
      this.hostelService.getHostelById(+hostelId)
        .subscribe( data => {
          this.editForm.setValue(data);
        });
      }
    
     //else
       //  this.router.navigate(['/login']);
   // }
  
    onSubmit() {
      this.submitted = true;
      if(this.editForm.invalid){
        alert('invalid editform');
        return;
      }
      this.hostelService.updateHostel(this.editForm.value)
        .subscribe(
          data => {
            this.router.navigate(['list-hostel']);
          },
          error => {
            alert('error: '+error.url);
          });
    }
  
     // logOff hostel
     logOutHostel():void{
      if(localStorage.getItem("name")!=null){
        localStorage.removeItem("name");
        this.router.navigate(['/login']);
      }
  }
}
