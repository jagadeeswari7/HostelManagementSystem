import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Hostel } from 'src/app/_models/hostel';
import { HostelService } from '../hostel.service';

@Component({
  selector: 'app-list-hostel',
  templateUrl: './list-hostel.component.html',
  styleUrls: ['./list-hostel.component.css']
})
export class ListHostelComponent implements OnInit {
  hostels!: Hostel[];

  constructor(private router: Router,private hostelService: HostelService) { }

  ngOnInit() {
    
    this.hostelService.getHostels().subscribe(data=> {  
        this.hostels = data;
      });
  }
  
  deleteHostel(hostel: Hostel): void {
    let result = confirm('Do you want to delete the hostel details?')
    if(result)
    {
      this.hostelService.deleteHostel(hostel.hostelId)
        .subscribe( data => {
          this.hostels = this.hostels.filter(u => u !== hostel);
        });
      }
  };
  editHostel(hostel: Hostel): void {
    localStorage.removeItem("editHostelId");
    localStorage.setItem("editHostelId", hostel.hostelId.toString());
    this.router.navigate(['edit-hostel']);
  };
 
  addRoom(): void {
    this.router.navigate(['add-room']);
  };

  addWarden(): void {
    this.router.navigate(['add-warden']);
  };
}