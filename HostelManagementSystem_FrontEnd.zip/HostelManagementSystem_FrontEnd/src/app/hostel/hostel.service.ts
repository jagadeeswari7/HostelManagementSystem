import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Hostel } from '../_models/hostel';

@Injectable({
  providedIn: 'root'
})
export class HostelService {
  constructor(private http:HttpClient) { }
  
  baseUrl:string = 'http://localhost:7070/Hostel';

  // Create Hostel
  createHostel(hostel: Hostel):Observable<string> {
    return this.http.post(this.baseUrl, hostel,{responseType :"text"});
  }
  // Get All Hostels
  getHostels(){
    return this.http.get<Hostel[]>(this.baseUrl+'/getAllHostels');
  }
  // Get Hostel By Id
  getHostelById(hostelId: number){
    return this.http.get<Hostel>(this.baseUrl+'/Id/'+hostelId);
  }
   // Delete Hostel
   deleteHostel(hostelId: number) : Observable<string>{
    return this.http.delete(this.baseUrl + '/' + hostelId,{responseType :"text"});
  }
  // Modify Hostel
  updateHostel(hostel: Hostel): Observable<string>{
    return this.http.put(this.baseUrl +'/Update/'+hostel.hostelId, hostel,{responseType :"text"});
  }
  
}
