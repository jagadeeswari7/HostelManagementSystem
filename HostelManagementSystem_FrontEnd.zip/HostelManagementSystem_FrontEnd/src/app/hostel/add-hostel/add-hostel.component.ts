import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HostelService } from '../hostel.service';

@Component({
  selector: 'app-add-hostel',
  templateUrl: './add-hostel.component.html',
  styleUrls: ['./add-hostel.component.css']
})
export class AddHostelComponent implements OnInit {
  addForm!: FormGroup;
  submitted: boolean = false;

  get f(){
    return this.addForm.controls;
  }

  constructor(private formBuilder: FormBuilder, private router: Router, 
    private hostelService: HostelService) {
      this.addForm = this.formBuilder.group({
        
        name: ['', Validators.required],
        type:['', Validators.required],
        contact: ['', Validators.required],
        address:['', Validators.required],
        description:['', Validators.required],
        fee:['', Validators.required]
        
      });
      
     }

  ngOnInit() {
   
  }

  onSubmit() {
    this.submitted = true;
    if(this.addForm.invalid){
      return;
    }
    this.hostelService.createHostel(this.addForm.value)
      .subscribe( data => {
        this.router.navigate(['list-hostel']);
      });
  }
}
