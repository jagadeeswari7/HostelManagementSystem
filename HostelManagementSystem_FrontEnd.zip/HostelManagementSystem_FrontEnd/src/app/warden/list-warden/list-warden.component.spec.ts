import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListWardenComponent } from './list-warden.component';

describe('ListWardenComponent', () => {
  let component: ListWardenComponent;
  let fixture: ComponentFixture<ListWardenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListWardenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListWardenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
