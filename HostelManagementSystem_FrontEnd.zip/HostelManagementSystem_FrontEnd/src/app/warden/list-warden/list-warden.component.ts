import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Warden } from 'src/app/_models/warden';
import { WardenService } from '../warden.service';

@Component({
  selector: 'app-list-warden',
  templateUrl: './list-warden.component.html',
  styleUrls: ['./list-warden.component.css']
})
export class ListWardenComponent implements OnInit {
  wardens!: Warden[];

  constructor(private router: Router,private wardenService: WardenService) { }

  ngOnInit() {
   // if(localStorage.getItem("wardenname")!=null){
     
    this.wardenService.getWardens().subscribe(data=> {
     // alert('subsribe...');
        this.wardens = data;
      });
    //alert('after subsribe.......');
   // }
   // else
    //this.router.navigate(['/add-warden']);
    
  }
  logOutWarden():void{
    //if(localStorage.getItem("wardenname")!=null){
      localStorage.removeItem("name");
      this.router.navigate(['/login']);
    //}
  }
  deleteWarden(warden: Warden): void {
    let result = confirm('Do you want to delete the warden Details?')
    if(result)
    {
      alert('delete');
      this.wardenService.deleteWarden(warden.wardenId)
        .subscribe( data => {
          this.wardens = this.wardens.filter(u => u !== warden);
          alert('deleted')
        });
      }
  };
  editWarden(warden: Warden): void {
    localStorage.removeItem("editWardenId");
    localStorage.setItem("editWardenId", warden.wardenId.toString());
    this.router.navigate(['edit-warden']);
  };
  addWarden(): void {
    this.router.navigate(['add-warden']);
  }
  home():void{
    this.router.navigate(['dashboard']);
  }
}
