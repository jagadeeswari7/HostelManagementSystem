import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RoomService } from 'src/app/room/room.service';
import { Room } from 'src/app/_models/room';


@Component({
  selector: 'app-room-list',
  templateUrl: './room-list.component.html',
  styleUrls: ['./room-list.component.css']
})
export class RoomListComponent implements OnInit {

  rooms!: Room[];

  // first one to execute and after that ngOnInit
  constructor(private router: Router, private roomService: RoomService) { 
  }

  // Initialize with default list of users
  ngOnInit() {
    this.roomService.getRooms().subscribe(data=> {
      this.rooms = data;
      });
  }



viewRoom(roomId:number){
  this.router.navigate(['view-room',roomId]);
}
}
