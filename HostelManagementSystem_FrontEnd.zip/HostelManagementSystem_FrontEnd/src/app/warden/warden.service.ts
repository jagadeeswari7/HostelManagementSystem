import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Warden } from '../_models/warden';


@Injectable({
  providedIn: 'root'
})
export class WardenService {

  constructor(private http:HttpClient) { }
  baseUrl:string = 'http://localhost:7070/warden';

  // Get All Wardens
  getWardens(){
    return this.http.get<Warden[]>(this.baseUrl+'/Search');
  }
  // Get Warden By Id
  getWardenById(wardenId: number){
    return this.http.get<Warden>(this.baseUrl+'/Id/'+wardenId);
  }
  // Create Warden
  createWarden(warden: Warden) :Observable<String> {
    return this.http.post(this.baseUrl+'/', warden,{responseType:'text'});
  }
  // Modify Warden
  updateWarden(warden: Warden) :Observable<String>{
    return this.http.put(this.baseUrl +'/'+warden.wardenId, warden,{responseType:'text'});
  }
  // Delete Warden
  deleteWarden(wardenId: number):Observable<String> {
    return this.http.delete(this.baseUrl + '/' +wardenId,{responseType:'text'});
  }
}


