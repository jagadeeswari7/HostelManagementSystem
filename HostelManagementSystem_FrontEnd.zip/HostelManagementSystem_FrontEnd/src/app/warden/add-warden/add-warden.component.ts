import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { WardenService } from '../warden.service';


@Component({
  selector: 'app-add-warden',
  templateUrl: './add-warden.component.html',
  styleUrls: ['./add-warden.component.css']
})
export class AddWardenComponent implements OnInit {
  addWardenForm!: FormGroup;
  submitted: boolean = false;


  constructor(private formBuilder: FormBuilder, private router: Router, 
    private wardenService: WardenService) {
      this.addWardenForm=this.formBuilder.group({
        // id:[],
         wardenId:['', Validators.required],
         //userId:['', Validators.required],
         name: ['', Validators.required],
         login:['', Validators.required],
        // hostelId:['', Validators.required]
       });
     }

  ngOnInit(){
   
  }
  

  onSubmit() {
    this.submitted = true;
    if(this.addWardenForm.invalid){
      alert('Add invalid')
      return;
      
    }
    this.wardenService.createWarden(this.addWardenForm.value)
      .subscribe( data => {
        this.router.navigate(['list-warden']);
        
      });
  }
}
