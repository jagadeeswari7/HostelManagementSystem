import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddWardenComponent } from './add-warden.component';

describe('AddWardenComponent', () => {
  let component: AddWardenComponent;
  let fixture: ComponentFixture<AddWardenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddWardenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddWardenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
