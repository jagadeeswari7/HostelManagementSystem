import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { WardenService } from '../warden.service';
import {first} from 'rxjs/operators';
import { Warden } from 'src/app/_models/warden';

@Component({
  selector: 'app-edit-warden',
  templateUrl: './edit-warden.component.html',
  styleUrls: ['./edit-warden.component.css']
})
export class EditWardenComponent implements OnInit {
  warden!: Warden;
  editWardenForm!: FormGroup;
  submitted: boolean = false;

  constructor(private formBuilder: FormBuilder,private router: Router, 
    private wardenService: WardenService) { }
    ngOnInit() {
     // if(localStorage.getItem("name")!=null){
        let wardenId = localStorage.getItem("editWardenId");
        if(!wardenId) {
          alert("Invalid action.")
          this.router.navigate(['list-warden']);
          return;
        }
      this.editWardenForm=this.formBuilder.group({
        wardenId:['', Validators.required],
      //  userId:['', Validators.required],
        name: ['', Validators.required],
        login:['', Validators.required],
      //  hostelId:['', Validators.required]
      });
      this.wardenService.getWardenById(+wardenId)
      .subscribe( data => {
        this.editWardenForm.setValue(data);
      });
    }
    //else
    //alert('Hai')
      //  this.router.navigate(['/login']);
     // }
      onSubmit() {
        this.submitted = true;
        if(this.editWardenForm.invalid){
          alert('invalid editform');
          return;
        }
        this.wardenService.updateWarden(this.editWardenForm.value)
          .pipe(first())
          .subscribe(
            data => {
              this.router.navigate(['list-warden']);
            },
            error => {
              alert('error: '+error.url);
            });
      }
      logOutWarden():void{
        if(localStorage.getItem("wardenname")!=null){
          localStorage.removeItem("wardenname");
          this.router.navigate(['/login']);
        }
    }

    
    

  

}
