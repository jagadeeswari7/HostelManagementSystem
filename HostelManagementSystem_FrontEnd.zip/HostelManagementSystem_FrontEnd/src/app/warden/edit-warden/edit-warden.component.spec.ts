import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditWardenComponent } from './edit-warden.component';

describe('EditWardenComponent', () => {
  let component: EditWardenComponent;
  let fixture: ComponentFixture<EditWardenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditWardenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditWardenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
