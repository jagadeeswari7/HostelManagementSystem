import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HostelService } from 'src/app/hostel/hostel.service';
import { Hostel } from 'src/app/_models/hostel';

@Component({
  selector: 'app-hostel-list',
  templateUrl: './hostel-list.component.html',
  styleUrls: ['./hostel-list.component.css']
})
export class HostelListComponent implements OnInit {
  hostels!: Hostel[];

  constructor(private router: Router,private hostelService: HostelService) { }

  ngOnInit() {
    
    this.hostelService.getHostels().subscribe(data=> {
     
        this.hostels = data;
      });
    
  }
  
  deleteHostel(hostel: Hostel): void {
    let result = confirm('Do you want to delete the hostel details?')
    if(result)
    {
      this.hostelService.deleteHostel(hostel.hostelId)
        .subscribe( data => {
          this.hostels = this.hostels.filter(u => u !== hostel);
        });
      }
  };
  editHostel(hostel: Hostel): void {
    localStorage.removeItem("editHostelId");
    localStorage.setItem("editHostelId", hostel.hostelId.toString());
    this.router.navigate(['edit-hostel']);
  };
  addHostel(): void {
    this.router.navigate(['add-hostel']);
  };
}