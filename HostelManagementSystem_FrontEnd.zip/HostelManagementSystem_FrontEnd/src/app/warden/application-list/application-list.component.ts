import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/user/user.service';
import { User } from 'src/app/_models/user';

@Component({
  selector: 'app-application-list',
  templateUrl: './application-list.component.html',
  styleUrls: ['./application-list.component.css']
})
export class ApplicationListComponent implements OnInit {
  users!: User[];
  userSearch!:User;
  searchText!: any;

  constructor(private router: Router, private userService: UserService,private param:ActivatedRoute) { }

  ngOnInit() {
    this.userService.getUsers().subscribe(data=> {
        this.users = data;
      });
     
    }

    viewUser(id:number){
  
      this.router.navigate(['view-user',id]);
    }
  }