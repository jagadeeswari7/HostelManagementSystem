import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AllotmentService } from 'src/app/allotment/allotment.service';
import { Allotment } from 'src/app/_models/allotment';

@Component({
  selector: 'app-allotment-list',
  templateUrl: './allotment-list.component.html',
  styleUrls: ['./allotment-list.component.css']
})
export class AllotmentListComponent implements OnInit {

  allotments!: Allotment[];

  constructor(private router: Router,private allotmentService: AllotmentService) { }

  ngOnInit() {
        
    this.allotmentService.getAllotments().subscribe(data=> {
  
        this.allotments = data;
      });
    
    
  }
  
  
}