export class Hostel {
    hostelId: number;
    name: string;
    type:string;
    contact: string;
    address: string;
    description:string;
    fee:string;
    
    constructor(hostelId: number, name:string, type: string, contact: string, address:string, description: string, fee: string ){
        this.hostelId=hostelId;
        this.name= name;
        this.type=type;
        this.contact=contact;
        this.address=address;
        this.description= description;
        this.fee=fee;
    }
    
   }