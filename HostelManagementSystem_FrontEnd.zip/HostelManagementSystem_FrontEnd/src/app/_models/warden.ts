import { Hostel } from "./hostel";

export class Warden{
    wardenId: number ;
    // userId: number;
     name: string ;
     login: string ;
     hostelId:number;
     constructor(wardenId:number,name:string,login:string,hostelId:number){
         this.wardenId=wardenId;
        // this.userId=userId;
         this.name=name;
         this.login=login;
         this.hostelId=hostelId;
     }
    }