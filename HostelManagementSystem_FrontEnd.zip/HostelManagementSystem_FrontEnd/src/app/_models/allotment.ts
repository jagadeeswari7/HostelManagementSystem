export class Allotment {
    allotId: number;
    hostelId: number;
    hostelName:string;
    userId: number;
    name: string;
    constructor(allotId:number,hostelId: number, hostelName:string, userId: number, name:string ){
        this.allotId=allotId;
        this.hostelId= hostelId;
        this.hostelName=hostelName;
        this.userId=userId;
        this.name=name;
         }
   }