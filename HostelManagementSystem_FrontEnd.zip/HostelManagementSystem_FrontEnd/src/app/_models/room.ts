
export class Room {
    roomId:number;
    number:number;
    description:string;

    constructor(roomId:number,number:number,description:string){
        this.roomId=roomId;
        this.number=number;
        this.description=description;
    }

}