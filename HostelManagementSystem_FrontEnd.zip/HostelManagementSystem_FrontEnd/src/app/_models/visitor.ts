export class Visitor
{
   visitorId:number;
    name:string;
    studentName:string;
    contactNo:string;
    address:string;
    relation:string;
    purpose:string;

    constructor(visitorId:number,name:string,studentName:string,contactNo:string,address:string,relation:string,
        purpose:string)
        {
           this.visitorId=visitorId;
           this.name=name;
           this.studentName=studentName;
           this.contactNo=contactNo;
           this.address=address;
           this.relation=relation;
           this.purpose= purpose;
        }
}