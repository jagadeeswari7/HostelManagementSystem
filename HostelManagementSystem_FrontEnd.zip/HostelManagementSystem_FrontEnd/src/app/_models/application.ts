import { Hostel } from "./hostel";
import { User } from "./user";

export class Application{
    user:User;
    hostel:Hostel;

    constructor(user:User, hostel:Hostel){
        this.user=user;
        this.hostel=hostel;
    }
}