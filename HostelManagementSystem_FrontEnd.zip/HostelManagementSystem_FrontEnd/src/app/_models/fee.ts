export class Fee {
    feeId: number;
    userId:number;
    name: string;
    hostelId: number;
    hostelName: string;
    totalfee: string;
    pay: string;
    paidfee: string;
    remainingfee: string;
    allotmentId: number;

    constructor(feeId: number,userId:number,name: string,hostelId: number,hostelName: string,totalfee: string,pay: string,paidfee: string,remainingfee: string,allotmentId: number){
        this.feeId=feeId;
        this.userId=userId;
        this.name=name;
        this.hostelId=hostelId;
        this.hostelName=hostelName;
        this.totalfee=totalfee;
        this.pay=pay;
        this.paidfee=paidfee;
        this.remainingfee=remainingfee;
        this.allotmentId=allotmentId;
    }

}