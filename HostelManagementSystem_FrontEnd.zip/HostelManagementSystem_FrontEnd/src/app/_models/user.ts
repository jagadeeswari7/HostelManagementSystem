
export class User {
    userId:number;
    firstName:string;
    lastName:string;
    login:string;
    password:string;
    confirmPassword:string;
    dob:Date;
    mail:string;
    mobileNo:string;
    gender:string;
    image:File;
    roleName:string;
    description:string;
    
    constructor(userId:number, firstName:string, lastName:string, login:string, password:string, confirmPassword:string
        ,dob:Date,  mail:string, mobile:string, gender:string, image:File,roleId:number,roleName:string,description:string){
            this.userId=userId;
            this.firstName=firstName;
            this.lastName=lastName;
            this.login=login;
            this.password=password;
            this.confirmPassword=confirmPassword;
            this.dob=dob;
            this.mail=mail;
            this.mobileNo=mobile;
            this.gender=gender;
            this.image=image;
            this.roleName=roleName;
            this.description=description;
        }
}
