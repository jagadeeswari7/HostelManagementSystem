import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HostelService } from 'src/app/hostel/hostel.service';
import { Hostel } from 'src/app/_models/hostel';


@Component({
  selector: 'app-student-hostel-list',
  templateUrl: './student-hostel-list.component.html',
  styleUrls: ['./student-hostel-list.component.css']
})
export class StudentHostelListComponent implements OnInit {

  hostels!: Hostel[];

  constructor(private router: Router,private hostelService: HostelService ) { }

  ngOnInit() {
     
    this.hostelService.getHostels().subscribe(data=> {
      
        this.hostels = data;
      });
  
    
  }
  
}