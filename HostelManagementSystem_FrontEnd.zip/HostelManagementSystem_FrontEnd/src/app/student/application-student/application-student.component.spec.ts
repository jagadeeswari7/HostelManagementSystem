import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationStudentComponent } from './application-student.component';

describe('ApplicationStudentComponent', () => {
  let component: ApplicationStudentComponent;
  let fixture: ComponentFixture<ApplicationStudentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApplicationStudentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationStudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
