import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/user/user.service';
import { User } from 'src/app/_models/user';

@Component({
  selector: 'app-application-student',
  templateUrl: './application-student.component.html',
  styleUrls: ['./application-student.component.css']
})
export class ApplicationStudentComponent implements OnInit {
  users!: User[];
  userSearch!:User;
  searchText!: any;

  constructor(private router: Router, private userService: UserService,private param:ActivatedRoute) { }

  ngOnInit() {
    this.userService.getUsers().subscribe(data=> {
        this.users = data;
      });
     
    }

    viewUser(id:number){
  
      this.router.navigate(['view-user',id]);
    }
  }