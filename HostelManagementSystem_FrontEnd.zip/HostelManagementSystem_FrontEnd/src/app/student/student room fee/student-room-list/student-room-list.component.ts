import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RoomService } from 'src/app/room/room.service';
import { Room } from 'src/app/_models/room';


@Component({
  selector: 'app-student-room-list',
  templateUrl: './student-room-list.component.html',
  styleUrls: ['./student-room-list.component.css']
})
export class StudentRoomListComponent implements OnInit {

  rooms!: Room[];

  // first one to execute and after that ngOnInit
  constructor(private router: Router, private roomService: RoomService ) { 
  }

  // Initialize with default list of users
  ngOnInit() {
    this.roomService.getRooms().subscribe(data=> {
      this.rooms = data;
      });
  }
}
