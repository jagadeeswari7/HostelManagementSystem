import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentRoomListComponent } from './student-room-list.component';

describe('StudentRoomListComponent', () => {
  let component: StudentRoomListComponent;
  let fixture: ComponentFixture<StudentRoomListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentRoomListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentRoomListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
