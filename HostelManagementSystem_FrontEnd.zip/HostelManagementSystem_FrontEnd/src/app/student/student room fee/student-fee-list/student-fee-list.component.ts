import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FeeService } from 'src/app/fee/fee.service';
import { Fee } from 'src/app/_models/fee';


@Component({
  selector: 'app-student-fee-list',
  templateUrl: './student-fee-list.component.html',
  styleUrls: ['./student-fee-list.component.css']
})
export class StudentFeeListComponent implements OnInit {

  
  fees!: Fee[];

  // first one to execute and after that ngOnInit
  constructor(private router: Router, private feeService: FeeService ) { }

  // Initialize with default list of users
  ngOnInit():void {
    this.feeService.getFees().subscribe(data=> {
      this.fees = data;
      });
  }


}
