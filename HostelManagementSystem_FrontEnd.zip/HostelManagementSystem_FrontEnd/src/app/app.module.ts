import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './Profile/home-page/home-page.component';
import { ContactUsComponent } from './Profile/contact-us/contact-us.component';
import { AboutUsComponent } from './Profile/about-us/about-us.component';
import { GalleryComponent } from './Profile/gallery/gallery.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { UserModule } from './_modules/user.module';
import { LoginModule } from './_modules/login.module';
import { WardenModule } from './_modules/warden.module';
import { FeeModule } from './_modules/fee.module';
import { RoomModule } from './_modules/room.module';
import { AllotmentModule } from './_modules/allotment.module';
import { HostelModule } from './_modules/hostel.module';
import { VisitorModule } from './_modules/visitor.module';
import { AdminLoginComponent } from './Admin/admin-login/admin-login.component';
import { ApplicationStudentComponent } from './student/application-student/application-student.component';
import { HostelListComponent } from './warden/hostel-list/hostel-list.component';



@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    ContactUsComponent,
    AboutUsComponent,
    GalleryComponent,
    AdminLoginComponent,
    ApplicationStudentComponent,
    HostelListComponent,
    
    

 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    UserModule,
    LoginModule,
    WardenModule,
    FeeModule,
    RoomModule,
    AllotmentModule,
    HostelModule,
    VisitorModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
