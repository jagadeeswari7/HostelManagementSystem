import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Fee } from '../_models/fee';

@Injectable({
  providedIn: 'root'
})
export class FeeService {

  constructor(private http:HttpClient) { }
  
  // for Java service
  baseUrl :string = "http://localhost:7070/fees";

  fees:Fee[]=[];
 
  // for Json - Server uncomment following url
  //baseUrl:string = 'http://localhost:3000/fees';

  // Create Fee
  createFee(fee:Fee):Observable<string>{
    return this.http.post(this.baseUrl+'/',fee,{responseType :"text"});
  }

  // Get All Fees
  getFees():Observable<Fee[]>{
    return this.http.get<Fee[]>(this.baseUrl+'/Search/');
  }

  // Get Fee By Id
  getFeeById(feeId: number):Observable<Fee>{
    return this.http.get<Fee>(this.baseUrl+'/feeId'+'/'+feeId);
  }
  
  // Modify Fee details
  updateFee(fee: Fee):Observable<string>{
    return this.http.put(this.baseUrl +'/Update/'+fee.feeId, fee,{responseType :"text"});
  }

  // Delete Fee details
  deleteFee(feeId: number):Observable<string>{
    return this.http.delete(this.baseUrl +'/'+feeId,{responseType : "text"});
  }
  
  // Get Fee details By Name
  getFeeByName(name:string):Observable<Fee>{
    return this.http.get<Fee>(this.baseUrl+'/GetName'+'/'+name);
  }
  
}
