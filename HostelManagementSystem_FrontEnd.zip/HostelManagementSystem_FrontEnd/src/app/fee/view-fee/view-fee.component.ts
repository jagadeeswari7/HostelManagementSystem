import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Fee } from 'src/app/_models/fee';
import { FeeService } from '../fee.service';

@Component({
  selector: 'app-view-fee',
  templateUrl: './view-fee.component.html',
  styleUrls: ['./view-fee.component.css']
})
export class ViewFeeComponent implements OnInit {

  feeId!:number;
  fee!:Fee;
  constructor(private route : ActivatedRoute, private service:FeeService, private router:Router) { }

  ngOnInit(){
    this.route.paramMap.subscribe(
      () =>{
        this.getFeeInfo();
      }
    )
  }
  getFeeInfo(){
    this.feeId=this.route.snapshot.params['feeId'];
    this.service.getFeeById(this.feeId).subscribe(
      data => {
        console.log(data);
        this.fee=data;
      },
      error => console.log(error)
    );
  }


}
