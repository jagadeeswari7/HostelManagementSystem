import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Fee } from 'src/app/_models/fee';
import { FeeService } from '../fee.service';

@Component({
  selector: 'app-add-fee',
  templateUrl: './add-fee.component.html',
  styleUrls: ['./add-fee.component.css']
})
export class AddFeeComponent implements OnInit {

  addFeeForm!: FormGroup;
  submitted: boolean = false;
  
  fee:Fee[]=new Array();
  constructor(private formBuilder: FormBuilder, private router: Router, 
    private feeService: FeeService) { }

  ngOnInit(): void {
    this.addFeeForm = this.formBuilder.group({
      feeId:['', Validators.required],
      name:['', Validators.required],
      hostelId: ['', Validators.required],
      hostelName: ['', Validators.required],
   
      totalfee: ['', Validators.required],
      pay: ['', Validators.required],
      paidfee: ['', Validators.required],
      remainingfee: ['', Validators.required],
      allotmentId: ['', Validators.required]
    });

  }

  onSubmit() {
    this.feeService.createFee(this.addFeeForm.value)   
      .subscribe( data => {
        this.router.navigate(['list-fee']);
      });
  }

 
}
