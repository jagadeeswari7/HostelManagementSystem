import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Fee } from 'src/app/_models/fee';
import { FeeService } from '../fee.service';

@Component({
  selector: 'app-list-fee',
  templateUrl: './list-fee.component.html',
  styleUrls: ['./list-fee.component.css']
})
export class ListFeeComponent implements OnInit {

  fees!: Fee[];

  // first one to execute and after that ngOnInit
  constructor(private router: Router, private feeService: FeeService) { }

  // Initialize with default list of users
  ngOnInit():void {
    this.feeService.getFees().subscribe(data=> {
      this.fees = data;
      });
  }

// Delete Fee
deleteFee(fee: Fee): void {
    let result = confirm('Do you want to delete the details about fee')
     if(result)
      {
        this.feeService.deleteFee(fee.feeId)
          .subscribe( data => {
          this.fees = this.fees.filter(f => f !== fee);
          });
        }
};

//Modify Fee details
editFee(fee: Fee): void {
  localStorage.removeItem("editId");
  localStorage.setItem("editId", fee.feeId.toString());
  this.router.navigate(['edit-fee']);
};

// Add New Fee
addFee(): void {
  this.router.navigate(['add-fee']);
};

viewFee(feeId:number){
  this.router.navigate(['view-fee',feeId]);
}
 

}
