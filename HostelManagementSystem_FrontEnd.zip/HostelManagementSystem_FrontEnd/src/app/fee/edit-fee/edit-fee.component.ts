import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { Fee } from 'src/app/_models/fee';
import { FeeService } from '../fee.service';

@Component({
  selector: 'app-edit-fee',
  templateUrl: './edit-fee.component.html',
  styleUrls: ['./edit-fee.component.css']
})
export class EditFeeComponent implements OnInit {

  fee!: Fee;
  editFeeForm!: FormGroup;
  submitted: boolean = false;
  constructor(private formBuilder: FormBuilder,private router: Router, 
    private feeService: FeeService) { }
  
  ngOnInit(): void { 
    let feeId = localStorage.getItem("editId");
    if(!feeId) {
      alert("Invalid action.")
      this.router.navigate(['list-fee']);
      return;
    }
    this.editFeeForm = this.formBuilder.group({
      feeId:['', Validators.required],
      name:['', Validators.required],
      hostelId: ['', Validators.required],
      hostelName: ['', Validators.required],
      totalfee: ['', Validators.required],
      pay: ['', Validators.required],
      paidfee: ['', Validators.required],
      remainingfee: ['', Validators.required],
      allotmentId: ['', Validators.required]
    });

    this.feeService.getFeeById(+feeId)
      .subscribe( data => {
        this.editFeeForm.setValue(data);
      });
  }

  onSubmit() {
    this.feeService.updateFee(this.editFeeForm.value).pipe(first()) .subscribe(
        data => {
          this.router.navigate(['list-fee']);
        },
        error => {
          alert('error: '+error.url);
        });
  }
 
}
