import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminLoginComponent } from './Admin/admin-login/admin-login.component';
import { AddAllotmentComponent } from './allotment/add-allotment/add-allotment.component';
import { EditAllotmentComponent } from './allotment/edit-allotment/edit-allotment.component';
import { ListAllotmentComponent } from './allotment/list-allotment/list-allotment.component';
import { AdminComponent } from './Dashboard/admin/admin.component';
import { StudentComponent } from './Dashboard/studentdashboard/student.component';
import { WardenComponent } from './Dashboard/wardendashboard/warden.component';
import { AddFeeComponent } from './fee/add-fee/add-fee.component';
import { EditFeeComponent } from './fee/edit-fee/edit-fee.component';
import { ListFeeComponent } from './fee/list-fee/list-fee.component';
import { ViewFeeComponent } from './fee/view-fee/view-fee.component';
import { AddHostelComponent } from './hostel/add-hostel/add-hostel.component';
import { EditHostelComponent } from './hostel/edit-hostel/edit-hostel.component';
import { ListHostelComponent } from './hostel/list-hostel/list-hostel.component';
import { AboutUsComponent } from './Profile/about-us/about-us.component';
import { ContactUsComponent } from './Profile/contact-us/contact-us.component';
import { GalleryComponent } from './Profile/gallery/gallery.component';
import { HomePageComponent } from './Profile/home-page/home-page.component';
import { LoginComponent } from './Profile/login/login.component';
import { AddRoomComponent } from './room/add-room/add-room.component';
import { EditRoomComponent } from './room/edit-room/edit-room.component';
import { ListRoomComponent } from './room/list-room/list-room.component';
import { ViewRoomComponent } from './room/view-room/view-room.component';
import { ApplicationStudentComponent } from './student/application-student/application-student.component';
import { StudentFeeListComponent } from './student/student room fee/student-fee-list/student-fee-list.component';
import { StudentRoomListComponent } from './student/student room fee/student-room-list/student-room-list.component';
import { StudentHostelListComponent } from './student/student-hostel-list/student-hostel-list.component';
import { EditUserComponent } from './user/edit-user/edit-user.component';
import { ForgotPasswordComponent } from './user/forgot-password/forgot-password.component';
import { ListUserComponent } from './user/list-user/list-user.component';
import { RegisterComponent } from './user/register/register.component';
import { ViewUserComponent } from './user/view-user/view-user.component';
import { AddVisitorComponent } from './visitor/add-visitor/add-visitor.component';
import { EditVisitorComponent } from './visitor/edit-visitor/edit-visitor.component';
import { ListVisitorComponent } from './visitor/list-visitor/list-visitor.component';
import { AddWardenComponent } from './warden/add-warden/add-warden.component';
import { AllotmentListComponent } from './warden/allotment-list/allotment-list.component';
import { ApplicationListComponent } from './warden/application-list/application-list.component';
import { EditWardenComponent } from './warden/edit-warden/edit-warden.component';
import { FeeListComponent } from './warden/fee-list/fee-list.component';
import { HostelListComponent } from './warden/hostel-list/hostel-list.component';
import { ListWardenComponent } from './warden/list-warden/list-warden.component';
import { RoomListComponent } from './warden/room-list/room-list.component';


const routes: Routes = [
  //Profile
  { path: '', component: HomePageComponent },
  { path: 'home', component: HomePageComponent },
  { path: 'contact-us', component: ContactUsComponent },
  { path: 'aboutus', component: AboutUsComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent},
  { path: 'gallery', component: GalleryComponent},

  // Dashboard
  { path: 'admin', component: AdminComponent },
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'student', component: StudentComponent },
  { path: 'application-student', component: ApplicationStudentComponent },
  { path: 'student-hostel-list', component: StudentHostelListComponent },
  { path: 'student-room-list', component: StudentRoomListComponent },
  { path: 'student-fee-list', component: StudentFeeListComponent },
  { path: 'warden', component: WardenComponent },

  //User
  { path: 'edit-user', component: EditUserComponent },
  { path: 'list-user', component: ListUserComponent },
  { path: 'view-user/:id', component: ViewUserComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },

  //Hostel
  { path: 'add-hostel', component: AddHostelComponent },
  { path: 'list-hostel', component: ListHostelComponent },
  { path: 'edit-hostel', component: EditHostelComponent },

  //Allotment
  { path: 'add-allotment', component: AddAllotmentComponent },
  { path: 'list-allotment', component: ListAllotmentComponent },
  { path: 'edit-allotment', component: EditAllotmentComponent  },

  //Room
  { path: 'add-room', component: AddRoomComponent },
  { path: 'edit-room', component: EditRoomComponent },
  { path: 'list-room', component: ListRoomComponent },
  { path: 'view-room/:roomId', component: ViewRoomComponent  },

  //Fee
  { path: 'add-fee', component: AddFeeComponent  },
  { path: 'list-fee', component: ListFeeComponent  },
  { path: 'edit-fee', component: EditFeeComponent },
  { path: 'view-fee/:feeId', component: ViewFeeComponent  },

  //Visitor
  { path: 'add-visitor', component: AddVisitorComponent },
  { path: 'list-visitor', component: ListVisitorComponent },
  { path: 'edit-visitor', component: EditVisitorComponent },
  
  //Warden-class
  { path: 'add-warden', component: AddWardenComponent },
  { path: 'list-warden', component: ListWardenComponent  },
  { path: 'edit-warden', component: EditWardenComponent },
  { path: 'application-list', component: ApplicationListComponent },
  { path: 'hostel-list', component: HostelListComponent },
  { path: 'room-list', component: RoomListComponent },
  { path: 'allotment-list', component: AllotmentListComponent },
  { path: 'fee-list', component: FeeListComponent },
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
