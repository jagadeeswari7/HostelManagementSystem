import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/Profile/login/login.service';
import { User } from 'src/app/_models/user';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  forgotForm : FormGroup;
  submitted:boolean =false;
  inform!:any;
  user!:User;

  constructor(private formBuilder: FormBuilder,private router: Router,private service:LoginService) {
    this.forgotForm = this.formBuilder.group({
      login: ['',Validators.required]
    });
  }
 
  
  ngOnInit() {
    this.forgotForm =new FormGroup({
      login : new FormControl(),
    });
  }

  onSubmit() {
      
      let email = (document.getElementById('email-for-pass') as HTMLInputElement)
        .value;
      alert('Link sent to ' + email);
      this.submitted = true;
      console.log(this.forgotForm.controls.login.value);
      /*
       this.inform = this.service.forgotPassword(login).subscribe(data => {
        this.inform = data;
        });
    */
        this.router.navigate(['/login']);
     
  }
}   
