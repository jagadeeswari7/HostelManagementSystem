import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/_models/user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {
  id!: number;
  user!:User;
  constructor(private route:ActivatedRoute, private service:UserService , private router:Router) { }

  ngOnInit(){
    this.route.paramMap.subscribe(
      () =>{
        this.getUserInfo();
      }
    )
  }
  getUserInfo(){
  this.id = this.route.snapshot.params['id'];

  this.service.getUserById(this.id).subscribe(
    data => {
      console.log(data);
      this.user=data;
    },
    error => console.log(error));
  }
}
  

