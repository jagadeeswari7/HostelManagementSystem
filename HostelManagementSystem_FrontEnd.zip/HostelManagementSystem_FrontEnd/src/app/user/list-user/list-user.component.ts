import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/_models/user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {
  users!: User[];
  userSearch!:User;
  searchTerm!: string;

  constructor(private router: Router, private userService: UserService,private param:ActivatedRoute) { }

  ngOnInit() {
    this.userService.getUsers().subscribe(data=> {
        this.users = data;
      });
     
    }

  // Delete User
deleteUser(user: User): void {
  let result = confirm('Do you want to delete the user?')
  if(result)
  {
    this.userService.deleteUser(user.userId)
      .subscribe( data => {
        alert('Record is deleted');
        this.users = this.users.filter(u => u !== user);
      });
    }
};

// Modify USer
editUser(user: User): void {
localStorage.removeItem("editUserId");
localStorage.setItem("editUserId", user.userId.toString());
this.router.navigate(['edit-user']);
};

viewUser(id:number){
  
  this.router.navigate(['view-user',id]);
}

showUser(login:string){
  this.router.navigateByUrl(`/show-user/${login}`);
}



}
