import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../_models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http:HttpClient) { }
  
  // for Java service
  baseUrl :string = "http://localhost:7070/users";

  users:User[]=[];
 
  // for Json - Server uncomment following url
  //baseUrl:string = 'http://localhost:3000/users';

  // Create User
  createUser(user:User):Observable<string>{
    alert("user data test");
    return this.http.post(this.baseUrl+'/register',user,{responseType :"text"});
  }

  // Get All Users
  getUsers():Observable<User[]>{
    return this.http.get<User[]>(this.baseUrl+'/getAllUsers');
  }

  // Get User By Id
  getUserById(userId: number):Observable<User>{
    return this.http.get<User>(this.baseUrl+'/userId'+'/'+userId);
  }
  
  // Modify User
  updateUser(user: User):Observable<string>{
    return this.http.put<string>(this.baseUrl +'/updateUser'+'/'+user.userId, user);
  }

  // Delete User
  deleteUser(id: number):Observable<boolean>{
    return this.http.delete<boolean>(this.baseUrl + '/removeUser' +'/'+ id);
  }
  
  // Get User By Name
  getUserByLogin(login:string):Observable<User>{
    return this.http.get<User>(this.baseUrl+'/findByLogin'+'/'+login);
  }
}