import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/_models/user';
import { UserService } from '../user.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  selectedImage! : File;
  addForm : FormGroup;
  submitted: boolean = false;
  user!:User;
  event:any;
  
  constructor(private formBuilder: FormBuilder, private router: Router, 
    private userService: UserService) { 
      this.addForm = this.formBuilder.group({
        
        firstName: ['', Validators.required],
        lastName:['', Validators.required],
        login:['', [Validators.required,Validators.email]],
        password:['',[Validators.required,Validators.minLength(8),Validators.maxLength(30)]],
        confirmPassword:['',[Validators.required,Validators.minLength(8)]],
        dob:['',Validators.required],
        roleName:['',Validators.required],
        gender:['',Validators.required],
        mobileNo:['', Validators.required],
        image:[''],
        description:['',Validators.required]
    });
    }

  ngOnInit() {
    
  }
  get f(){
    return this.addForm.controls;
  }
  onFileChanged(event:any) {
    this.selectedImage = event.target.files[0];
  }
  onSubmit() {
    this.submitted = true;
    alert('Your details are submitted');
    
    //localStorage.setItem("login",this.user.login);
    if(this.addForm.invalid){
      alert('Record is not added');
      return;
    }
    
      this.userService.createUser(this.addForm.value)
      .subscribe( (data: any) => {
        alert('You are successfully registered!!!Click OK to continue');
    
        this.router.navigate(['login']);
      });
    
  }
}
      

