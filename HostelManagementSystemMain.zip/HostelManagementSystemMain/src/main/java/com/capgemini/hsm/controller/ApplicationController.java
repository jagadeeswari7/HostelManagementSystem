package com.capgemini.hsm.controller;
/** This is a Controller class for Application module 
 * 
 * @author Tejaswi's
 *
 */
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Application;
import com.capgemini.hsm.service.ApplicationService;


@RestController
@RequestMapping(path="Application") // Map a specific request path or pattern onto a controller
public class ApplicationController {
	@Autowired
	ApplicationService service;// To establish a relationship with Application service

	/** This method adds user application in the database
	 *
	 * @param  Application
	 * @return Application object
	 */
	@PostMapping
	public ResponseEntity<Application> addApplication(@Valid @RequestBody Application entity) throws DuplicateRecordException {
		Application result = service.add(entity);
		ResponseEntity<Application> response;
		if(result!=null) {
			response = new ResponseEntity<Application>(result,HttpStatus.CREATED);
		}else {
			response = new ResponseEntity<Application>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}  
	
	/** This method is to view Application Users by Name
	 *
	 * @param  ApplicationName
	 * @return Application object
	 * @throws RecordNotFoundException 
	 */
	
	@GetMapping("/ApplicationName/{applicationName}")
	private ResponseEntity<List<Application>> getApplicationsByName(@PathVariable("applicationName") String name) throws RecordNotFoundException {
		List<Application> applicationList=service.findApplicationByName(name);
		if(applicationList.isEmpty()) {
			return new ResponseEntity<List<Application>>(HttpStatus.NOT_FOUND) ;
		}
		else {
			return new ResponseEntity<List<Application>>(applicationList,HttpStatus.OK) ;
		}
	}
	
	/** This method is to view Application by Id
	 *
	 * @param  ApplicationId
	 * @return Application object
	 * @throws RecordNotFoundException 
	 */
	
	@GetMapping("/ApplicationId/{applicationId}")  
	private ResponseEntity<Application> getUserByID(@PathVariable("applicationId") long applicationId) throws RecordNotFoundException 
	{ 
		Application application= service.findApplicationByPk(applicationId);
		if(application!=null) {
			return new ResponseEntity<Application>(application,HttpStatus.OK);
		}
		return new ResponseEntity<Application>(HttpStatus.NOT_FOUND);
	}

	/** This method updates Application Record Data in the database
    *
    * @param  ApplicationId
    * @param  Application
    * @return Application User object
    * @throws RecordNotFoundException 
    */
	
	@PutMapping("/ApplicationId/{ApplicationId}")  
	public ResponseEntity<Application> update(@PathVariable("ApplicationId") long id, @RequestBody Application application) throws RecordNotFoundException{   
	{ 
		Application application1= service.findApplicationByPk(id);
		Application result = service.update(application, id);
		if(result!=null && application1!=null) {
			return new ResponseEntity<Application>(result,HttpStatus.OK);
		}else if(application1==null) {
			return new ResponseEntity<Application>(HttpStatus.NOT_FOUND);
		}
		    return new ResponseEntity<Application>(HttpStatus.NOT_ACCEPTABLE);
		}
	}
	
	/** This method deletes Application record in the database
	 *
	 * @param  ApplicationId
	 * @throws RecordNotFoundException 
	 */
	
	@DeleteMapping("/ApplicationId/{ApplicationId}")  
	private ResponseEntity<String> deleteApplicationByID(@PathVariable("ApplicationId") long id)  throws RecordNotFoundException  
	{  
			if(service.delete(id)) 
				return new ResponseEntity<String>("Application is deleted",HttpStatus.OK);
			return new ResponseEntity<String>("Application not found",HttpStatus.NOT_FOUND);
		
	}  
	
	/** This method returns the list of Application records in the database
	 *
	 * @return list of all Application
	 */
	
	@GetMapping("/GetAllApplications")
	private ResponseEntity<List<Application>> getDetailsOfAllApplications() throws RecordNotFoundException  
	{  
		List<Application> applications=service.search();
		if(applications.isEmpty()) {
			return new ResponseEntity<List<Application>>(HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
		else {
			return new ResponseEntity<List<Application>>(applications,HttpStatus.OK) ;
		}
	}  
}
