package com.capgemini.hsm.service;
/** The FeeServiceImpl class provides access to repository methods to CRUD operations User details 
 * 
 * 
 * @author Deepthi's
 *
 */
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Fee;
import com.capgemini.hsm.repository.FeeDAO;


@Transactional
@Service
public class FeeServiceImpl implements FeeService {
    @Autowired
	private FeeDAO dao;

    private static final Logger logger = LogManager.getLogger(FeeServiceImpl.class);
    
    public FeeDAO getDao() {
		return dao;
	}

	public void setDao(FeeDAO dao) {
		this.dao = dao;
	}

	@Override
	public Fee add(Fee entity) throws DuplicateRecordException {
		logger.info(" Start add fee method in the service!");
		if(dao.existsById(entity.getFeeId())) {
			logger.error("Fee is already present");
			throw new DuplicateRecordException("Duplicate Fee Found");
		}
		dao.save(entity);
		logger.info(" Fee Record Added Successfully...!");
		return entity;
	}

	@Override
	public Fee update(Fee entity,long feeId) throws RecordNotFoundException{
		logger.info(" Start update fee method in the service!");
		Fee currentFee = dao.findByFeeId(feeId);
        if (currentFee!=null) {
        	currentFee.setName(entity.getName());
        	currentFee.setHostelName(entity.getHostelName());
        	currentFee.setTotalfee(entity.getTotalfee());
        	currentFee.setPaidfee(entity.getPaidfee());
        	currentFee.setRemainingfee(entity.getRemainingfee());
        	dao.save(currentFee);
        	logger.info("Fee Data Updated Successfully...!");
        	return currentFee;
        }
        else {
        	logger.error("Fee is not present");
        	throw new RecordNotFoundException("Fee not found for this id : "+feeId);
        }
	}

	@Override
	public boolean delete(long feeId) throws RecordNotFoundException {
		logger.info(" Start delete fee method in the service!");
		if(dao.existsById(feeId)) {
			dao.deleteById(feeId);
			logger.info("Fee Record Removed Successfully...!");
			return true;
		}else {
			logger.error("Fee is not present");
			throw new RecordNotFoundException("Fee not found for this id : "+feeId);
		}
	}

	@Override
	public List<Fee> findByName(String name) throws RecordNotFoundException{
		logger.info(" Start reading fee by name method in the service!");
		List<Fee> listByName= dao.findByName(name);
		if(!listByName.isEmpty())
		{
			logger.info(" Retrieved Fee by Name successfully...!");
			return listByName;
		}
		else {
			logger.error("Fee is not present");
		    throw new RecordNotFoundException("Record Not Found for this name :"+name);
		}
	}

	@Override
	public Fee findByPk(long feeId) throws RecordNotFoundException{
		logger.info(" Start reading fee by feeId method in the service!");
		Fee fee=dao.findByFeeId(feeId);
		if(fee!=null)
		{
			logger.info(" Retrieved fee by id successfully...!");
			return fee;
		}
		else {
			logger.error("Fee is not present");
		throw new RecordNotFoundException("Record Not Found for this id :"+feeId);
		}
	}

	@Override
	public List<Fee> search(){
		logger.info("Start reading all fee records method in the service!");
		List<Fee> feeList = dao.findAll();
		logger.info(" Retrieved all the fee successfully...!");
		return feeList;		
	}

}