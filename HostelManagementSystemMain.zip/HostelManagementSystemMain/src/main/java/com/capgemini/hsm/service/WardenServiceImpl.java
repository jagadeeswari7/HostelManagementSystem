package com.capgemini.hsm.service;
/** The WardenServiceImpl class provides access to repository methods to CRUD operations User details 
 * 
 * 
 * @author Bhavana's
 *
 */
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Warden;
import com.capgemini.hsm.repository.WardenDAO;

@Transactional
@Service
public class WardenServiceImpl implements WardenService{
		
		@Autowired
		private WardenDAO dao;
		private static final Logger logger = LogManager.getLogger(WardenServiceImpl.class);
		
		public WardenDAO getDao() {
			return dao;
		}

		public void setDao(WardenDAO dao) {
			this.dao = dao;
		}
		
		@Override
		public Warden addWarden(Warden entity) throws DuplicateRecordException {
			logger.info(" Start add warden method in the service!");
			if(dao.existsById(entity.getWardenId())) {
				logger.error("Warden is not present" );
				throw new DuplicateRecordException("Duplicate Record Found");
			}
			dao.save(entity);
			logger.info("Warden Record Added Successfully...!");
			return entity;
		}
		
		@Override
		public Warden updateWarden(Warden entity,long wardenId) throws RecordNotFoundException {
			logger.info(" Start update warden method in the service!");
			Warden warden = dao.findBywardenId(wardenId);
	        if (warden!=null) {
	        	warden.setName(entity.getName());
	        	warden.setLogin(entity.getLogin());
	        	dao.save(warden);
	        	logger.info("Warden Data Updated Successfully...!");
	            return warden;     	
	        }
	        else {
				logger.error("Warden is not present" );
				throw new RecordNotFoundException("Record Not Found for this id");
			   
	        }
		}
		
		@Override	
		public boolean deleteWarden(long id) throws RecordNotFoundException {
			logger.info(" Start delete method method in the service!");
			if(dao.existsById(id)) {
			   dao.deleteById(id);
			   logger.info("Warden Record Removed Successfully...!");
			   return true;
			}
			else {
				logger.error("Warden id is not present" );
				throw new RecordNotFoundException("Record Not Found for this id");
			   
		}
		}

		@Override
		public List<Warden> findByWardenName(String name) throws RecordNotFoundException {
			logger.info(" Start reading warden by wardenName method in the service!");
			List<Warden> wardenList = dao.findByName(name);
			if(!wardenList.isEmpty()) {
				logger.info(" Retrieved Warden by name successfully...!");
				 return wardenList;
			}
			else {
				logger.error("Warden is not present" );
				throw new RecordNotFoundException("Record Not Found for this name");
			}
			 
			}
		
		@Override
		public Warden findByPk(long wardenId) throws RecordNotFoundException {
			logger.info(" Start reading warden by wardenId method in the service!");
			Warden warden = dao.findBywardenId(wardenId);
			if(warden!=null) {
				logger.info(" Retrieved Warden by id successfully...!");
				return warden;  
			}
			else {
				logger.error("Warden id is not present" );
				throw new RecordNotFoundException("Record Not Found for this id");
			}
			
		}
		
	    @Override
		public List<Warden> searchAllWardens() {
	    	logger.info("Start reading all warden records method in the service!");
	    	
	    	List<Warden> list = dao.findAll();
	    	logger.info(" Retrieved all the  successfully...!");
			return list;
		}
		}
