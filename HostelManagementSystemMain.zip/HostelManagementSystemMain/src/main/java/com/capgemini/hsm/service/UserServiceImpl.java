package com.capgemini.hsm.service;

/** The UserServiceImpl class provides access to repository methods to CRUD operations User details 
 * 
 * 
 * @author Jagadeeswari's
 *
 */
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.hsm.exception.ApplicationException;
import com.capgemini.hsm.exception.DatabaseException;
import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.User;
import com.capgemini.hsm.repository.UserDAO;

@Transactional
@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDAO dao;
	
	private static final Logger logger = LogManager.getLogger(UserServiceImpl.class);
			
	public UserDAO getDao() {
		return dao;
	}

	public void setDao(UserDAO dao) {
		this.dao = dao;
	}
	
	@Override
	public User add(User entity) throws DuplicateRecordException {
		logger.info(" Start add user method in the service!");
		if(dao.existsById(entity.getUserId())) {
			logger.error("Duplicate Record Found");
			throw new DuplicateRecordException("User already exists");
		}
		dao.save(entity);
		logger.info("User Record Added Successfully...!");
		return entity;
	}

	@Override
	public User update(User entity, long userId) throws RecordNotFoundException{
		logger.info(" Start update user method in the service!");
		User currentUser = dao.findByUserId(userId);
		if(currentUser!=null) { 
        	currentUser.setFirstName(entity.getFirstName());
        	currentUser.setLastName(entity.getLastName());
        	currentUser.setDob(entity.getDob());
        	currentUser.setMail(entity.getMail());
        	currentUser.setMobileNo(entity.getMobileNo());
        	currentUser.setGender(entity.getGender());
        	dao.save(currentUser);
        	logger.info("User Data Updated Successfully...!");
        	return currentUser;
		}
		logger.error("User not present");
		throw new RecordNotFoundException("User not found for this id :: "+userId);
	}

	@Override
	public boolean delete(long userId) throws RecordNotFoundException {
		logger.info(" Start delete user method in the service!");
		if(dao.existsById(userId)) {
			dao.deleteById(userId);
			logger.info("User Record Removed Successfully...!");
			return true;
		}else {
			logger.error("User not present");
			throw new RecordNotFoundException("User not found for this id :: "+userId);
		}
	}

	@Override
	public User findByLogin(String login) throws RecordNotFoundException {
		logger.debug(" Start reading user by login method in the service!");
		User user = dao.findByLogin(login);
		if(user!=null) {
			logger.info(" Retrieved User by Login successfully...!");
			return user;
		}
		    logger.error("User not present");
			throw new RecordNotFoundException("Record Not Found for this login :: "+login);
	}

	@Override
	public User findByPk(long userId) throws RecordNotFoundException {
		logger.info(" Start reading user by userId method in the service!");
		User user = dao.findByUserId(userId);
		if(user!=null) {
			logger.info(" Retrieved User by id successfully...!");
			return user;  
		}
		logger.error("User not present");
		throw new RecordNotFoundException("User not found for this id :: "+userId);
	}

	@Override
	public List<User> searchAllUsers() {
		logger.info("Start reading all user records method in the service!");
		List<User> usersList = dao.findAll();
		logger.info(" Retrieved all the users successfully...!");
		return usersList;
	}

	@Override
	public User authenticate(User entity) throws RecordNotFoundException, ApplicationException {
		logger.info(" Start authentication check for user method in the service!");
		User user = dao.findByUserId(entity.getUserId());
		if(user!=null) {
			if(user.getLogin().equals(entity.getLogin()) && user.getPassword().equals(entity.getPassword())){ 
				logger.info(" Authentication check done successfully...!");
				return user;
			}else {
				logger.error("Invalid details given");
		        throw new ApplicationException("Authentication Not Successful");
			}
		}
		    logger.error("User not present");
		    throw new RecordNotFoundException("Record not found for this id ::"+entity.getUserId());
	}

	@Override
	public boolean changePassword(long id , String mail, String newPassword) throws ApplicationException, RecordNotFoundException{
		logger.info(" Start changing password for the user method in the service!");
		User user = dao.findByUserId(id);
		if(user!=null) {
		if(user.getMail().equals(mail)) {
			user.setPassword(newPassword);
			dao.save(user);
			logger.info(" Password Changed successfully...!");
			return true;
		}else {
			logger.error("Invalid details");
		   throw new ApplicationException("Invalid Email Details");	
		}
		}
		    logger.error("User not present");
		    throw new RecordNotFoundException("Record not found for this id ::"+id);
	}

	@Override
	public User registerUser(User newUser) throws DuplicateRecordException, DatabaseException {
		logger.info(" Start registering a new user method in the service!");
		if(dao.existsById(newUser.getUserId())) {
			logger.error("Duplicate Record Found");
			throw new DuplicateRecordException("Duplicate Record Found");
		}
		dao.save(newUser);
    	Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("hostelmanagement.office@gmail.com", "HSM@1234");
			}
		});
			
			try {
				MimeMessage message = new MimeMessage(session);
				message.setFrom();
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(newUser.getMail()));
				message.setSubject("HSM OFFICE WELCOMES YOU!");
				message.setContent("You have Successfully registered!!..You can now access your profile in the portal!!!", "text/html");
				// send message
				Transport.send(message);
		        logger.info(" Registering a new user done successfully...!");
			} catch (MessagingException e) {
				throw new DatabaseException("Unable to send email");
			}
		return newUser;
	}

	@Override
	public String forgetPassword(String login) throws RecordNotFoundException{
		logger.info(" Start forget password for the user method in the service!");
		User user = dao.findByLogin(login);
		if(user!=null && user.getLogin().equals(login)) {
			logger.info(" Forget Password Check done successfully...!");
			return user.getPassword();
		}
		logger.error("User not present");
		throw new RecordNotFoundException("Record not found for this login "+login);
	}
	
}
