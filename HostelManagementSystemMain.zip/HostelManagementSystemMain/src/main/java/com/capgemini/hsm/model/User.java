package com.capgemini.hsm.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotBlank;

import com.capgemini.hsm.validations.ValidEmail;
import com.capgemini.hsm.validations.ValidPassword;

@Entity
@Table(name="Users")
public class User implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
    @Id
    @Column(name="USER_ID")
	private long userId;
    
    @Column(name="FIRST_NAME")
	private String firstName;
    
    @Column(name="LAST_NAME")
	private String lastName;
    
	@Column(name = "LOGIN", unique = true)
	@NotBlank(message = "Login must not be blank")
	private String login;
	
	@Column(name="PASSWORD")
	@NotBlank(message = "Please provide password")
	@ValidPassword
	private String password;
	
	@Transient
	private String confirmPassword;
	
	@Column(name="DOB")
	@Temporal(value=TemporalType.DATE)
	private Date dob;
	
	@Column(name = "MAIL")
	@NotBlank(message = "Please provide Email")
	@ValidEmail
	private String mail;
	
	@Column(name="MOBILE_NUMBER")
	private String mobileNo;
	
	@Column(name="GENDER")
	private String gender;
	
	@Column(name="IMAGE")
	private String image;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="ROLE_ID")
	private Role role;
	
	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}
	
	public User() {
		
	}

	public User(long userId, String firstName, String lastName, String login, String password, String confirmPassword,
			Date dob, String mail, String mobileNo, String gender, String image) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.login = login;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.dob = dob;
		this.mail = mail;
		this.mobileNo = mobileNo;
		this.gender = gender;
		this.image = image;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", login=" + login
				+ ", password=" + password + ", confirmPassword=" + confirmPassword + ", dob=" + dob + ", mail=" + mail
				+ ", mobileNo=" + mobileNo + ", gender=" + gender + ", image=" + image + "]";
	}
	
	
	
}
