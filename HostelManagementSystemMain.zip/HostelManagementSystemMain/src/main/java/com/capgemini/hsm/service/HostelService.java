package com.capgemini.hsm.service;

import java.util.List;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Hostel;


public interface HostelService {
	public Hostel add(Hostel entity) throws DuplicateRecordException;
	public boolean delete(long Id) throws RecordNotFoundException;
	public Hostel findByPk(long id) throws RecordNotFoundException;
	public List<Hostel> search();
	public List<Hostel> findByName(String name) throws RecordNotFoundException;
	public Hostel update(long id, Hostel Entity) throws RecordNotFoundException;
	
	}
