package com.capgemini.hsm.service;
	
	import java.util.List;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Application;

	public interface ApplicationService {

		public Application add(Application entity) throws DuplicateRecordException;
		public boolean delete(long applicationId) throws RecordNotFoundException;
		public List<Application> findApplicationByName(String name) throws RecordNotFoundException;
		public Application findApplicationByPk(long applicationId) throws RecordNotFoundException;
		public List<Application> search();
		Application update(Application entity, long applicationId) throws RecordNotFoundException;
		
		
		
	}
	


