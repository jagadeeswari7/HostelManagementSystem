package com.capgemini.hsm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Fees")
public class Fee implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "FEE_ID")
	private long feeId;
	
	@Column(name = "NAME")
	@NotNull
	@Size(min=3,max=30, message="The length of Name should be between 3 and 30 characters")
	private String name;
	
	@Column(name = "HOSTEL_ID")
	private long hostelId;
	
	@Column(name = "HOSTEL_NAME")
	@NotNull
	@Size(min=3,max=30, message="The length of hostelName should be between 3 and 30 characters")
	private String hostelName;
	
	@Column(name = "TOTAL_FEE")
	private String totalfee;
	
	@Column(name = "PAY")
	private String pay;
	
	@Column(name = "PAID_FEE")
	private String paidfee;
	
	@Column(name = "REMAINING_FEE")
	private String remainingfee;
	
	@Column(name = "ALLOTMENT_ID")
	private long allotmentId;
	
	@OneToOne
	@JoinColumn(name="USER_ID")
	private User user;
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	@ManyToOne
	@JoinColumn(name = "ROOM_ID")
	private Room room;
	
	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public Fee(long feeId, String name, long hostelId, String hostelName, 
			String totalfee, String pay, String paidfee, String remainingfee, long allotmentId) {
		super();
		this.feeId = feeId;
		this.name = name;
		this.hostelId = hostelId;
		this.hostelName = hostelName;
		this.totalfee = totalfee;
		this.pay = pay;
		this.paidfee = paidfee;
		this.remainingfee = remainingfee;
		this.allotmentId = allotmentId;
	}
	public Fee() {
		
	}
	public long getFeeId() {
		return feeId;
	}
	public void setFeeId(long feeId) {
		this.feeId = feeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getHostelId() {
		return hostelId;
	}
	public void setHostelId(long hostelId) {
		this.hostelId = hostelId;
	}
	public String getHostelName() {
		return hostelName;
	}
	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}

	public String getTotalfee() {
		return totalfee;
	}
	public void setTotalfee(String totalfee) {
		this.totalfee = totalfee;
	}
	public String getPay() {
		return pay;
	}
	public void setPay(String pay) {
		this.pay = pay;
	}
	public String getPaidfee() {
		return paidfee;
	}
	public void setPaidfee(String paidfee) {
		this.paidfee = paidfee;
	}
	public String getRemainingfee() {
		return remainingfee;
	}
	public void setRemainingfee(String remainingfee) {
		this.remainingfee = remainingfee;
	}
	public long getAllotmentId() {
		return allotmentId;
	}
	public void setAllotmentId(long allotmentId) {
		this.allotmentId = allotmentId;
	}
}
