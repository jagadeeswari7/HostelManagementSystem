package com.capgemini.hsm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;



@Entity
@Table(name = "Rooms")
public class Room implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ROOM_ID")
	private long roomId;
	
	@Column(name = "NAME")
	@NotNull
	@Size(max=40, message="The length of Name should not exceed 40 characters")
	private String name;
	
	@Column(name = "DESCRIPTION")
	@Size(max=40, message="Description should not exceed 40 characters")
	private String description;
	
	@ManyToOne
	@JoinColumn(name="HOSTEL_ID")
	private Hostel hostel;
	
	public Hostel getHostel() {
		return hostel;
	}

	public void setHostel(Hostel hostel) {
		this.hostel = hostel;
	}
	public Room(long roomId, String name, String description) {
		super();
		this.roomId = roomId;
		this.name = name;
		this.description = description;
	}

	public Room() {
		
	}

	public long getRoomId() {
		return roomId;
	}
	public void setRoomId(long roomId) {
		this.roomId = roomId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}