package com.capgemini.hsm.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * The ApplicationException layer provides customized Exceptions
 */
@ResponseStatus(value = HttpStatus.NOT_ACCEPTABLE)
public class ApplicationException  extends Exception
{
	
	
	private static final long serialVersionUID = 1L;

	public ApplicationException(String message) {
		super(message);
	}
}
