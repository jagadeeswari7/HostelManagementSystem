package com.capgemini.hsm.controller;
/** This is a Controller class for Visitor module 
 * 
 * @author RamyaPriya's
 *
 */
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DatabaseException;
import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Visitor;
import com.capgemini.hsm.service.VisitorService;

@RestController
@RequestMapping("visitors") // Map a specific request path or pattern onto a controller
public class VisitorController {

	@Autowired
	private VisitorService service;// To establish a relationship with Visitor service
	
	/** This method adds Visitor record in the database
	 *
	 * @param  Visitor
	 * @return Visitor object
	 */
	@PostMapping
	public ResponseEntity<Visitor> addVisitor(@Valid @RequestBody Visitor visitors) throws DuplicateRecordException
	{
		Visitor result=service.addVisitor(visitors);
		ResponseEntity<Visitor> response;
		if(result!=null)
		{
			response=new ResponseEntity<Visitor>(result,HttpStatus.CREATED);
		}
		else
		{
			response=new ResponseEntity<Visitor>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	/** This method is to view Visitor by Id
	 *
	 * @param  VisitorId
	 * @return Visitor object
	 * @throws RecordNotFoundException 
	 */
	@GetMapping("/Id/{visitorId}")
	public ResponseEntity<Visitor> getDetailsById(@PathVariable("visitorId") long id) throws RecordNotFoundException
	{
		Visitor visitorsById=service.findVisitorByPK(id);
		if(visitorsById!=null)
		{
			return new ResponseEntity<Visitor>(visitorsById,HttpStatus.OK);	
		}
		else
		{
			return new ResponseEntity<Visitor>(HttpStatus.NOT_FOUND);
			
		}
	}
	
	/** This method is to view Visitor by Name
	 *
	 * @param  VisitorName
	 * @return Visitor object
	 * @throws RecordNotFoundException 
	 */
	@GetMapping("/Name/{visitorName}")
	public ResponseEntity<List<Visitor>> getDetailsByName(@PathVariable("visitorName") String name) throws RecordNotFoundException
	{
		List<Visitor> visitorsByName=service.findVisitorByName(name);
		if(visitorsByName.isEmpty())
		{
			return new ResponseEntity<List<Visitor>>(HttpStatus.NOT_FOUND);
		}
		else
		{
			return new ResponseEntity<List<Visitor>>(visitorsByName,HttpStatus.OK);
		}
	}
	
	/** This method returns the list of Visitor records in the database
	 *
	 * @return list of all Visitors
	 */
	@GetMapping
	public ResponseEntity<List<Visitor>> getDetailsOfAllVisitors() throws RecordNotFoundException
	{
		List<Visitor> visitorList=service.searchVisitor();
		if(visitorList.isEmpty())
		{
		   return new ResponseEntity<List<Visitor>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<Visitor>>(visitorList,HttpStatus.OK);
	}
	
	/** This method deletes Visitor record in the database
	 *
	 * @param  VisitorId
	 * @throws RecordNotFoundException 
	 */
	@DeleteMapping("{visitorId}")
	public ResponseEntity<String> deleteDetailsOfVisitors(@PathVariable("visitorId")long id) throws RecordNotFoundException
	{
		String deletemsg=service.deleteVisitor(id);
		if(deletemsg!=null)
			return new ResponseEntity<String>("Visitor with the id "+id+" is deleted",HttpStatus.OK);
		else
			 return new ResponseEntity<String>("Visitor Id is not Found",HttpStatus.NOT_FOUND);
			
		
	}
	
	/** This method updates Visitor Record Data in the database
    *
    * @param  VisitorId
    * @param  Visitor
    * @return Visitor User object
    * @throws RecordNotFoundException 
    */
	@PutMapping("/{visitorId}")
	public ResponseEntity<Visitor> updateVisitorDetails(@PathVariable("visitorId") long id, @RequestBody Visitor visitors) throws RecordNotFoundException, DatabaseException
	{
		Visitor visitorDetails=service.updateVisitor(id, visitors);
		if(visitorDetails!=null)
		{
			return new ResponseEntity<Visitor>(visitorDetails,HttpStatus.OK);
		}
		  return new ResponseEntity<Visitor>(HttpStatus.NOT_ACCEPTABLE);
		
	}

}
