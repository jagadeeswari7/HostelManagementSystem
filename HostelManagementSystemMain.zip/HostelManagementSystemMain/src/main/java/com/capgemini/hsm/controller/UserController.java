package com.capgemini.hsm.controller;
/** This is a Controller class for User module 
 * 
 * @author Jagadeeswari's
 *
 */
import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.ApplicationException;
import com.capgemini.hsm.exception.DatabaseException;
import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.User;
import com.capgemini.hsm.service.UserService;

@RestController
@RequestMapping(path="Users")     // Map a specific request path or pattern onto a controller
public class UserController {
	
	@Autowired
	private UserService service;  // To establish a relationship with User service
	
	private static final Logger logger = LogManager.getLogger(UserController.class);
	
	/** This method adds User record in the database
	 *
	 * @param User
	 * @return User object
	 */
	
	
	@PostMapping("/")             
	public User addUser(@Valid @RequestBody User user) throws DuplicateRecordException {
		logger.info(" Start add user method in the controller!");
		return service.add(user);
	}
		
	/** This method updates User data in the database
     *
     * @param  UserId
     * @param  User
     * @return User object
     * @throws RecordNotFoundException 
     */
	
	
	@PutMapping("/updateUser/{userId}")  
	public ResponseEntity<User> updateUser(@Valid @RequestBody User user, @PathVariable("userId") long id) throws RecordNotFoundException{
		logger.info(" Start update user method in the controller!");
		User result = service.update(user,id);
		return ResponseEntity.ok(result);
	}
			
	/** This method deletes User record in the database
	 *
	 * @param  UserId
	 * @throws RecordNotFoundException 
	 */
	
	
	@DeleteMapping("/removeUser/{userId}")
	public ResponseEntity<Boolean> removeUser(@PathVariable("userId") long id) throws RecordNotFoundException {
		logger.info(" Start delete user method in the controller!");
		boolean result = service.delete(id);	
		return ResponseEntity.ok(result);
	}
	
	/** This method is to view User by Login
	 *
	 * @param  UserLogin
	 * @return User object
	 * @throws RecordNotFoundException 
	 */
	
	
	@GetMapping("/userLogin/{userLogin}")
	public ResponseEntity<User> findUserByLogin(@PathVariable("userLogin") String login) throws RecordNotFoundException {
		logger.info(" Start reading user by login method in the controller!");
		User user = service.findByLogin(login);
		return ResponseEntity.ok(user);
	}
	
	/** This method is to view User by Id
	 *
	 * @param  UserId
	 * @return User object
	 * @throws RecordNotFoundException 
	 */
	
	@GetMapping("/userId/{userId}")
	public ResponseEntity<User> findUserByPrimaryKey(@PathVariable("userId") long id) throws RecordNotFoundException {
		logger.info(" Start reading user by userId method in the controller!");
		User user = service.findByPk(id);
		return ResponseEntity.ok(user);
	}
	
	/** This method returns the list of User records in the database
	 *
	 * @return list of all Users
	 */
	
	@GetMapping("/getAllUsers")
	public List<User> readAllUsers(){
		logger.info("Start reading all user records method in the controller!");
		return service.searchAllUsers();
	}
	
	/** This method returns the response of authentication check
	 * 
     * @param  UserId
     * @param  User
     * @return User object
     * @throws RecordNotFoundException 
     * @throws ApplicationException 
	 */
	
	@PostMapping("/authentication")
	public ResponseEntity<User> authentication(@Valid @RequestBody User user) 
			                        throws RecordNotFoundException, ApplicationException{
		logger.info(" Start authentication check for user method in the controller!");
		User user2 = service.authenticate(user);
		return ResponseEntity.ok(user2);
	}
	
	/** This method registers a new user
	 *
	 * @param  User
	 * @return User object
	 * @throws DatabaseException 
	 * @throws RecordNotFoundException 
	 */
	
	@PostMapping("/register")
	public ResponseEntity<User> registeringUser( @RequestBody User user) throws DuplicateRecordException, DatabaseException{
		logger.info(" Start registering a new user method in the controller!");
		User newUser = service.registerUser(user);
		return ResponseEntity.ok(newUser);
	}
	
	/** This method is for changing password
	 * 
     * @param  UserId
     * @param  User
     * @return message
	 * @throws RecordNotFoundException 
	 * @throws ApplicationException 
	 */
	
	@PatchMapping("/changePassword/{id}")
	public ResponseEntity<String> changingPassword(@PathVariable("id") long id, @Valid @RequestBody User user) 
			                                       throws ApplicationException, RecordNotFoundException{
		logger.info(" Start changing password for the user method in the controller!");
		String mail = user.getMail();
		String newPassword = user.getPassword();
		boolean result = service.changePassword(id, mail, newPassword);
		if(result) { 
			return ResponseEntity.ok("Password Changed successfully!!");
		}else {
			return ResponseEntity.ok("Changing password is Failed!!");
		}
	}
	
	/** This method is for forget password
	 * 
     * @param  UserLogin
     * @return message
     * @throws RecordNotFoundException 
	 */
	@GetMapping("/forgetPassword/{login}")
	public ResponseEntity<String> forgetPassword(@PathVariable("login") String login) throws RecordNotFoundException{
		logger.info(" Start forget password for the user method in the controller!");
		String message = service.forgetPassword(login);
		return ResponseEntity.ok(message);
	}
	
}
