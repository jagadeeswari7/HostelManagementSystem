package com.capgemini.hsm.service;
/** The VisitorServiceImpl class provides access to repository methods to CRUD operations User details 
 * 
 * 
 * @author RamyaPriya's
 *
 */
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Visitor;
import com.capgemini.hsm.repository.VisitorDAO;

@Transactional
@Service
public class VisitorsServiceImpl implements VisitorService{
	
	@Autowired
	private VisitorDAO dao;
	
	private static final Logger logger = LogManager.getLogger(UserServiceImpl.class);

	public VisitorDAO getVisitorDao() {
		return dao;
	}

	public void setVisitorDao(VisitorDAO dao) {
		this.dao = dao;
	}

	@Override
	public Visitor addVisitor(Visitor visitor) throws DuplicateRecordException {
		logger.info(" Start add Visitor method in the service!");
		if(dao.existsById(visitor.getVisitorId())) {
			logger.error("The record already present..");
			throw new DuplicateRecordException("Duplicate Visitor Found");
		}
		dao.save(visitor);
		logger.info("Visitor Record Added Successfully...!");
		return visitor;
	}

	@Override
	public Visitor findVisitorByPK(long id) throws RecordNotFoundException {
		logger.info(" Start reading Visitor by visitorId method in the service!");
		Visitor visitor=dao.findByVisitorId(id);
		if(visitor!=null)
		{
			logger.info(" Retrieved Visitor by id successfully...!");
			return visitor;
		}
		else
		{
			logger.error("The visitors details with the given id is not present");
		 throw new RecordNotFoundException("The Visitor details does not excist for the id"+id);
		}
	}

	@Override
	public List<Visitor> searchVisitor() throws RecordNotFoundException {
		logger.info("Start reading all Visitor records method in the service!");
		List<Visitor> visitorList=dao.findAll();
		if(visitorList.isEmpty())
		{
			logger.error("The visitors details are not present");
			 throw new RecordNotFoundException("The Visitor details does not exist.");
		}
		else
			logger.info(" Retrieved all the users successfully...!");	
		return visitorList;
	}

	@Override
	public Visitor updateVisitor(long visitorId,Visitor entity) throws RecordNotFoundException {
		logger.info(" Start update Visitor method in the service!");
		Visitor visitors=dao.findByVisitorId(visitorId);
		if(visitors!=null)
		{			
			visitors.setName(entity.getName());
			visitors.setPurpose(entity.getPurpose());
			visitors.setRelation(entity.getRelation());
			visitors.setStudentName(entity.getStudentName());
			visitors.setAddress(entity.getAddress());
			dao.save(visitors);
			logger.info("Visitor Data Updated Successfully...!");
			return visitors;
	      	
	     }
		logger.error("The visitors details with the given id is not present");
		throw new RecordNotFoundException("Visitor not found for this id"+visitorId);
		
	}

	@Override
	public String deleteVisitor(long id) throws RecordNotFoundException {
		logger.info(" Start delete Visitor method in the service!");
		if(dao.existsById(id))
		{
			dao.deleteById(id);
			logger.info("Visitor Record Removed Successfully...!");
			return "Visitor details are deleted";
		}
		  logger.error("The visitors details with the given id is not present");
		 throw new RecordNotFoundException("The Visitor details does not excist for the id"+id);
	}

	@Override
	public List<Visitor> findVisitorByName(String name) throws RecordNotFoundException {
		logger.info(" Start reading Visitor by name method in the service!");
		List<Visitor> visitors=dao.findByName(name);
		if(!visitors.isEmpty())
		{
			logger.info(" Retrieved Visitor by Name successfully...!");
			return visitors;
		}
		 logger.error("The visitors details with the given name is not present");
		 throw new RecordNotFoundException("The Visitor details does not exist for the name"+name);
	}


}
