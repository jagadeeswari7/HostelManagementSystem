package com.capgemini.hsm.controller;
/** This is a Controller class for Allotment module 
 * 
 * @author Maneesha's
 *
 */
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Allotment;
import com.capgemini.hsm.service.AllotmentService;

@RestController
@RequestMapping(path="Allotment") // Map a specific request path or pattern onto a controller
public class AllotmentController {
	@Autowired
	private AllotmentService service;// To establish a relationship with Allotment service

	/** This method adds allotment record in the database
	 *
	 * @param Allotment User
	 * @return User object
	 */
	
	@PostMapping
	public ResponseEntity<Allotment> addAllotment( @Valid @RequestBody Allotment entity) throws DuplicateRecordException {
		Allotment result = service.add(entity);
		ResponseEntity<Allotment> response;
		if(result!=null) {
			response = new ResponseEntity<Allotment>(result,HttpStatus.CREATED);
		}else {
			response = new ResponseEntity<Allotment>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;	
	}  
	
	/** This method is to view Allotment Users by Name
	 *
	 * @param  AllotmentName
	 * @return User object
	 * @throws RecordNotFoundException 
	 */
	
	@GetMapping("/AllotmentName/{AllotmentName}")
	private ResponseEntity<List<Allotment>> getallotmentByName(@PathVariable("AllotmentName") String name) throws RecordNotFoundException{
		List<Allotment> app=service.findAllotmentByName(name);
		if(app.isEmpty()) {
			return new ResponseEntity<List<Allotment>>(HttpStatus.NOT_FOUND) ;
		}
		else {
			return new ResponseEntity<List<Allotment>>(app,HttpStatus.OK) ;
		}
		
	}
	
	/** This method is to view Allotment by Id
	 *
	 * @param  AllotmentId
	 * @return Allotment object
	 * @throws RecordNotFoundException 
	 */
	
	@GetMapping("/AllotmentId/{AllotmentId}")  
	private ResponseEntity<Allotment> getallotmentByID(@PathVariable("AllotmentId") long allotmentId) throws RecordNotFoundException 
	{ 
		Allotment allotment= service.findByPk(allotmentId);
		if(allotment!=null) {
			return new ResponseEntity<Allotment>(allotment,HttpStatus.OK);
		}
		return new ResponseEntity<Allotment>(HttpStatus.NOT_FOUND);
	}

	/** This method updates Allotment Record Data in the database
    *
    * @param  AllotmentId
    * @param  Allotment
    * @return Allotment User object
    * @throws RecordNotFoundException 
    */
	
	@PutMapping("{AllotmentId}")  
	public ResponseEntity<Allotment> update(@PathVariable("AllotmentId") long id, @RequestBody Allotment allotment) throws RecordNotFoundException{   
	{ 
		Allotment sample =service.update(id,allotment);
		  if (sample != null) 
			  return new ResponseEntity<Allotment>(sample,HttpStatus.OK);
		  
		  return new ResponseEntity<Allotment>( HttpStatus.NOT_FOUND);
		}
	}
	
	/** This method deletes Allotment record in the database
	 *
	 * @param  AllotmentId
	 * @throws RecordNotFoundException 
	 */
	
	@DeleteMapping("{AllotmentId}")  
	private ResponseEntity<String> deleteAllotmentByID(@PathVariable("AllotmentId") long id) throws RecordNotFoundException 
	{  
			if(service.delete(id)) {
				return new ResponseEntity<String>("Allotment is deleted",HttpStatus.OK);
			}
			else {
				return new ResponseEntity<String>("Allotment not found",HttpStatus.NOT_FOUND);
			}	
	}  
	
	/** This method returns the list of Allotment records in the database
	 *
	 * @return list of all Allotments
	 */
	
	@GetMapping
	private ResponseEntity<List<Allotment>> getDetailsOfAllAllotments()  
	{  
		List<Allotment> app=service.searchAllAllotedUsers();
		if(app.isEmpty()) {
			return new ResponseEntity<List<Allotment>>(HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
		else {
			return new ResponseEntity<List<Allotment>>(app,HttpStatus.OK) ;
		}
	}  
}


