package com.capgemini.hsm.controller;
/** This is a Controller class for Fee module 
 * 
 * @author Deepthi's
 *
 */
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Fee;
import com.capgemini.hsm.service.FeeService;

@RestController
@RequestMapping(path="Fee")// Map a specific request path or pattern onto a controller
public class FeeController {
	
	@Autowired
	private FeeService service;// To establish a relationship with Fee service
	
	/** This method adds Fee record in the database
	 *
	 * @param Fee
	 * @return Fee object
	 */
	
	@PostMapping
	public ResponseEntity<Fee> addFee( @Valid @RequestBody Fee entity) throws DuplicateRecordException {
		Fee result = service.add(entity);
		ResponseEntity<Fee> response;
		if(result!=null) {
			response = new ResponseEntity<Fee>(result,HttpStatus.CREATED);
		}else {
			response = new ResponseEntity<Fee>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	/** This method updates Room data in the database
    *
    * @param  FeeId
    * @param  Fee
    * @return Fee object
    * @throws RecordNotFoundException 
    */
	
	@PutMapping("/Update/{feeId}")
	public ResponseEntity<?> updateFee(@RequestBody Fee fee, @PathVariable("feeId") long feeId) throws RecordNotFoundException 
	{
		service.update(fee, feeId);
		return ResponseEntity.ok("Fee has been updated successfully");	
	}
	
	/** This method deletes Fee record in the database
	 *
	 * @param  FeeId
	 * @throws RecordNotFoundException 
	 */
	
	@DeleteMapping("{feeId}")
	public ResponseEntity<?> removeRoom(@PathVariable("feeId") long feeId) throws RecordNotFoundException
	{
	   service.delete(feeId);
	   return ResponseEntity.ok("Fee has been deleted successfully");	
	}
	
	/** This method is to view Fee by Name
	 *
	 * @param  FeeId
	 * @return Fee object
	 * @throws RecordNotFoundException 
	 */
	
	@GetMapping("/GetName/{name}")
	public ResponseEntity<List<Fee>> getDetailsByName(@PathVariable("name") String name) throws RecordNotFoundException
	{
		List<Fee> fee= service.findByName(name);
		if(fee.isEmpty())
			return new ResponseEntity<List<Fee>>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<List<Fee>>(fee,HttpStatus.OK);	
	}
	
	/** This method is to view Fee by Id
	 *
	 * @param  FeeId
	 * @return Fee object
	 * @throws RecordNotFoundException 
	 */
	
	@GetMapping("/feeId/{feeId}")
	public ResponseEntity<Fee> getDetailsByPk(@PathVariable("feeId") long feeId) throws RecordNotFoundException
	{
		Fee result = service.findByPk(feeId);
		if(result!=null)
			 return new ResponseEntity<Fee>(result,HttpStatus.OK);
		   return new ResponseEntity<Fee>(HttpStatus.INTERNAL_SERVER_ERROR);	   		
	}
	
	/** This method returns the list of fee records in the database
	 *
	 * @return list of all fees
	 */
	
	@GetMapping("/Search")
	public ResponseEntity<List<Fee>> searchDetails()
	{
		List<Fee> feeList=service.search();
		if(feeList.isEmpty())
			return new ResponseEntity<List<Fee>>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<List<Fee>>(feeList,HttpStatus.OK);	
	}
	
	
}
