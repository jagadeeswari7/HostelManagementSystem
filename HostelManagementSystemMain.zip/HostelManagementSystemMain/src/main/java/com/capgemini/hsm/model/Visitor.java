package com.capgemini.hsm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Visitors")
public class Visitor implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "VISITOR_ID")
	private long visitorId;
	
	@Column(name = "NAME")
	@NotBlank
	@Size(min=3,max=30,message="The length of name should be between 3 and 30 characters")
	private String name;
	
	@Column(name = "CONTACT_NO")
	@NotBlank
	private String contactNo;
	
	@Column(name = "STUDENT_NAME")
	@NotBlank
	@Size(min=3,max=30,message="The length of student name should be between 3 and 30 characters")
	private String studentName;
	
	@Column(name = "ADDRESS")
	@NotBlank(message="The address must not be empty")
	private String address;
	
	
	@Column(name = "RELATION")
	@NotBlank(message="The relation is not entered")
	private String relation;
	
	@Column(name = "PURPOSE")
	@NotBlank(message="The purpose must be mentioned")
	private String purpose;
	
	@ManyToOne
	@JoinColumn(name="WARDEN_ID")
    private Warden wardens;
	
	public Warden getWardens() {
		return wardens;
	}

	public void setWardens(Warden wardens) {
		this.wardens = wardens;
	}

	public Visitor(long visitorId, String name, String contactNo, String studentName, String address, String relation,
			String purpose) {
		super();
		this.visitorId = visitorId;
		this.name = name;
		this.contactNo = contactNo;
		this.studentName = studentName;
		this.address = address;
		this.relation = relation;
		this.purpose = purpose;
	}
	
	public Visitor() {
		
	}

	public long getVisitorId() {
		return visitorId;
	}
	public void setVisitorId(long visitorId) {
		this.visitorId = visitorId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	@Override
	public String toString() {
		return "Visitor [visitorId=" + visitorId + ", name=" + name + ", contactNo=" + contactNo + ", studentName="
				+ studentName + ", address=" + address + ", relation=" + relation + ", purpose=" + purpose
				+ ", wardens=" + wardens.getWardenId() + "]";
	}
	
	
}
