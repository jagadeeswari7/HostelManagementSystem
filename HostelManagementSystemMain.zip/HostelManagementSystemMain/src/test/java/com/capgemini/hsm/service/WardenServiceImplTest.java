package com.capgemini.hsm.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Warden;
import com.capgemini.hsm.repository.WardenDAO;
@RunWith(SpringRunner.class)
@SpringBootTest
class WardenServiceImplTest {
	@Autowired
	private WardenService service;
	
	@MockBean
	private WardenDAO dao;
	
	@Test
	void testAddWardenShouldAddWardenDataToDatabase() throws DuplicateRecordException {
		Warden warden = new Warden(2L,"Adam","warden2");
		when(dao.save(warden)).thenReturn(warden);
		Warden result = service.addWarden(warden);
		assertEquals(result.getWardenId(), warden.getWardenId());
	}
	@Test
	void testRemoveWardenShouldDeleteEmployeeDataToDatabase() throws RecordNotFoundException{
		Warden warden = new Warden(2L,"Adam","warden2");
		when(dao.existsById(warden.getWardenId())).thenReturn(true);
		boolean result = service.deleteWarden(warden.getWardenId());
		assertTrue(result);
	}
		@Test
		void testFindAllTheWardensInTheDatabase() {
			Warden warden = new Warden(2L,"Adam","warden2");
			List<Warden> wardenList = new ArrayList<>();
			wardenList.add(warden);
			when(dao.findAll()).thenReturn(wardenList);
			List<Warden> result = service.searchAllWardens();
			assertEquals(result.size(),wardenList.size());	
			assertNotNull(result);
	
}
		@Test
		void testFindByNameShouldFindNameFromDatabase() throws RecordNotFoundException{

			Warden warden = new Warden(2L,"Adam","warden2");
			List<Warden>wardenList=new ArrayList<>();
			wardenList.add(warden);
			when(dao.findByName("Adam")).thenReturn(wardenList);
			List<Warden> result = service.findByWardenName("Adam");
			assertEquals(wardenList,result);
		}
		@Test
		void testFindWardenByWardenIdFromTheDatabase() throws RecordNotFoundException{
			Warden warden = new Warden(2L,"Adam","warden2");
			when(dao.findBywardenId(2L)).thenReturn(warden);
			Warden result = service.findByPk(warden.getWardenId());
			assertEquals(result.getWardenId(),warden.getWardenId());
		}
		
		@Test
		void testUpdateWardenShouldUpdateWardenDataToDatabase()throws RecordNotFoundException{
		Warden warden = new Warden(2L,"Adam","warden2");
		warden.setName("John");
		when(dao.findBywardenId(2L)).thenReturn(warden);
		Warden updateWarden=service.updateWarden(warden, 2L);
		assertEquals(updateWarden.getWardenId(),warden.getWardenId());
		assertEquals(updateWarden.getName(),warden.getName());
		}
}
	
