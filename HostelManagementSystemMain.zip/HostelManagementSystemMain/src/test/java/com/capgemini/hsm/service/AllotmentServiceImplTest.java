package com.capgemini.hsm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Allotment;
import com.capgemini.hsm.repository.AllotmentDAO;

@RunWith(SpringRunner.class)
@SpringBootTest
class AllotmentServiceImplTest {

	@Autowired
	private AllotmentService service;
	
	@MockBean
	private AllotmentDAO dao;
	
	@Test
	void testAddAllotmentFormShouldAddUserDataToDatabase() throws DuplicateRecordException  {
	    Allotment allotForm = new Allotment(1L, 1L, "A-Deg", 1L, "John");
		Allotment userToBeAdded = service.add(allotForm);
		assertEquals(userToBeAdded.getUserId(), allotForm.getUserId());
	}
	
	@Test
	void testUpdateAllotmentFormShouldUpdateUserDataToDatabase() throws RecordNotFoundException {
		Allotment allotForm = new Allotment(1L, 1L, "A-Deg", 1L, "John");
		when(dao.findByAllotId(1L)).thenReturn(allotForm);
		allotForm.setHostelId(2L);	
		allotForm.setHostelName("B-Deg");
		allotForm.setUserId(2L);
		allotForm.setName("Aman");
		Allotment updatedAllotedForm = service.update(1L, allotForm);
		assertEquals(updatedAllotedForm.getUserId(),allotForm.getUserId());
	}
	
	@Test
	void testRemoveAllotmentFormShouldDeleteUserDataToDatabase() throws RecordNotFoundException{
		Allotment allotForm = new Allotment(1L, 1L, "A-Deg", 1L, "John");
		when(dao.existsById(allotForm.getUserId())).thenReturn(true);
		boolean result = service.delete(allotForm.getUserId());
		assertTrue(result);
	}
	
	@Test
	void testFindUserByUserLoginFromTheDatabase() throws RecordNotFoundException{
		Allotment allotForm = new Allotment(1L, 1L, "A-Deg", 1L, "John");
		List<Allotment> allotedNameList = new ArrayList<>();
		allotedNameList.add(allotForm);
		when(dao.findByName("John")).thenReturn(allotedNameList);
		List<Allotment> result = service.findAllotmentByName(allotForm.getName());
		assertEquals(result.size(),allotedNameList.size());
	}
	
	@Test
	void testFindUserByUserIdFromTheDatabase() throws RecordNotFoundException{
		Allotment allotForm = new Allotment(1L, 1L, "A-Deg", 1L, "John");
		when(dao.findByAllotId(1L)).thenReturn(allotForm);
		Allotment result = service.findByPk(allotForm.getUserId());
		assertEquals(result.getUserId(),allotForm.getUserId());
	}
	
	@Test
	void testFindAllTheUsersInTheDatabase(){
		Allotment allotForm = new Allotment(1L, 1L, "A-Deg", 1L, "John");
		List<Allotment> allotedUserList = new ArrayList<>();
		allotedUserList.add(allotForm);
		when(dao.findAll()).thenReturn(allotedUserList);
		List<Allotment> result = service.searchAllAllotedUsers();
		assertEquals(result.size(),allotedUserList.size());	
		assertNotNull(result);
	}
	
}
