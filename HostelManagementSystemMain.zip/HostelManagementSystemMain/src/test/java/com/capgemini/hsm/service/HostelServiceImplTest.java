package com.capgemini.hsm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Hostel;
import com.capgemini.hsm.repository.HostelDAO;
@RunWith(SpringRunner.class)
@SpringBootTest
class HostelServiceImplTest {
	@Autowired
	private HostelService service;
	
	@MockBean
	private HostelDAO dao;
	
	@Test
	void testAddHostelShouldAddDataToDatabase() throws DuplicateRecordException {
		Hostel hostel= new Hostel(1L, "John", "XYZ", "9886750243", "Tirupati", "ABC",  "45000");
		when(dao.save(hostel)).thenReturn(hostel);
		Hostel result = service.add(hostel);
		assertEquals(result.getHostelId(), hostel.getHostelId());
	}

	  @Test 
	  void testUpdateTheHostelDetailsInDatabaseOrNot() throws  RecordNotFoundException{ 
	  Hostel hostel = new Hostel(1L, "John", "XYZ", "9886750243", "Tirupati", "ABC", "45000");
	  hostel.setHostelId(1L); 
	  hostel.setName("Sharma"); 
	  hostel.setType("RTC");
	  hostel.setContact("1234567890"); 
	  hostel.setAddress("Hyd");
	  hostel.setDescription("SDF"); 
	  hostel.setFee("56000");
	  when(dao.findByHostelId(1L)).thenReturn(hostel); 
	  Hostel updatedHostel = service.update(1L,hostel);
	  assertEquals(updatedHostel.getHostelId(),hostel.getHostelId());
	  assertEquals(updatedHostel.getName(),hostel.getName());  
	  }
	 
	@Test
	void testDeleteHostelShouldDeleteDataToDatabase() throws RecordNotFoundException {
		Hostel hostel = new Hostel(1L, "John", "XYZ", "9886750243", "Tirupati", "ABC",  "45000" );
		when(dao.existsById(hostel.getHostelId())).thenReturn(true);
		boolean result = service.delete(hostel.getHostelId());
		assertTrue(result);
	}
	
	@Test
	void testFindHostelByNamePresentInDatabaseOrNot() throws RecordNotFoundException {
         Hostel hostel = new Hostel(1L, "John", "XYZ", "9886750243", "Tirupati", "ABC",  "45000");
         List<Hostel> hostelList = new ArrayList<Hostel>();
 		hostelList.add(hostel);
 		when(dao.findByName("XYZ")).thenReturn(hostelList);
		List<Hostel> result = service.findByName("XYZ");
		assertEquals(result.size(),hostelList.size());	
		assertNotNull(result);
	}
	
	
	@Test 
	void testFindByPkPresentInDatabaseOrNot() throws RecordNotFoundException {		  
          Hostel hostel = new Hostel(1L, "John", "XYZ", "9886750243", "Tirupati", "ABC",  "45000" );	  
		  when(dao.findByHostelId(1L)).thenReturn(hostel);
		  Hostel result = service.findByPk(1L);
		  assertEquals(hostel.getHostelId(),result.getHostelId());
	}
	
	@Test
	void testFindAllTheHostelsInTheDatabase(){
		Hostel hostel = new Hostel(1L, "John", "XYZ", "9886750243", "Tirupati", "ABC",  "45000");
		List<Hostel> hostelList = new ArrayList<>();
		hostelList.add(hostel);
		when(dao.findAll()).thenReturn(hostelList);
		List<Hostel> result = service.search();
		assertEquals(result.size(),hostelList.size());	
		assertNotNull(result);
	}
	
	
	}
