package com.capgemini.hsm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.capgemini.hsm.exception.DatabaseException;
import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Application;
import com.capgemini.hsm.repository.ApplicationDAO;
@RunWith(SpringRunner.class)
@SpringBootTest
class ApplicationServiceImplTest {
	@Autowired
	private ApplicationService service;
	
	@MockBean
	private ApplicationDAO dao;
	
	
	@Test
	void testAddApplicationShouldAddApplicationDataToDatabase() throws DuplicateRecordException{
		Application application = new Application(1L, "John", "abc", "highschool", "password12","student");
		when(dao.save(application)).thenReturn(application);
		Application applicationToBeAdded = service.add(application);
		assertEquals(applicationToBeAdded.getApplicationId(), application.getApplicationId());
	}
	
	@Test 
    void testUpdateApplicationShouldUpdateApplicationDataToDatabase() throws RecordNotFoundException, DatabaseException{
	  Application application = new Application(1L, "John", "abc", "highschool","password12","student");
	  application.setName("Karn");
	  application.setHostelName("def");
	  application.setQualification("pg");
	  application.setAddress("mainroad");
	  application.setDescription("students");
	  when(dao.findByApplicationId(1L)).thenReturn(application); 
	  Application updatedApplication = service.update(application,1L);
	  assertEquals(updatedApplication.getApplicationId(),application.getApplicationId());
	  assertEquals(updatedApplication.getName(),application.getName());
	  assertEquals(updatedApplication.getQualification(),application.getQualification());
	  assertEquals(updatedApplication.getAddress(),application.getAddress());
	  assertEquals(updatedApplication.getDescription(),application.getDescription());
	  }

	 @Test 
	 void testDeleteApplicationShouldDeleteApplicationDataToDatabase() throws RecordNotFoundException, DatabaseException{ 
      Application application =new Application(1L, "John", "abc", "highschool", "password12","student");
	  when(dao.existsById(application.getApplicationId())).thenReturn(true);
	  boolean result = service.delete(application.getApplicationId());
	  assertTrue(result); 
	  }
	 
	  @Test
	  void testFindApplicationByApplicationIdFromTheDatabase() throws RecordNotFoundException{	  
		  Application application = new Application(1L, "John", "abc", "highschool", "password12","student");		  
		  when(dao.findByApplicationId(1L)).thenReturn(application);
		  Application result = service.findApplicationByPk(application.getApplicationId());		  
		  assertEquals(result.getApplicationId(),application.getApplicationId());	
	   }
	  
	  @Test
	  void testFindByNameShouldShouldFindNameFromDatabase() throws RecordNotFoundException{
		    Application application = new Application(1L, "John", "abc", "highschool", "password12","student");
		    List<Application> applicationList = new ArrayList<>();
			applicationList.add(application);
			when(dao.findByName("John")).thenReturn(applicationList);
			List<Application> result = service.findApplicationByName("John");
			assertEquals(applicationList,result);	
	  }
	  
	    @Test
		void testFindAllTheApplicationsInTheDatabase(){
		    Application application = new Application(1L, "John", "abc", "highschool", "password12","student");
			List<Application> applicationList = new ArrayList<>();
			applicationList.add(application);
			when(dao.findAll()).thenReturn(applicationList);
			List<Application> result = service.search();
			assertEquals(result.size(),applicationList.size());	
			assertNotNull(result);
		 }
	  
	 
	
	
}