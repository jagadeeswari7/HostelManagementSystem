package com.capgemini.hsm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Visitor;
import com.capgemini.hsm.repository.VisitorDAO;
@RunWith(SpringRunner.class)
@SpringBootTest

class VisitorsServiceImplTest {
   
	@Autowired
    private VisitorService service;
	
	@MockBean
	private VisitorDAO dao;


	@Test
	void testAddVisitorDetailsToDataBase() throws DuplicateRecordException {
		Visitor visitor=new Visitor(450L,"Renuga","9445351137","srini","Coimbatore","relative","unOfficial");
		when(dao.save(visitor)).thenReturn(visitor);
		Visitor visitor1=service.addVisitor(visitor);
		assertEquals(visitor.getVisitorId(),visitor1.getVisitorId());
	}
	@Test
	void testFindByPkPresentInDatabaseOrNot() throws RecordNotFoundException
	{
		Visitor visitor=new Visitor(450L,"Renuga","9445351137","srini","Coimbatore","relative","unOfficial");
		when(dao.findByVisitorId(450L)).thenReturn(visitor);
		Visitor visitor2=service.findVisitorByPK(450L);
		assertEquals(visitor.getVisitorId(),visitor2.getVisitorId());
	}
	
	@Test
	void testUpdateTheVisitorDetailsInDatabaseOrNot() throws RecordNotFoundException
	{
		Visitor visitor=new Visitor(450L,"Renuga","9445351137","srini","Coimbatore","relative","unOfficial");
		visitor.setName("RamGopal");
		visitor.setRelation("Brother");
		visitor.setStudentName("Ramnath");
		visitor.setAddress("Kerala");
		visitor.setPurpose("Official");
		when(dao.findByVisitorId(450L)).thenReturn(visitor);
		Visitor visitors=service.updateVisitor(450L, visitor);
		assertEquals(visitor.getVisitorId(),visitors.getVisitorId());
	}
	
	@Test
	public void testVisitorIsDeletingOrNot() throws RecordNotFoundException {
		Visitor visitorToRemove=new Visitor(450L,"Renuga","9445351137","srini","Coimbatore","relative","unOfficial");
	    when(dao.existsById(visitorToRemove.getVisitorId())).thenReturn(true);
	    assertEquals("Visitor details are deleted",service.deleteVisitor(450L));
	}
	
	@Test
	void testFindVisitorByNamePresentInDatabaseOrNot() throws RecordNotFoundException
	{
		Visitor visitor=new Visitor(450L,"Renuga","9445351137","srini","Coimbatore","relative","unOfficial");
		List<Visitor> visitorsList=new ArrayList<Visitor>();
		visitorsList.add(visitor);
		when(dao.findByName("Deva")).thenReturn(visitorsList);
		List<Visitor> visitorList=service.findVisitorByName("Deva");
		assertEquals(visitorsList.size(),visitorList.size());
		assertNotNull(visitorList);
	}
	
	@Test
	public void testSearchAllVisitorsPresentInDatabase() throws RecordNotFoundException
	{
		Visitor visitor=new Visitor(450L,"Renuga","9445351137","srini","Coimbatore","relative","unOfficial");
		List<Visitor> visitorsList=new ArrayList<Visitor>();
		visitorsList.add(visitor);
		when(dao.findAll()).thenReturn(visitorsList);
		List<Visitor> visitorList=service.searchVisitor();
		assertEquals(visitorsList.size(),visitorList.size());
		assertNotNull(visitorList);
	}
	


}
