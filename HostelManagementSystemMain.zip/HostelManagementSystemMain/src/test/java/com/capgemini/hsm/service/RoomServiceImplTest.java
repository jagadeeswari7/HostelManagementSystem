package com.capgemini.hsm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Room;
import com.capgemini.hsm.repository.RoomDAO;
@RunWith(SpringRunner.class)
@SpringBootTest
class RoomServiceImplTest {
	@Autowired
	private RoomService service;
	
	@MockBean
	private RoomDAO dao;
	
	@Test
	void testAddRoomShouldAddDataToDatabase() throws DuplicateRecordException{
		Room room = new Room(1L,"room1","XXX");
		when(dao.save(room)).thenReturn(room);
		Room result = service.add(room);
		assertEquals(result.getRoomId(), room.getRoomId());			
	}
	
	@Test
	void testUpdateUserShouldUpdateUserDataToDatabase() throws RecordNotFoundException{	
		Room room = new Room(1L,"room1","XXX");
		room.setName("Room2");
    	room.setDescription("General");
		when(dao.findByRoomId(1234L)).thenReturn(room);
		Room updatedRoom = service.update(room,1234L);
		assertEquals(updatedRoom.getRoomId(),room.getRoomId());
		assertEquals(updatedRoom.getName(),room.getName());
	}
	
	@Test
	void testDeleteRoomShouldDeleteDataToDatabase() throws RecordNotFoundException{
		Room room = new Room(1L,"room1","XXX");
		when(dao.existsById(room.getRoomId())).thenReturn(true);
		boolean result = service.delete(room.getRoomId());
		assertTrue(result);
	}
	
	@Test
	void testFindByNameShouldFindNameFromDatabase() throws RecordNotFoundException{
		Room room1 = new Room(1L,"room1","XXX");
		Room room2 = new Room(1L,"room2","XXX");
		List<Room> roomList = new ArrayList<>();
		roomList.add(room1);
		roomList.add(room2);
		when(dao.findByName("room1")).thenReturn(roomList);
		List<Room> result = service.findByName("room1");
		assertEquals(roomList,result);
	}
	
	@Test
	void testFindAllTheUsersInTheDatabase(){		
		Room room = new Room(1L,"room1","XXX");
		List<Room> roomList = new ArrayList<>();
		roomList.add(room);
		when(dao.findAll()).thenReturn(roomList);
		List<Room> result = service.search();
		assertEquals(result.size(),roomList.size());	
		assertNotNull(result);
	}
	
	@Test
	void testFindRoomByRoomIdFromTheDatabase() throws RecordNotFoundException{
		Room room = new Room(1L,"room1","XXX");
		when(dao.findByRoomId(1L)).thenReturn(room);
		Room result = service.findByPk(room.getRoomId());
		assertEquals(result.getRoomId(),room.getRoomId());
	}

}
