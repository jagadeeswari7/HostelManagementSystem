package com.capgemini.hsm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.capgemini.hsm.exception.ApplicationException;
import com.capgemini.hsm.exception.DatabaseException;
import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.User;
import com.capgemini.hsm.repository.UserDAO;
@RunWith(SpringRunner.class)
@SpringBootTest
class UserServiceImplTest {
	@Autowired
	private UserService service;
	
	@MockBean
	private UserDAO dao;
	
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
	
	@Test
	void testAddUserShouldAddUserDataToDatabase() throws DuplicateRecordException, ParseException {
		Date date = simpleDateFormat.parse("2000-12-12");
		User user = new User(1L, "John", "smith", "student1", "password12", "password12", date, "john99@gmail.com", "9000836362", "Female", "pic");
		when(dao.save(user)).thenReturn(user);
		User userToBeAdded = service.add(user);
		assertEquals(userToBeAdded.getUserId(), user.getUserId());
	}
	
	@Test
	void testUpdateUserShouldUpdateUserDataToDatabase() throws ParseException, RecordNotFoundException, DatabaseException{
		Date date = simpleDateFormat.parse("2018-09-09");
		User user = new User(1L, "John", "Smith", "student1", "password12", "password12", date, "john99@gmail.com", "9000836362", "Female", "pic");
		when(dao.findByUserId(1L)).thenReturn(user);
		user.setFirstName("Aman");
		user.setLastName("Mathur");
		user.setDob(simpleDateFormat.parse("2000-12-12"));
		user.setMail("aman99@gmail.com");
		user.setMobileNo("7013661522");
		user.setGender("MALE");	
		User updatedUser = service.update(user, 1L);
		assertEquals(updatedUser.getUserId(),user.getUserId());
	}
	
	@Test
	void testRemoveUserShouldDeleteUserDataToDatabase() throws RecordNotFoundException, ParseException{
		Date date = simpleDateFormat.parse("2018-09-09");
		User user = new User(1L, "John", "smith", "student1", "password12", "password12", date, "john99@gmail.com", "9000836362", "Female", "pic");
		when(dao.existsById(user.getUserId())).thenReturn(true);
		boolean result = service.delete(user.getUserId());
		assertTrue(result);
	}
	
	@Test
	void testFindUserByUserLoginFromTheDatabase() throws RecordNotFoundException, ParseException{
		Date date = simpleDateFormat.parse("2018-09-09");
		User user = new User(1L, "John", "smith", "student1", "password12", "password12", date, "john99@gmail.com", "9000836362", "Female", "pic");
		when(dao.findByLogin("student1")).thenReturn(user);
		User result = service.findByLogin(user.getLogin());
		assertEquals(result.getUserId(),user.getUserId());
	}
	
	@Test
	void testFindUserByUserIdFromTheDatabase() throws RecordNotFoundException, ParseException{
		Date date = simpleDateFormat.parse("2018-09-09");
		User user = new User(1L, "John", "smith", "student1", "password12", "password12", date, "john99@gmail.com", "9000836362", "Female", "pic");
		when(dao.findByUserId(1L)).thenReturn(user);
		User result = service.findByPk(user.getUserId());
		assertEquals(result.getUserId(),user.getUserId());
	}
	
	@Test
	void testFindAllTheUsersInTheDatabase() throws ParseException{
		Date date = simpleDateFormat.parse("2018-09-09");
		User user = new User(1L, "John", "smith", "student1", "password12", "password12", date, "john99@gmail.com", "9000836362", "Female", "pic");
		List<User> userList = new ArrayList<>();
		userList.add(user);
		when(dao.findAll()).thenReturn(userList);
		List<User> result = service.searchAllUsers();
		assertEquals(result.size(),userList.size());	
		assertNotNull(result);
	}
	
	@Test
	void testAuthenticationProcessCheckForTheUserInTheDatabase() throws ParseException, RecordNotFoundException, ApplicationException{
		Date date = simpleDateFormat.parse("2018-09-09");
		User user = new User(1L, "John", "smith", "student1", "password12", "password12", date, "john99@gmail.com", "9000836362", "Female", "pic");
		when(dao.findByUserId(1L)).thenReturn(user);
        User result = service.authenticate(user);
        assertEquals(user.getLogin(),result.getLogin());
        assertEquals(user.getPassword(),result.getPassword());
	}
	
	@Test
	void testChangingPasswordForTheUserInTheDatabase() throws ParseException, ApplicationException, RecordNotFoundException{
		Date date = simpleDateFormat.parse("2018-09-09");
		User user = new User(1L, "John", "smith", "student1", "password12", "password12", date, "john99@gmail.com", "9000836362", "Female", "pic");
		when(dao.findByUserId(1L)).thenReturn(user);
        boolean result = service.changePassword(user.getUserId(), user.getMail(), user.getPassword());
        assertTrue(result);
	}
	
	@Test
	void testRegisteringNewUserInTheDatabase() throws ParseException, DuplicateRecordException, DatabaseException{
		Date date = simpleDateFormat.parse("2018-09-09");
		User user = new User(1L, "John", "smith", "student1", "password12", "password12", date, "jagadeeswari.bolli99@gmail.com", "9000836362", "Female", "pic");
		when(dao.existsById(1L)).thenReturn(false);
        User result = service.registerUser(user);
        assertEquals(user.getUserId(),result.getUserId());
	}
	
	@Test
	void testForgetPasswordForTheUserInTheDatabase() throws ParseException, RecordNotFoundException{
		Date date = simpleDateFormat.parse("2018-09-09");
		User user = new User(1L, "John", "smith", "student1", "password12", "password12", date, "john99@gmail.com", "9000836362", "Female", "pic");
		when(dao.findByLogin("student1")).thenReturn(user);
		String result = service.forgetPassword(user.getLogin());
		assertEquals(result,user.getPassword());
	}
	
}
