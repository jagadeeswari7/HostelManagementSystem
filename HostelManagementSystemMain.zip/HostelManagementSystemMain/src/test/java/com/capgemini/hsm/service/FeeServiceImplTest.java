package com.capgemini.hsm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Fee;
import com.capgemini.hsm.repository.FeeDAO;
@RunWith(SpringRunner.class)
@SpringBootTest
class FeeServiceImplTest {
	@Autowired
	private FeeService service;
	
	@MockBean
	private FeeDAO dao;
	
	@Test
	void testAddFeeShouldAddDataToDatabase() throws DuplicateRecordException{
		Fee fee = new Fee(2L, "fee1", 3L, "hostel1", "10000", "XXX", "6000", "4000", 4L);
		when(dao.save(fee)).thenReturn(fee);
		Fee result = service.add(fee);
		assertEquals(result.getFeeId(), fee.getFeeId());			
	}

	@Test
	void testUpdateUserShouldUpdateUserDataToDatabase() throws RecordNotFoundException{	
		Fee fee = new Fee(2L, "fee1", 3L, "hostel1", "10000", "XXX", "6000", "4000", 4L);
		fee.setName("fee2");
    	fee.setHostelName("hostel2");
    	fee.setTotalfee("100");
    	fee.setPaidfee("60");
    	fee.setRemainingfee("40");
		when(dao.findByFeeId(2L)).thenReturn(fee);
		Fee updatedFee = service.update(fee,2L);
		assertEquals(updatedFee.getFeeId(),fee.getFeeId());
		assertEquals(updatedFee.getName(),fee.getName());
	}
	
	@Test
	void testDeleteFeeShouldDeleteDataToDatabase() throws RecordNotFoundException{
		Fee fee = new Fee(2L, "fee1", 3L, "hostel1",  "10000", "XXX", "6000", "4000", 4L);
		when(dao.existsById(fee.getFeeId())).thenReturn(true);
		boolean result = service.delete(fee.getFeeId());
		assertTrue(result);
	}
	
	@Test
	void testFindByNameShouldFindNameFromDatabase() throws RecordNotFoundException{
		Fee fee1 = new Fee(2L, "fee1", 3L, "hostel1", "10000", "XXX", "6000", "4000", 4L);
		Fee fee2 = new Fee(3L, "fee4", 3L, "hostel1", "10000", "XXX", "6000", "4000", 4L);
		List<Fee> feeList = new ArrayList<>();
		feeList.add(fee1);
		feeList.add(fee2);
		when(dao.findByName("fee4")).thenReturn(feeList);
		List<Fee> result = service.findByName("fee4");
		assertEquals(feeList,result);
	}
	
	@Test
	void testFindAllTheUsersInTheDatabase(){		
		Fee fee = new Fee(2L, "fee1", 3L, "hostel1", "10000", "XXX", "6000", "4000", 4L);
		List<Fee> feeList = new ArrayList<>();
		feeList.add(fee);
		when(dao.findAll()).thenReturn(feeList);
		List<Fee> result = service.search();
		assertEquals(result.size(),feeList.size());	
		assertNotNull(result);
	}
	
	@Test
	void testFindFeeByFeeIdFromTheDatabase() throws RecordNotFoundException{
		Fee fee = new Fee(2L, "fee1", 3L, "hostel1", "10000", "XXX", "6000", "4000", 4L);
		when(dao.findByFeeId(2L)).thenReturn(fee);
		Fee result = service.findByPk(fee.getFeeId());
		assertEquals(result.getFeeId(),fee.getFeeId());
	}


}
