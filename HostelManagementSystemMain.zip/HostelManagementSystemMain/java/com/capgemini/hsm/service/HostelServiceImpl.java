package com.capgemini.hsm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Hostel;
import com.capgemini.hsm.repository.HostelDAO;

@Service
public class HostelServiceImpl implements HostelService{

	@Autowired
	private HostelDAO dao;
	
	public HostelDAO getDao() {
		return dao;
	}

	public void setDao(HostelDAO dao) {
		this.dao = dao;
	}

	@Override
	public Hostel add(Hostel entity) throws DuplicateRecordException{
		if(dao.existsById(entity.getHostelId())) {
			throw new DuplicateRecordException("Duplicate Record Found");
		}
		dao.save(entity);
		return entity;
	}
	

	@Override
	public Hostel update(long id, Hostel entity) {
		return dao.save(entity);
	}

	@Override
	public boolean delete(long Id) throws RecordNotFoundException{
		if(dao.existsById(Id)) {
			dao.deleteById(Id);
			return true;
			}
			throw new RecordNotFoundException("Record Not Found");
		}
	

	
	@Override
	public Hostel findByPk(long id) throws RecordNotFoundException {
	
		Optional<Hostel> hostelentity = dao.findById(id);
		if(hostelentity.isPresent()) {
			return hostelentity.get();
		}
		   throw new RecordNotFoundException("Record Not Found");
	}
		
	@Override
	public List<Hostel> search() {
			List<Hostel> list = dao.findAll();
			return list;
		}

	@Override
	public List<Hostel> findByName(String name) throws RecordNotFoundException {
		List<Hostel> listByName= dao.findByName(name);
		if(!listByName.isEmpty())
		{
			return listByName;
		}
		throw new RecordNotFoundException("Record Not Found Exception");
	}
}

