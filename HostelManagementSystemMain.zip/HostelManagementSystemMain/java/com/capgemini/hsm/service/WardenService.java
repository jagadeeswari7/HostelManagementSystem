package com.capgemini.hsm.service;

import java.util.List;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Warden;



public interface WardenService {

	public Warden addWarden(Warden entity)throws DuplicateRecordException;
	public Warden updateWarden(Warden entity, long wardenId)throws RecordNotFoundException;
	public boolean deleteWarden(long id)throws RecordNotFoundException;
	public List<Warden> findByWardenName(String name)throws RecordNotFoundException;
	public Warden findByPk(long id)throws RecordNotFoundException;
	public List<Warden> searchAllWardens();
	
	
}
