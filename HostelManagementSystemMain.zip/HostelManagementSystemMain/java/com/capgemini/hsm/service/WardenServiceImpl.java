package com.capgemini.hsm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Warden;
import com.capgemini.hsm.repository.WardenDAO;

@Service
public class WardenServiceImpl implements WardenService{
		
		@Autowired
		private WardenDAO dao;
		
		public WardenDAO getDao() {
			return dao;
		}

		public void setDao(WardenDAO dao) {
			this.dao = dao;
		}
		
		@Override
		public Warden addWarden(Warden entity) throws DuplicateRecordException {
			if(dao.existsById(entity.getWardenId())) {
				throw new DuplicateRecordException("Duplicate Record Found");
			}
			dao.save(entity);
			return entity;
		}
		
		@Override
		public Warden updateWarden(Warden entity,long wardenId) throws RecordNotFoundException {
			Warden warden = dao.findBywardenId(wardenId);
	        if (warden!=null) {
	        	warden.setName(entity.getName());
	        	warden.setLogin(entity.getLogin());
	        	dao.save(warden);
	            return warden;     	
	        }
	            throw new RecordNotFoundException ("Warden not found for this id");
	        }
		
		@Override	
		public boolean deleteWarden(long id) throws RecordNotFoundException {
			if(dao.existsById(id)) {
			   dao.deleteById(id);
			   return true;
			}
			   throw new RecordNotFoundException("Record Not Found");
		}

		@Override
		public List<Warden> findByWardenName(String name) throws RecordNotFoundException {
		    List<Warden> wardenList = dao.findByName(name);
			if(wardenList.isEmpty()) {
				throw new RecordNotFoundException("Record Not Found");
			}
			   return wardenList;
			}
		
		@Override
		public Warden findByPk(long wardenId) throws RecordNotFoundException {
			Warden warden = dao.findBywardenId(wardenId);
			if(warden!=null) {
				return warden;  
			}
			throw new RecordNotFoundException("Warden not found for this id");
		}
		
	    @Override
		public List<Warden> searchAllWardens() {
			List<Warden> list = dao.findAll();
			return list;
		}
		}

		