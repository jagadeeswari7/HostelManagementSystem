package com.capgemini.hsm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Room;
import com.capgemini.hsm.repository.RoomDAO;

@Service
public class RoomServiceImpl implements RoomService {
    @Autowired
	private RoomDAO dao;

    public RoomDAO getDao() {
		return dao;
	}

	public void setDao(RoomDAO dao) {
		this.dao = dao;
	}

	@Override
	public Room add(Room entity) throws DuplicateRecordException {
		if(dao.existsById(entity.getRoomId())) {
			throw new DuplicateRecordException("Duplicate Room User Found");
		}
		dao.save(entity);
		return entity;
	}

	@Override
	public Room update(Room entity,long roomId) throws RecordNotFoundException{
		Room currentRoom = dao.findByRoomId(roomId);
        if (currentRoom!=null) {
        	currentRoom.setName(entity.getName());
        	currentRoom.setDescription(entity.getDescription());
        	dao.save(currentRoom);
        	return currentRoom;
        }
        else
            throw new RecordNotFoundException("Room not found for this id: "+roomId);
	}

	@Override
	public boolean delete(long roomId) throws RecordNotFoundException {
		if(dao.existsById(roomId)) {
			dao.deleteById(roomId);
			return true;
		}else {
			throw new RecordNotFoundException("Room not found for this id : "+roomId);
		}
	}

	@Override
	public List<Room> findByName(String name) throws RecordNotFoundException{
		List<Room> listByName= dao.findByName(name);
		if(!listByName.isEmpty())
		{
			return listByName;
		}
		throw new RecordNotFoundException("Record Not Found");
	}

	@Override
	public Room findByPk(long roomId) throws RecordNotFoundException{
		Room rooms=dao.findByRoomId(roomId);
		if(rooms!=null)
		{
			return rooms;
		}
		throw new RecordNotFoundException("Record Not Found");
	}

	@Override
	public List<Room> search(){
		List<Room> roomList = dao.findAll();
		return roomList;		
	}

}