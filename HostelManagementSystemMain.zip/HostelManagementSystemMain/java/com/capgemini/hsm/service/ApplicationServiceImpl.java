package com.capgemini.hsm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Application;
import com.capgemini.hsm.repository.ApplicationDAO;

@Service
public class ApplicationServiceImpl implements ApplicationService {
	@Autowired
	public ApplicationDAO dao;

	public  ApplicationDAO getDao() {
		return dao;
	}

	public void setDao( ApplicationDAO dao) {
		this.dao = dao;
	}
	

	@Override
	public Application add(Application entity) throws DuplicateRecordException {
		if(dao.existsById(entity.getApplicationId())) {
			throw new DuplicateRecordException("Duplicate Application Found");
		}
		dao.save(entity);
		return entity;
	}

	@Override
	public Application update(long id,String name) throws RecordNotFoundException{
		Optional<Application> application = dao.findById(id);
		if (application.isPresent()) {
			Application app=application.get();
			app.setName(name);
			return dao.save(app);
		}
		throw new RecordNotFoundException("Record Not Found");
	}

	@Override
	public boolean delete(long id) throws RecordNotFoundException{
		Optional<Application> application = dao.findById(id);
		if(application.isPresent()) {
			dao.deleteById(id);
			return true;
		}
		throw new RecordNotFoundException("Record Not Found");
	}

	@Override
	public List<Application> findApplicationByName(String name) throws RecordNotFoundException {
		List<Application> application = dao.findByName(name);
		if(application!=null) {
			return application;
		}
		throw new RecordNotFoundException("Record Not Found");
	}

	@Override
	public Application findApplicationByPk(long id) throws RecordNotFoundException {
		Optional<Application> application = dao.findById(id);
		if (application.isPresent()) {
			return application.get();
		}
		throw new RecordNotFoundException("Record Not Found");
	}

	
	@Override
	public List<Application> search() {
		List<Application> list = dao.findAll();
		return list;
	}

	
}
