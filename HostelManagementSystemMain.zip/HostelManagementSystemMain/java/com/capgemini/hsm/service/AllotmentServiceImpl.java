package com.capgemini.hsm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Allotment;
import com.capgemini.hsm.repository.AllotmentDAO;
@Service
public class AllotmentServiceImpl implements AllotmentService{

	@Autowired
	private AllotmentDAO dao;

	public AllotmentDAO getDao() {
		return dao;
	}
	public void setDao(AllotmentDAO dao) {
		this.dao = dao;
	}

	@Override
	public Allotment add(Allotment entity) throws DuplicateRecordException{
		if(dao.existsById(entity.getAllotId())) {
			throw new DuplicateRecordException("Duplicate User Found for this allotment.");
		}
		dao.save(entity);
		return entity;   
	}
	
	@Override
	public boolean delete(long allotId) throws RecordNotFoundException{
		if(dao.existsById(allotId)) {
			dao.deleteById(allotId);
			return true;
		}else {
			throw new RecordNotFoundException("Record Not Found Exception");
		}
	}

	@Override
	public List<Allotment> findAllotmentByName(String name) throws RecordNotFoundException {
		List<Allotment> nameList= dao.findByName(name);
		if(!nameList.isEmpty())
		{
			return nameList;
		}
		throw new RecordNotFoundException("Record Not Found Exception");
	}

	@Override
	public Allotment findByPk(long allotId) throws RecordNotFoundException {
		Allotment allotedUser = dao.findByAllotId(allotId);
		if(allotedUser!=null) {
			return allotedUser;
		}
		   throw new RecordNotFoundException("Record Not Found Exception");
	}
	
	@Override
	public List<Allotment> searchAllAllotedUsers() {
		List<Allotment> list = dao.findAll();
		return list;
	
	}
	@Override
	public Allotment update(long allotId, Allotment entity) throws RecordNotFoundException {
		Allotment allotedUser = dao.findByAllotId(allotId);
		if(allotedUser!=null) {
		allotedUser.setHostelId(entity.getHostelId());	
		allotedUser.setHostelName(entity.getHostelName());
		allotedUser.setUserId(entity.getUserId());
		allotedUser.setName(entity.getName());
		allotedUser.setRoomName(entity.getRoomName());
		dao.save(allotedUser);
		return allotedUser;
		}
		 throw new RecordNotFoundException("Record Not Found Exception");
	}

}