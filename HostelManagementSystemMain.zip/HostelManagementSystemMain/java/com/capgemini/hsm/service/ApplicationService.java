package com.capgemini.hsm.service;

import java.util.List;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Application;

public interface ApplicationService {

	public Application add(Application entity) throws DuplicateRecordException;
	public Application update(long id,String name) throws RecordNotFoundException;
	public boolean delete(long id) throws RecordNotFoundException;
	public List<Application> findApplicationByName(String name) throws RecordNotFoundException;
	public Application findApplicationByPk(long id) throws RecordNotFoundException;
	public List<Application> search();
	
	
	
}

