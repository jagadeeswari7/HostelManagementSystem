package com.capgemini.hsm.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
		
@Entity
@Table(name="Allotments")
public class Allotment implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ALLOTMENT_ID")
	private long allotId;
	
	@Column(name = "HOSTEL_ID")
	private long hostelId;
	
	@Column(name = "HOSTEL_NAME") 
	private String hostelName;
	
	@Column(name = "USER_ID")
	private long userId;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "ROOM_NAME")
	private String roomName;
	
	@ManyToMany(fetch=FetchType.LAZY,mappedBy = "allotments")
	private Set<Room> roomallot=new HashSet<Room>();
	
	
	public Allotment(long allotId, long hostelId, String hostelName, long userId, String name, String roomName) {
		super();
		this.allotId = allotId;
		this.hostelId = hostelId;
		this.hostelName = hostelName;
		this.userId = userId;
		this.name = name;
		this.roomName = roomName;
	}
	public Set<Room> getRoomallot() {
		return roomallot;
	}
	public void setRoomallot(Set<Room> roomallot) {
		this.roomallot = roomallot;
	}
	public long getAllotId() {
		return allotId;
	}
	public void setAllotId(long allotId) {
		this.allotId = allotId;
	}
	public long getHostelId() {
		return hostelId;
	}
	public void setHostelId(long hostelId) {
		this.hostelId = hostelId;
	}
	public String getHostelName() {
		return hostelName;
	}
	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	@Override
	public String toString() {
		return "Allotment [allotId=" + allotId + ", hostelId=" + hostelId + ", hostelName=" + hostelName + ", userId="
				+ userId + ", name=" + name + ", roomName=" + roomName + "]";
	}
	
	
}
