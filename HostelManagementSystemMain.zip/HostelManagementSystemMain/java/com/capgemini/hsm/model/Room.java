package com.capgemini.hsm.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Rooms")
public class Room implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ROOM_ID")
	private long roomId;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@ManyToMany(fetch=FetchType.LAZY, mappedBy="rooms")
	private Set<Hostel> hostelrooms=new HashSet<Hostel>();
	
	public Set<Hostel> getHostelrooms() {
		return hostelrooms;
	}

	public void setHostelrooms(Set<Hostel> hostelrooms) {
		this.hostelrooms = hostelrooms;
	}
	
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="roomfee")
	private Set<Fee>fees=new HashSet<Fee>();

	public Set<Fee> getFees() {
		return fees;
	}

	public void setFees(Set<Fee> fees) {
		this.fees = fees;
	}
   
	 @ManyToMany(cascade=CascadeType.ALL)
	 @JoinTable(name="room_allotments" ,joinColumns= {@JoinColumn(name="ROOM_ID")}, inverseJoinColumns= {@JoinColumn(name="ALLOTMENT_ID")})
		private Set<Allotment>allotments=new HashSet<Allotment>();
	    
		public Set<Allotment> getAllotments() {
			return allotments;
		}

		public void setAllotments(Set<Allotment> allotments) {
			this.allotments = allotments;
		}

	public Room(long roomId, String name, String description) {
		super();
		this.roomId = roomId;
		this.name = name;
		this.description = description;
	}

	public Room() {
		
	}

	public long getRoomId() {
		return roomId;
	}
	public void setRoomId(long roomId) {
		this.roomId = roomId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

//	public void addAllotments(Allotment allotss)
//	{
//		this.getAllotments().add(allotss);
//	}


}