package com.capgemini.hsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DatabaseException;
import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Visitor;
import com.capgemini.hsm.service.VisitorService;

@RestController
@RequestMapping("visitors")
public class VisitorController {

	@Autowired
	private VisitorService service;
	
	// http://localhost:7070/visitors - METHOD PUT
	@PostMapping
	public ResponseEntity<Visitor> addVisitor(@RequestBody Visitor visitors) throws DuplicateRecordException
	{
		Visitor result=service.addVisitor(visitors);
		ResponseEntity<Visitor> response;
		if(result!=null)
		{
			response=new ResponseEntity<Visitor>(result,HttpStatus.CREATED);
		}
		else
		{
			response=new ResponseEntity<Visitor>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	@GetMapping("/id/{visitorId}")
	public ResponseEntity<Visitor> getDetailsById(@PathVariable("visitorId") long id) throws RecordNotFoundException
	{
		Visitor visitorsById=service.findVisitorByPK(id);
		if(visitorsById!=null)
		{
			return new ResponseEntity<Visitor>(visitorsById,HttpStatus.OK);	
		}
		else
		{
			return new ResponseEntity<Visitor>(HttpStatus.NOT_FOUND);
			
		}
	}
	
	@GetMapping("/name/{visitorName}")
	public ResponseEntity<List<Visitor>> getDetailsByName(@PathVariable("visitorName") String name) throws RecordNotFoundException
	{
		List<Visitor> visitorsByName=service.findVisitorByName(name);
		if(visitorsByName.isEmpty())
		{
			return new ResponseEntity<List<Visitor>>(HttpStatus.NOT_FOUND);
		}
		else
		{
			return new ResponseEntity<List<Visitor>>(visitorsByName,HttpStatus.OK);
		}
	}
	
	@GetMapping
	public ResponseEntity<List<Visitor>> getDetailsOfAllVisitors() throws RecordNotFoundException
	{
		List<Visitor> visitorList=service.searchVisitor();
		if(visitorList.isEmpty())
		{
		   return new ResponseEntity<List<Visitor>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<Visitor>>(visitorList,HttpStatus.OK);
	}
	
	@DeleteMapping("{visitorId}")
	public ResponseEntity<String> deleteDetailsOfVisitors(@PathVariable("visitorId")long id) throws RecordNotFoundException
	{
		String deletemsg=service.deleteVisitor(id);
		if(deletemsg!=null)
			return new ResponseEntity<String>("Visitor with the id "+id+" is deleted",HttpStatus.OK);
		else
			 return new ResponseEntity<String>("Visitor Id is not Found",HttpStatus.NOT_FOUND);
			
		
	}
	
	@PutMapping("/{visitorId}")
	public ResponseEntity<Visitor> updateVisitorDetails(@PathVariable("visitorId") long id, @RequestBody Visitor visitors) throws RecordNotFoundException, DatabaseException
	{
		Visitor visitorDetails=service.updateVisitor(id, visitors);
		if(visitorDetails!=null)
		{
			return new ResponseEntity<Visitor>(visitorDetails,HttpStatus.OK);
		}
		  return new ResponseEntity<Visitor>(HttpStatus.NOT_ACCEPTABLE);
		
	}

}
