package com.capgemini.hsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Hostel;
import com.capgemini.hsm.service.HostelService;

@RestController
@RequestMapping(path="hostel")
public class HostelController {
	
	@Autowired
	HostelService service;

	@PostMapping
	public ResponseEntity<Hostel> addHostel(@RequestBody Hostel entity) throws DuplicateRecordException {
		Hostel result = service.add(entity);
		ResponseEntity<Hostel> response;
		if(result!=null) {
			response = new ResponseEntity<Hostel>(result,HttpStatus.CREATED);
		}else {
			response = new ResponseEntity<Hostel>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}  
		
	@GetMapping("/name/{HostelName}")
	private ResponseEntity<List<Hostel>> gethostelByName(@PathVariable("HostelName") String name) throws RecordNotFoundException {
		List<Hostel> list=service.findByName(name);
		if(list.isEmpty()) {
			return new ResponseEntity<List<Hostel>>(HttpStatus.NOT_FOUND) ;
		}
		else {
			return new ResponseEntity<List<Hostel>>(list,HttpStatus.OK) ;
		}
	}
	
	@GetMapping("/Id/{HostelId}")  
	private ResponseEntity<Hostel> getstudentByID(@PathVariable("HostelId") long hostelId)   throws RecordNotFoundException 
	{ 
		Hostel hostel= service.findByPk(hostelId);
		if(hostel!=null) {
			return new ResponseEntity<Hostel>(hostel,HttpStatus.OK);
		}
		return new ResponseEntity<Hostel>(HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping("{HostelId}")  
	private ResponseEntity<String> deleteHostelByID(@PathVariable("HostelId") long id)  throws RecordNotFoundException  
	{  
			if(service.delete(id)) 
				return new ResponseEntity<String>("Application is deleted",HttpStatus.OK);
			return new ResponseEntity<String>("Hostel not found",HttpStatus.NOT_FOUND);
		
	}  
	@GetMapping("/getAll")
	private ResponseEntity<List<Hostel>> getDetailsOfAllHostels() throws RecordNotFoundException  
	{  	
		List<Hostel> app=service.search();
		if(app.isEmpty()) {
			return new ResponseEntity<List<Hostel>>(HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
		else {
			return new ResponseEntity<List<Hostel>>(app,HttpStatus.OK) ;
		}
	}  
	
}