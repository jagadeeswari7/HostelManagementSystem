package com.capgemini.hsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Room;
import com.capgemini.hsm.service.RoomService;

@RestController
@RequestMapping(path="rooms")
public class RoomController {
	
	@Autowired
	private RoomService service;
	
	@PostMapping
	public ResponseEntity<Room> addRoom(@RequestBody Room entity) throws DuplicateRecordException {
		Room result = service.add(entity);
		ResponseEntity<Room> response;
		if(result!=null) {
			response = new ResponseEntity<Room>(result,HttpStatus.CREATED);
		}else {
			response = new ResponseEntity<Room>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	@PutMapping("{RoomId}")
	public ResponseEntity<?> updateRoom(@RequestBody Room room, @PathVariable("RoomId") long RoomId) throws RecordNotFoundException
	{
		service.update(room,RoomId);
		return ResponseEntity.ok("Room has been updated successfully");
	}
	
	@DeleteMapping("{RoomId}")
	public ResponseEntity<?> removeRoom(@PathVariable("RoomId") long RoomId) throws RecordNotFoundException
	{
	   service.delete(RoomId);
	   return ResponseEntity.ok("Room has been deleted successfully");	   
	}
	
	@GetMapping("/getName/{name}")
	public ResponseEntity<List<Room>> getDetailsByName(@PathVariable("name") String name) throws RecordNotFoundException
	{
		List<Room> room= service.findByName(name);
		if(room.isEmpty())
			return new ResponseEntity<List<Room>>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<List<Room>>(room,HttpStatus.OK);	
	}
	
	@GetMapping("/RoomId/{RoomId}")
	public ResponseEntity<Room> getDetailsByPk(@PathVariable("RoomId") long RoomId) throws RecordNotFoundException
	{
		Room result = service.findByPk(RoomId);
		if(result!=null)
			 return new ResponseEntity<Room>(result,HttpStatus.OK);
		   return new ResponseEntity<Room>(HttpStatus.INTERNAL_SERVER_ERROR);	   		
	}
	
	@GetMapping("/search")
	public ResponseEntity<List<Room>> searchDetails()
	{
		List<Room> roomList=service.search();
		if(roomList.isEmpty())
			return new ResponseEntity<List<Room>>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<List<Room>>(roomList,HttpStatus.OK);	
	}
}
