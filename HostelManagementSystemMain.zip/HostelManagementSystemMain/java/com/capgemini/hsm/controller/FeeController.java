package com.capgemini.hsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Fee;
import com.capgemini.hsm.service.FeeService;

@RestController
@RequestMapping(path="fee")
public class FeeController {
	
	@Autowired
	private FeeService service;
	
	@PostMapping
	public ResponseEntity<Fee> addFee(@RequestBody Fee entity) throws DuplicateRecordException {
		Fee result = service.add(entity);
		ResponseEntity<Fee> response;
		if(result!=null) {
			response = new ResponseEntity<Fee>(result,HttpStatus.CREATED);
		}else {
			response = new ResponseEntity<Fee>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	@PutMapping("/update/{feeId}")
	public ResponseEntity<?> updateFee(@RequestBody Fee fee, @PathVariable("feeId") long feeId) throws RecordNotFoundException 
	{
		service.update(fee, feeId);
		return ResponseEntity.ok("Fee has been updated successfully");	
	}
	
	@DeleteMapping("{feeId}")
	public ResponseEntity<?> removeRoom(@PathVariable("feeId") long feeId) throws RecordNotFoundException
	{
	   service.delete(feeId);
	   return ResponseEntity.ok("Fee has been deleted successfully");	
	}
	@GetMapping("/getName/{name}")
	public ResponseEntity<List<Fee>> getDetailsByName(@PathVariable("name") String name) throws RecordNotFoundException
	{
		List<Fee> fee= service.findByName(name);
		if(fee.isEmpty())
			return new ResponseEntity<List<Fee>>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<List<Fee>>(fee,HttpStatus.OK);	
	}
	
	@GetMapping("/feeId/{feeId}")
	public ResponseEntity<Fee> getDetailsByPk(@PathVariable("feeId") long feeId) throws RecordNotFoundException
	{
		Fee result = service.findByPk(feeId);
		if(result!=null)
			 return new ResponseEntity<Fee>(result,HttpStatus.OK);
		   return new ResponseEntity<Fee>(HttpStatus.INTERNAL_SERVER_ERROR);	   		
	}
	
	@GetMapping("/search")
	public ResponseEntity<List<Fee>> searchDetails()
	{
		List<Fee> feeList=service.search();
		if(feeList.isEmpty())
			return new ResponseEntity<List<Fee>>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<List<Fee>>(feeList,HttpStatus.OK);	
	}
	
	
}
