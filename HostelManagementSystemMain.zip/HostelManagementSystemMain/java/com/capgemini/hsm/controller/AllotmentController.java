package com.capgemini.hsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Allotment;
import com.capgemini.hsm.service.AllotmentService;

@RestController
@RequestMapping(path="allotment")
public class AllotmentController {
	@Autowired
	private AllotmentService service;

	@PostMapping
	public ResponseEntity<Allotment> addAllotment(@RequestBody Allotment entity) throws DuplicateRecordException {
		Allotment result = service.add(entity);
		ResponseEntity<Allotment> response;
		if(result!=null) {
			response = new ResponseEntity<Allotment>(result,HttpStatus.CREATED);
		}else {
			response = new ResponseEntity<Allotment>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;	
	}  
	
	@GetMapping("/name/{AllotmentName}")
	private ResponseEntity<List<Allotment>> getallotmentByName(@PathVariable("AllotmentName") String name) throws RecordNotFoundException{
		List<Allotment> app=service.findAllotmentByName(name);
		if(app.isEmpty()) {
			return new ResponseEntity<List<Allotment>>(HttpStatus.NOT_FOUND) ;
		}
		else {
			return new ResponseEntity<List<Allotment>>(app,HttpStatus.OK) ;
		}
		
	}
	
	@GetMapping("/id/{AllotmentId}")  
	private ResponseEntity<Allotment> getallotmentByID(@PathVariable("AllotmentId") long allotmentId) throws RecordNotFoundException 
	{ 
		Allotment allotment= service.findByPk(allotmentId);
		if(allotment!=null) {
			return new ResponseEntity<Allotment>(allotment,HttpStatus.OK);
		}
		return new ResponseEntity<Allotment>(HttpStatus.NOT_FOUND);
	}

	@PutMapping("{AllotmentId}")  
	public ResponseEntity<Allotment> update(@PathVariable("AllotmentId") long id, @RequestBody Allotment allotment) throws RecordNotFoundException{   
	{ 
		Allotment sample =service.update(id,allotment);
		  if (sample != null) 
			  return new ResponseEntity<Allotment>(sample,HttpStatus.OK);
		  
		  return new ResponseEntity<Allotment>( HttpStatus.NOT_FOUND);
		}
	}
	
	
	@DeleteMapping("{AllotmentId}")  
	private ResponseEntity<String> deleteAllotmentByID(@PathVariable("AllotmentId") long id) throws RecordNotFoundException 
	{  
			if(service.delete(id)) {
				return new ResponseEntity<String>("Allotment is deleted",HttpStatus.OK);
			}
			else {
				return new ResponseEntity<String>("Allotment not found",HttpStatus.NOT_FOUND);
			}	
	}  
	
	@GetMapping
	private ResponseEntity<List<Allotment>> getDetailsOfAllAllotments()  
	{  
		List<Allotment> app=service.searchAllAllotedUsers();
		if(app.isEmpty()) {
			return new ResponseEntity<List<Allotment>>(HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
		else {
			return new ResponseEntity<List<Allotment>>(app,HttpStatus.OK) ;
		}
	}  
}


