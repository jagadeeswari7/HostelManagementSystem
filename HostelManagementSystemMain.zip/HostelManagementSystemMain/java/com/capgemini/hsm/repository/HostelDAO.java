package com.capgemini.hsm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.hsm.model.Hostel;


public interface HostelDAO extends JpaRepository<Hostel , Long>{
	
	public List<Hostel> findByName(String name);
	
}
