package com.capgemini.hsm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.hsm.model.Allotment;


public interface AllotmentDAO extends JpaRepository<Allotment, Long>{

	public Allotment findByAllotId(long allotId);
	public List<Allotment> findByName(String name);
}
