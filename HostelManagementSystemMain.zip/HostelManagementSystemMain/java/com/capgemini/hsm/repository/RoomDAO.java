package com.capgemini.hsm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.hsm.model.Room;


public interface RoomDAO extends JpaRepository<Room, Long>{

	public List<Room> findByName(String name);

	public Room findByRoomId(long roomId);	
}
