package com.capgemini.hsm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.hsm.model.Warden;


public interface WardenDAO extends JpaRepository<Warden, Long>{

	public List<Warden> findByName(String name);

	public Warden findBywardenId(long wardenId);

}
