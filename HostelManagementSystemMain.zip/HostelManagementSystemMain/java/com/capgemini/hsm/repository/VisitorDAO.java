package com.capgemini.hsm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.hsm.model.Visitor;


public interface VisitorDAO extends JpaRepository<Visitor, Long>{

	public List<Visitor> findByName(String name);

	public Visitor findByVisitorId(long visitorId);
	
}
