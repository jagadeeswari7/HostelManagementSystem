package com.capgemini.hsm.service;

import java.util.List;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Visitor;

public interface VisitorService {
	
	
	public Visitor addVisitor(Visitor visitor) throws DuplicateRecordException;
	public Visitor findVisitorByPK(long id) throws RecordNotFoundException;
	public List<Visitor> searchVisitor()throws RecordNotFoundException;
	public Visitor updateVisitor(long id,Visitor visitor) throws RecordNotFoundException;
	public String deleteVisitor(long id) throws RecordNotFoundException;
	public List<Visitor> findVisitorByName(String name)throws RecordNotFoundException;
	

}
