package com.capgemini.hsm.service;

import java.util.List;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Allotment;

public interface AllotmentService {

	public Allotment add(Allotment entity) throws DuplicateRecordException;
	public boolean delete(long allotId) throws RecordNotFoundException;
	public List<Allotment> findAllotmentByName(String name) throws RecordNotFoundException;
	public Allotment findByPk(long allotId) throws RecordNotFoundException;
	public List<Allotment> searchAllAllotedUsers();
	Allotment update(long allotId, Allotment entity) throws RecordNotFoundException;
	
}
