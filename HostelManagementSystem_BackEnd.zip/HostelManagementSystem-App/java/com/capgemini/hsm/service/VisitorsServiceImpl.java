package com.capgemini.hsm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Visitor;
import com.capgemini.hsm.repository.VisitorDAO;

@Service
public class VisitorsServiceImpl implements VisitorService{
	
	@Autowired
	private VisitorDAO dao;

	public VisitorDAO getVisitorDao() {
		return dao;
	}

	public void setVisitorDao(VisitorDAO dao) {
		this.dao = dao;
	}

	@Override
	public Visitor addVisitor(Visitor visitor) throws DuplicateRecordException {
		if(dao.existsById(visitor.getVisitorId())) {
			throw new DuplicateRecordException("Duplicate Visitor Found");
		}
		dao.save(visitor);
		return visitor;
	}

	@Override
	public Visitor findVisitorByPK(long id) throws RecordNotFoundException {
		Visitor visitor=dao.findByVisitorId(id);
		if(visitor!=null)
		{
			return visitor;
		}
		else
		{
		 throw new RecordNotFoundException("The Visitor details does not excist for the id"+id);
		}
	}

	@Override
	public List<Visitor> searchVisitor() throws RecordNotFoundException {
		List<Visitor> visitorList=dao.findAll();
		if(visitorList.isEmpty())
		{
			 throw new RecordNotFoundException("The Visitor details does not exist.");
		}
		else
			
		return visitorList;
	}

	@Override
	public Visitor updateVisitor(long visitorId,Visitor entity) throws RecordNotFoundException {

		Visitor visitors=dao.findByVisitorId(visitorId);
		if(visitors!=null)
		{			
			visitors.setName(entity.getName());
			visitors.setPurpose(entity.getPurpose());
			visitors.setRelation(entity.getRelation());
			visitors.setStudentName(entity.getStudentName());
			visitors.setAddress(entity.getAddress());
			dao.save(visitors);
			return visitors;
	      	
	     }
		throw new RecordNotFoundException("Visitor not found for this id"+visitorId);
		
	}

	@Override
	public String deleteVisitor(long id) throws RecordNotFoundException {
		
		if(dao.existsById(id))
		{
			dao.deleteById(id);
			return "Visitor details are deleted";
		}
		 throw new RecordNotFoundException("The Visitor details does not excist for the id"+id);
	}

	@Override
	public List<Visitor> findVisitorByName(String name) throws RecordNotFoundException {
		List<Visitor> visitors=dao.findByName(name);
		if(!visitors.isEmpty())
		{
			return visitors;
		}
		 throw new RecordNotFoundException("The Visitor details does not exist for the name"+name);
	}


}
