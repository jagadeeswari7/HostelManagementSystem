package com.capgemini.hsm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Fee;
import com.capgemini.hsm.repository.FeeDAO;

@Service
public class FeeServiceImpl implements FeeService {
    @Autowired
	private FeeDAO dao;

    public FeeDAO getDao() {
		return dao;
	}

	public void setDao(FeeDAO dao) {
		this.dao = dao;
	}

	@Override
	public Fee add(Fee entity) throws DuplicateRecordException {
		if(dao.existsById(entity.getFeeId())) {
			throw new DuplicateRecordException("Duplicate Fee User Found");
		}
		dao.save(entity);
		return entity;
	}

	@Override
	public Fee update(Fee entity,long feeId) throws RecordNotFoundException{
		Fee currentFee = dao.findByFeeId(feeId);
        if (currentFee!=null) {
        	currentFee.setName(entity.getName());
        	currentFee.setHostelName(entity.getHostelName());
        	currentFee.setRoomName(entity.getRoomName());
        	currentFee.setTotalfee(entity.getTotalfee());
        	currentFee.setPaidfee(entity.getPaidfee());
        	currentFee.setRemainingfee(entity.getRemainingfee());
        	dao.save(currentFee);
        	return currentFee;
        }
        else
        	throw new RecordNotFoundException("Fee not found for this id : "+feeId);
	}

	@Override
	public boolean delete(long feeId) throws RecordNotFoundException {
		if(dao.existsById(feeId)) {
			dao.deleteById(feeId);
			return true;
		}else {
			throw new RecordNotFoundException("Fee not found for this id : "+feeId);
		}
	}

	@Override
	public List<Fee> findByName(String name) throws RecordNotFoundException{
		List<Fee> listByName= dao.findByName(name);
		if(!listByName.isEmpty())
		{
			return listByName;
		}
		throw new RecordNotFoundException("Record Not Found");
	}

	@Override
	public Fee findByPk(long feeId) throws RecordNotFoundException{
		Fee fee=dao.findByFeeId(feeId);
		if(fee!=null)
		{
			return fee;
		}
		throw new RecordNotFoundException("Record Not Found");
	}

	@Override
	public List<Fee> search(){
		List<Fee> feeList = dao.findAll();
		return feeList;		
	}

}