package com.capgemini.hsm.service;

import java.util.List;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Fee;


public interface FeeService {

	public Fee add(Fee entity) throws DuplicateRecordException;
	public Fee update(Fee entity, long feeId) throws RecordNotFoundException;
	public boolean delete(long feeId) throws RecordNotFoundException;
	public List<Fee> findByName(String name) throws RecordNotFoundException;
	public Fee findByPk(long feeId) throws RecordNotFoundException;
	public List<Fee> search();
}
