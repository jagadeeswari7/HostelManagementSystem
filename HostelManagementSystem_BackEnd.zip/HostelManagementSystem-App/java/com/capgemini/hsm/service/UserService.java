package com.capgemini.hsm.service;

import java.util.List;

import com.capgemini.hsm.exception.ApplicationException;
import com.capgemini.hsm.exception.DatabaseException;
import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.User;

public interface UserService {

	public User add(User entity) throws DuplicateRecordException;
	public User update(User entity,long userId) throws RecordNotFoundException;
	public boolean delete(long userId) throws RecordNotFoundException;
	public User findByLogin(String login) throws RecordNotFoundException;
	public User findByPk(long userId) throws RecordNotFoundException;
	public List<User> searchAllUsers();
	public User authenticate(User entity) throws RecordNotFoundException, ApplicationException;
	public boolean changePassword(Long userId, String oldPassword, String newPassword) throws RecordNotFoundException, DatabaseException ;
    public long registerUser(User entity) throws DuplicateRecordException;
    public String forgetPassword(String login) throws RecordNotFoundException;
    
}
