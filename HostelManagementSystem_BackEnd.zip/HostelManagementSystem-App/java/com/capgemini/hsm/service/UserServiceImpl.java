package com.capgemini.hsm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hsm.exception.ApplicationException;
import com.capgemini.hsm.exception.DatabaseException;
import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.User;
import com.capgemini.hsm.repository.UserDAO;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDAO dao;
	
	public UserDAO getDao() {
		return dao;
	}

	public void setDao(UserDAO dao) {
		this.dao = dao;
	}
	
	@Override
	public User add(User entity) throws DuplicateRecordException {
		if(dao.existsById(entity.getUserId())) {
			throw new DuplicateRecordException("Duplicate Record Found");
		}
		dao.save(entity);
		return entity;
	}

	@Override
	public User update(User entity, long userId) throws RecordNotFoundException{
		User currentUser = dao.findByUserId(userId);
		if(currentUser!=null) { 
        	currentUser.setFirstName(entity.getFirstName());
        	currentUser.setLastName(entity.getLastName());
        	currentUser.setDob(entity.getDob());
        	currentUser.setMail(entity.getMail());
        	currentUser.setMobileNo(entity.getMobileNo());
        	currentUser.setGender(entity.getGender());
        	dao.save(currentUser);
        	return currentUser;
		}
		throw new RecordNotFoundException("User not found for this id :: "+userId);
	}

	@Override
	public boolean delete(long userId) throws RecordNotFoundException {
		if(dao.existsById(userId)) {
			dao.deleteById(userId);
			return true;
		}else {
			throw new RecordNotFoundException("User not found for this id :: "+userId);
		}
	}

	@Override
	public User findByLogin(String login) throws RecordNotFoundException {
		User user = dao.findByLogin(login);
		if(user!=null) {
			return user;
		}
			throw new RecordNotFoundException("Record Not Found for this login :: "+login);
	}

	@Override
	public User findByPk(long userId) throws RecordNotFoundException {
		User user = dao.findByUserId(userId);
		if(user!=null) {
			return user;  
		}
		throw new RecordNotFoundException("User not found for this id :: "+userId);
//		User user = dao.findById(userId).orElseThrow(()-> new RecordNotFoundException("User not found for this id :: "+userId));
//		return user;
	}

	@Override
	public List<User> searchAllUsers() {
		return dao.findAll();
	}

	@Override
	public User authenticate(User entity) throws RecordNotFoundException, ApplicationException {
		User user = dao.findByUserId(entity.getUserId());
		if(user!=null) {
			if(user.getLogin().equals(entity.getLogin()) && user.getPassword().equals(entity.getPassword())){ 
				return user;
			}else {
				throw new ApplicationException("Authentication Not Successful");
			}
		}
	          throw new RecordNotFoundException("User not found for this id :: ");	
	}

	@Override
	public boolean changePassword(Long userId, String oldPassword, String newPassword) throws RecordNotFoundException, DatabaseException {
		User user = dao.findByUserId(userId);
		if(user!=null) {
		if(user.getPassword().equals(oldPassword)) {
			user.setPassword(newPassword);
			dao.save(user);
			return true;
		}else {
			throw new DatabaseException("Database Error");
		}
		}
		throw new RecordNotFoundException("User not found for this id :: "+userId);
	}

	@Override
	public long registerUser(User entity) throws DuplicateRecordException {
		if(dao.existsById(entity.getUserId())) {
			throw new DuplicateRecordException("Duplicate Record Found");
		}
		User newUser = new User();
		newUser.setUserId(entity.getUserId());
		newUser.setFirstName(entity.getFirstName());
    	newUser.setLastName(entity.getLastName());
    	newUser.setDob(entity.getDob());
    	newUser.setMail(entity.getMail());
    	newUser.setMobileNo(entity.getMobileNo());
    	newUser.setGender(entity.getGender());
    	dao.save(newUser);
		return newUser.getUserId();
	}

	@Override
	public String forgetPassword(String login) throws RecordNotFoundException{
		User user = dao.findByLogin(login);
		if(user!=null && user.getLogin().equals(login)) {
				return user.getMail();
		}
		throw new RecordNotFoundException("Record not found for this login "+login);
		
	}

}
