package com.capgemini.hsm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
//http://localhost:7070/HostelSystemManagement/swagger-ui/
//http://localhost:7070/swagger-ui/
public class MainUI 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(MainUI.class, args);
    }
}
