package com.capgemini.hsm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Applications")
public class Application implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "APPLICATION_ID")
	private long applicationId;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "HOSTEL_NAME")
	private String hostelName;
	
	@Column(name = "QUALIFICATION")
	private String qualification;
	
	@Column(name = "ADDRESS")
	private String address;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@OneToOne
	@JoinColumn(name="USER_ID")
	private User user;
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	@ManyToOne
	@JoinColumn(name="HOSTEL_ID")
	private Hostel hostel;
	

	public Hostel getHostel() {
		return hostel;
	}

	public void setHostel(Hostel hostel) {
		this.hostel = hostel;
	}

	public Application(long applicationId,String name, String hostelName, String qualification,
			String address, String description) {
		super();
		this.applicationId = applicationId;
		this.name = name;
		this.hostelName = hostelName;
		this.qualification = qualification;
		this.address = address;
		this.description = description;
	}
	
	public Application() {
		
	}

	public long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getHostelName() {
		return hostelName;
	}
	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
