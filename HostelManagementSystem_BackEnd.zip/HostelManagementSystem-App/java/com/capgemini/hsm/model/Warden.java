package com.capgemini.hsm.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Wardens")
public class Warden implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "WARDEN_ID")
	private long wardenId;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "LOGIN")
	private String login;
	
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private User user;
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@ManyToOne
	@JoinColumn(name = "VISITOR_ID")
	private Visitor visitors;

	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="hostel_wardens",joinColumns= {@JoinColumn(name="WARDEN_ID")},inverseJoinColumns =  {@JoinColumn(name="HOSTEL_ID")})
	private Set<Hostel> hostel=new HashSet<Hostel>();
	
	public Set<Hostel> getHostel() {
		return hostel;
	}

	public void setHostel(Set<Hostel> hostel) {
		this.hostel = hostel;
	}

	public Warden(long wardenId, String name, String login) {
		super();
		this.wardenId = wardenId;
		this.name = name;
		this.login = login;
	}
	
	public Warden() {

	}
	public long getWardenId() {
		return wardenId;
	}
	public void setWardenId(long wardenId) {
		this.wardenId = wardenId;
	}	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
//	public void addHostel(Hostel hostels)
//	{
//		this.getHostel().add(hostels);
//	}
}
