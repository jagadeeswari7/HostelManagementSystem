package com.capgemini.hsm.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Fees")
public class Fee implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "FEE_ID")
	private long feeId;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "HOSTEL_ID")
	private long hostelId;
	
	@Column(name = "HOSTEL_NAME")
	private String hostelName;
	
	@Column(name = "ROOM_NAME")
	private String roomName;
	
	@Column(name = "TOTAL_FEE")
	private String totalfee;
	
	@Column(name = "PAY")
	private String pay;
	
	@Column(name = "PAID_FEE")
	private String paidfee;
	
	@Column(name = "REMAINING_FEE")
	private String remainingfee;
	
	@Column(name = "ALLOTMENT_ID")
	private long allotmentId;
	
	@OneToOne
	@JoinColumn(name="USER_ID")
	private User user;
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="room_fees", joinColumns = {@JoinColumn(name="FEE_ID")},inverseJoinColumns= {@JoinColumn(name="ROOM_ID")})
	private Set<Room> roomfee=new HashSet<Room>();
	
	public Fee(long feeId, String name, long hostelId, String hostelName, String roomName,
			String totalfee, String pay, String paidfee, String remainingfee, long allotmentId) {
		super();
		this.feeId = feeId;
		this.name = name;
		this.hostelId = hostelId;
		this.hostelName = hostelName;
		this.roomName = roomName;
		this.totalfee = totalfee;
		this.pay = pay;
		this.paidfee = paidfee;
		this.remainingfee = remainingfee;
		this.allotmentId = allotmentId;
	}
	public Fee() {
		
	}
	public long getFeeId() {
		return feeId;
	}
	public void setFeeId(long feeId) {
		this.feeId = feeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getHostelId() {
		return hostelId;
	}
	public void setHostelId(long hostelId) {
		this.hostelId = hostelId;
	}
	public String getHostelName() {
		return hostelName;
	}
	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}

	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public String getTotalfee() {
		return totalfee;
	}
	public void setTotalfee(String totalfee) {
		this.totalfee = totalfee;
	}
	public String getPay() {
		return pay;
	}
	public void setPay(String pay) {
		this.pay = pay;
	}
	public String getPaidfee() {
		return paidfee;
	}
	public void setPaidfee(String paidfee) {
		this.paidfee = paidfee;
	}
	public String getRemainingfee() {
		return remainingfee;
	}
	public void setRemainingfee(String remainingfee) {
		this.remainingfee = remainingfee;
	}
	public long getAllotmentId() {
		return allotmentId;
	}
	public void setAllotmentId(long allotmentId) {
		this.allotmentId = allotmentId;
	}
   
//	public void addRoomFees(Room roomFees)
//	{
//		this.getRoomfee().add(roomFees);
//	}
//	
}
