package com.capgemini.hsm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.hsm.model.Application;


public interface ApplicationDAO extends JpaRepository<Application, Long>{
	
	public List<Application> findByName(String name);
}
