package com.capgemini.hsm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.hsm.model.Fee;


public interface FeeDAO extends JpaRepository<Fee, Long>{

	public List<Fee> findByName(String name);

	public Fee findByFeeId(long feeId);
}
