package com.capgemini.hsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.ApplicationException;
import com.capgemini.hsm.exception.DatabaseException;
import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.User;
import com.capgemini.hsm.service.UserService;

@RestController
@RequestMapping(path="users")
public class UserController {
	
	@Autowired
	private UserService service;
	
	// http://localhost:7070/users - METHOD POST
	@PostMapping
	public ResponseEntity<User> addUser(@RequestBody User user) throws DuplicateRecordException {
		User result = service.add(user);
		ResponseEntity<User> response;
		if(result!=null) { 
			response = new ResponseEntity<User>(result,HttpStatus.CREATED);
		}else {
            throw new DuplicateRecordException("Internal Server Error");
        }
		return response;
	}
		
	// http://localhost:7070/users - METHOD PUT
	@PutMapping("{userId}") 
	public ResponseEntity<User> updateUser(@RequestBody User user, @PathVariable("userId") long id) throws RecordNotFoundException{
		User result = service.update(user,id);
		if(result!=null) {
			return new ResponseEntity<User>(result,HttpStatus.OK);
		}else {
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
		}
	}
			
	// http://localhost:7070/users - METHOD DELETE
	@DeleteMapping("{userId}")
	public ResponseEntity<String> removeUser(@PathVariable("userId") long id) throws RecordNotFoundException {
		boolean result = service.delete(id);
		if(result) {
		    return new ResponseEntity<String>("User has been deleted successfully",HttpStatus.OK);	
		}else {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("/login/{userLogin}")
	public ResponseEntity<User> findUserByLogin(@PathVariable("userLogin") String login) throws RecordNotFoundException {
		User result = service.findByLogin(login);
		if(result!=null) {
			return new ResponseEntity<User>(result,HttpStatus.OK);
		}else {
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("/id/{userId}")
	public ResponseEntity<User> findUserByPrimaryKey(@PathVariable("userId") long id) throws RecordNotFoundException {
		User result = service.findByPk(id);
		if(result!=null) {
			return new ResponseEntity<User>(result,HttpStatus.OK);
		}else {
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
		}
	}
	
	// http://localhost:7070/users - METHOD GET
	@GetMapping
	public ResponseEntity<List<User>> read(){
		List<User> users = service.searchAllUsers();
        if(users.isEmpty()){
            return new ResponseEntity<List<User>>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<List<User>>(users, HttpStatus.OK);
	}
	
	@GetMapping("/auth/{id}")
	public ResponseEntity<User> authentication(@PathVariable("id")long id, @RequestBody User user) throws RecordNotFoundException, ApplicationException{
		User user2 = service.findByPk(id);
		User result = service.authenticate(user);
		if(result!=null && user2!=null) {
			return new ResponseEntity<User>(result,HttpStatus.OK);
		}else if(user2==null) {
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
		}
		    return new ResponseEntity<User>(HttpStatus.NOT_ACCEPTABLE);
	}
	
	@PostMapping("/register")
	public ResponseEntity<String> registeringUser(@RequestBody User user) throws DuplicateRecordException{
		long result = service.registerUser(user);
		ResponseEntity<String> response;
		if(result>=1) { 
			response = new ResponseEntity<String>("User with id "+result+" is registered Successfully",HttpStatus.CREATED);
		}else {
			response = new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	@PatchMapping("/change/{id}")
	public ResponseEntity<String> changingPassword(@PathVariable("id") long id,@RequestBody User user) 
			                                       throws RecordNotFoundException, DatabaseException{
		User user2 = service.findByPk(id);
		String oldPassword = user.getPassword();
		boolean result = service.changePassword(id, oldPassword, "NewPass12");
		ResponseEntity<String> response;
		if(result) { 
			response = new ResponseEntity<String>("Password Changed Successfully",HttpStatus.OK);
		}else if(user2==null) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}else {
			response = new ResponseEntity<String>(HttpStatus.NOT_MODIFIED);
		}
		return response;
	}
	
	@GetMapping("/forget/{login}")
	public String forgetPassword(@PathVariable("login") String login) throws RecordNotFoundException{
		String result = service.forgetPassword(login);
		return result;
	}
}
