package com.capgemini.hsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Warden;
import com.capgemini.hsm.service.WardenService;

@RestController
@RequestMapping(path="wardens")
public class WardenController {
	
	@Autowired
	private WardenService service;

	// http://localhost:7070/wardens - METHOD POST
	@PostMapping
	public ResponseEntity<Warden> addWarden(@RequestBody Warden warden) throws DuplicateRecordException
	{
		Warden result = service.addWarden(warden);
		ResponseEntity<Warden> response;
		if(result!=null) { 
			response = new ResponseEntity<Warden>(result,HttpStatus.CREATED);
		}else {
			response = new ResponseEntity<Warden>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	@PutMapping("{wardenId}") 
	public ResponseEntity<?> updateWarden(@RequestBody Warden warden, @PathVariable("wardenId") long id) throws RecordNotFoundException {
		service.updateWarden(warden, id);
		return ResponseEntity.ok("Warden has been updated successfully");
	}
	
	@GetMapping("/Id/{wardenId}")
    public Warden getDetailsById(@PathVariable("wardenId") long wardenId) throws RecordNotFoundException 
	{
		return service.findByPk(wardenId);
	}
	
	@GetMapping("/Name/{wardenName}")
	 public List<Warden> getDetailsByName(@PathVariable("wardenName") String wardenName) throws RecordNotFoundException 
		{
			return service.findByWardenName(wardenName);
		}
	
	@DeleteMapping("{wardenId}")
	public boolean DeleteDetails(@PathVariable("wardenId") Long wardenId) throws RecordNotFoundException
	{
	   return service.deleteWarden(wardenId);
	   
	}

}
