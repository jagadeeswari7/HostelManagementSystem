package com.capgemini.hsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Application;
import com.capgemini.hsm.service.ApplicationService;


@RestController
@RequestMapping(path="application")
public class ApplicationController {
	@Autowired
	ApplicationService service;

	@PostMapping
	public ResponseEntity<Application> addApplication(@RequestBody Application entity) throws DuplicateRecordException {
		Application result = service.add(entity);
		ResponseEntity<Application> response;
		if(result!=null) {
			response = new ResponseEntity<Application>(result,HttpStatus.CREATED);
		}else {
			response = new ResponseEntity<Application>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}  
	
	@GetMapping("/name/{applicationName}")
	private ResponseEntity<List<Application>> getApplicationsByName(@PathVariable("applicationName") String name) throws RecordNotFoundException {
		List<Application> applicationList=service.findApplicationByName(name);
		if(applicationList.isEmpty()) {
			return new ResponseEntity<List<Application>>(HttpStatus.NOT_FOUND) ;
		}
		else {
			return new ResponseEntity<List<Application>>(applicationList,HttpStatus.OK) ;
		}
	}
	
	@GetMapping("/id/{applicationId}")  
	private ResponseEntity<Application> getUserByID(@PathVariable("applicationId") long applicationId) throws RecordNotFoundException 
	{ 
		Application application= service.findApplicationByPk(applicationId);
		if(application!=null) {
			return new ResponseEntity<Application>(application,HttpStatus.OK);
		}
		return new ResponseEntity<Application>(HttpStatus.NOT_FOUND);
	}

	@PutMapping("/id/{ApplicationId}")  
	public ResponseEntity<Application> update(@PathVariable("ApplicationId") long id) throws RecordNotFoundException{   
	{ 
		Application sample =service.update(id,"ABC");
		  if (sample != null) 
			  return new ResponseEntity<Application>(sample,HttpStatus.OK);
		  
		  return new ResponseEntity<Application>(HttpStatus.NOT_FOUND);
		}
	}
	
	
	@DeleteMapping("/id/{ApplicationId}")  
	private ResponseEntity<String> deleteApplicationByID(@PathVariable("ApplicationId") long id)  throws RecordNotFoundException  
	{  
			if(service.delete(id)) 
				return new ResponseEntity<String>("Application is deleted",HttpStatus.OK);
			return new ResponseEntity<String>("Application not found",HttpStatus.NOT_FOUND);
		
	}  
	@GetMapping("/getAll")
	private ResponseEntity<List<Application>> getDetailsOfAllApplications() throws RecordNotFoundException  
	{  
		List<Application> applications=service.search();
		if(applications.isEmpty()) {
			return new ResponseEntity<List<Application>>(HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
		else {
			return new ResponseEntity<List<Application>>(applications,HttpStatus.OK) ;
		}
	}  
}
