package com.capgemini.hsm.globalExceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.capgemini.hsm.exception.ApplicationException;
import com.capgemini.hsm.exception.DatabaseException;
import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(RecordNotFoundException.class)
	public ResponseEntity<ErrorMessage> exceptionHandler(RecordNotFoundException e){
		  ErrorMessage error = new ErrorMessage(new Date(),HttpStatus.NOT_FOUND.getReasonPhrase(),e.getMessage());
		  return new ResponseEntity<ErrorMessage>(error,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = DuplicateRecordException.class)
	public ResponseEntity<ErrorMessage> handleException(DuplicateRecordException e){
		ErrorMessage error = new ErrorMessage(new Date(),HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),e.getMessage());
		return new ResponseEntity<ErrorMessage>(error,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(value = DatabaseException.class)
	public ResponseEntity<ErrorMessage> handleException(DatabaseException e){
		ErrorMessage error = new ErrorMessage(new Date(),HttpStatus.NOT_MODIFIED.getReasonPhrase(),e.getMessage());
		return new ResponseEntity<ErrorMessage>(error,HttpStatus.NOT_MODIFIED);
	}
	
	@ExceptionHandler(value = ApplicationException.class)
	public ResponseEntity<ErrorMessage> handleException(ApplicationException e){
		ErrorMessage error = new ErrorMessage(new Date(),HttpStatus.NOT_ACCEPTABLE.getReasonPhrase(),e.getMessage());
		return new ResponseEntity<ErrorMessage>(error,HttpStatus.NOT_ACCEPTABLE);
	}
}
