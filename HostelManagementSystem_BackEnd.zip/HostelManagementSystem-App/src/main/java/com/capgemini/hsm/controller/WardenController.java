package com.capgemini.hsm.controller;
/** This is a Controller class for User module 
 * 
 * @author Bhavana's
 *
 */
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Warden;
import com.capgemini.hsm.service.WardenService;

@RestController
@RequestMapping(path="warden")// Map a specific request path or pattern onto a controller
@Controller
@CrossOrigin
public class WardenController {
	
	@Autowired
	private WardenService service;// To establish a relationship with Warden service
	
	
	
	
	/** This method adds Warden record in the database
	 *
	 * @param Warden
	 * @return Warden object
	 */
	
	@PostMapping("/")             
	public ResponseEntity<Warden> addWarden(@Valid @RequestBody Warden entity) throws DuplicateRecordException {
		Warden result = service.addWarden(entity);
		ResponseEntity<Warden> response;
		if(result!=null) {
			response = new ResponseEntity<Warden>(result,HttpStatus.CREATED);
		}else {
			response = new ResponseEntity<Warden>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	
	/** This method updates Warden data in the database
    *
    * @param  WardenId
    * @param  Warden
    * @return Warden object
    * @throws RecordNotFoundException 
    */
	
	
	@PutMapping("{wardenId}") 
	public ResponseEntity<?> updateWarden(@RequestBody Warden warden, @PathVariable("wardenId") long id) throws RecordNotFoundException {
		service.updateWarden(warden, id);
	
		return ResponseEntity.ok("Warden has been updated successfully");
	}
	/** This method is to view Warden by Id
	 *
	 * @param  WardenId
	 * @return Warden object
	 * @throws RecordNotFoundException 
	 */
	
	@GetMapping("/Id/{wardenId}")
    public Warden getDetailsById(@PathVariable("wardenId") long wardenId) throws RecordNotFoundException {
		
		return service.findByPk(wardenId);
	}
	/** This method is to view Warden by Name
	 *
	 * @param  WardenId
	 * @return Warden object
	 * @throws RecordNotFoundException 
	 */
	
	@GetMapping("/Name/{wardenName}")
	 public List<Warden> getDetailsByName(@PathVariable("wardenName") String wardenName) throws RecordNotFoundException {
	
		return service.findByWardenName(wardenName);
	}
	/** This method deletes Warden record in the database
	 *
	 * @param  WardenId
	 * @throws RecordNotFoundException 
	 */
	
	@DeleteMapping("{wardenId}")
	public boolean DeleteDetails(@PathVariable("wardenId") Long wardenId) throws RecordNotFoundException{
	
	   return service.deleteWarden(wardenId);
	   
	}
	
	/** This method returns the list of Warden records in the database
	 *
	 * @return list of all Wardens
	 */
	
	@GetMapping("/Search")
	public ResponseEntity<List<Warden>> searchDetails()
	{
		List<Warden> wardenList=service.searchAllWardens();
		if(wardenList.isEmpty())
			return new ResponseEntity<List<Warden>>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<List<Warden>>(wardenList,HttpStatus.OK);
		}
    }


