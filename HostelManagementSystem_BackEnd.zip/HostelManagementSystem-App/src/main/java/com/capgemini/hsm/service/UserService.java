package com.capgemini.hsm.service;

import java.util.List;

import com.capgemini.hsm.exception.ApplicationException;
import com.capgemini.hsm.exception.DatabaseException;
import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.User;
import com.capgemini.hsm.model.UserCredentials;

public interface UserService {

	
	public User update(User entity,long userId) throws RecordNotFoundException;
	public boolean delete(long userId) throws RecordNotFoundException;
	public User findByLogin(String login) throws RecordNotFoundException;
	public User findByPk(long userId) throws RecordNotFoundException;
	public List<User> searchAllUsers();
	
	public User authenticate(UserCredentials userCredentials) throws ApplicationException, RecordNotFoundException;
	public boolean changePassword(long id, String mail, String newPassword) throws ApplicationException, RecordNotFoundException;
	
    public User createUser(User entity) throws DuplicateRecordException, ApplicationException, DatabaseException;
    public String forgetPassword(String login) throws RecordNotFoundException, DatabaseException;
	
	
}
