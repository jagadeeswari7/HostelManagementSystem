package com.capgemini.hsm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Visitors")
public class Visitor implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "VISITOR_ID")
	private long visitorId;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "CONTACT_NO")
	private String contactNo;
	
	@Column(name = "STUDENT_NAME")
	private String studentName;
	
	@Column(name = "ADDRESS")
	private String address;
	
	@Column(name = "RELATION")
	private String relation;
	
	@Column(name = "PURPOSE")
	private String purpose;
	
	

	public Visitor(long visitorId, String name, String contactNo, String studentName, String address, String relation,
			String purpose) {
		super();
		this.visitorId = visitorId;
		this.name = name;
		this.contactNo = contactNo;
		this.studentName = studentName;
		this.address = address;
		this.relation = relation;
		this.purpose = purpose;
	}
	
	public Visitor() {
		
	}

	public long getVisitorId() {
		return visitorId;
	}
	public void setVisitorId(long visitorId) {
		this.visitorId = visitorId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	
	
	
}
