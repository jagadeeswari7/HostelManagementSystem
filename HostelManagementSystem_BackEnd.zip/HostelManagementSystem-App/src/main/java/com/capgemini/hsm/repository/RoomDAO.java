package com.capgemini.hsm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.hsm.model.Room;


public interface RoomDAO extends JpaRepository<Room, Long>{

	

	public Room findByRoomId(long roomId);	
}
