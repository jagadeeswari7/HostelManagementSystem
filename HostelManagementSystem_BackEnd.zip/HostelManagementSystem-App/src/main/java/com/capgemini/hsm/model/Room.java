package com.capgemini.hsm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "rooms")
public class Room implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ROOM_ID")
	private long roomId;
	
	@Column(name = "ROOM_NO")
	private long number;
	
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	
	
	
		
	public Room(long roomId, long number,  String description) {
		super();
		this.roomId = roomId;
		this.number = number;

		this.description = description;
	}

	public Room() {
		
	}

	public long getRoomId() {
		return roomId;
	}
	public void setRoomId(long roomId) {
		this.roomId = roomId;
	}
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	

	public long getNumber() {
		return number;
	}

	public void setNumber(long number) {
		this.number = number;
	}
	
	
}