package com.capgemini.hsm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="ADMIN")
public class Admin implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="A_NAME")
	String name;
	
	@Column(name="A_PASSWORD")
	String password;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
