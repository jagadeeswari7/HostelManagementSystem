package com.capgemini.hsm.model;

import javax.validation.constraints.NotBlank;

import org.springframework.stereotype.Component;

import com.capgemini.hsm.validations.ValidEmail;
import com.capgemini.hsm.validations.ValidPassword;

@Component
public class UserCredentials {
	
	
	@NotBlank(message = "Login must not be blank")
	@ValidEmail
	private String login;
	
	
	@NotBlank(message = "Please provide password")
	@ValidPassword
	private String password;

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
