package com.capgemini.hsm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
		
@Entity
@Table(name="Allotments")
public class Allotment implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ALLOTMENT_ID")

	private long allotId;
	
	@Column(name = "HOSTEL_ID")
	private long hostelId;
	
	@Column(name = "HOSTEL_NAME") 
	private String hostelName;
	
	@Column(name = "USER_ID")
	private long userId;
	
	@Column(name = "NAME")
	private String name;
	
	
	
	public Allotment(long allotId, long hostelId, String hostelName, long userId, String name) {
		super();
		this.allotId = allotId;
		this.hostelId = hostelId;
		this.hostelName = hostelName;
		this.userId = userId;
		this.name = name;
		
	}
	public Allotment() {
		super();
	}
	public long getAllotId() {
		return allotId;
	}
	public void setAllotId(long allotId) {
		this.allotId = allotId;
	}
	public long getHostelId() {
		return hostelId;
	}
	public void setHostelId(long hostelId) {
		this.hostelId = hostelId;
	}
	public String getHostelName() {
		return hostelName;
	}
	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	

	@Override
	public String toString() {
		return "Allotment [allotId=" + allotId + ", hostelId=" + hostelId + ", hostelName=" + hostelName + ", userId="
				+ userId + ", name=" + name + "]";
	}
	
	
}
