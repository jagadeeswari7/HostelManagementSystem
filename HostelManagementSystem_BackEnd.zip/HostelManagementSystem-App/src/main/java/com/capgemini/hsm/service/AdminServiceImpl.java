package com.capgemini.hsm.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.hsm.exception.ApplicationException;
import com.capgemini.hsm.model.Admin;
import com.capgemini.hsm.repository.AdminDAO;

@Transactional
@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	public AdminDAO repository;
	
	private static final Logger logger = LogManager.getLogger(AdminServiceImpl.class);

	public  AdminDAO getDao() {
		return repository;
	}

	public void setDao( AdminDAO repository) {
		this.repository = repository;
	}
	
	@Override
	public Admin authenticate(Admin admin) throws ApplicationException {
		Admin userInDb = repository.findByName(admin.getName());
		if (userInDb != null) {
			logger.info("Details exits. Getting the details with user Name : " +admin.getName());
			if (admin.getPassword().equals(userInDb.getPassword())) {
				logger.info("Entered password is correct");
				return userInDb;
			} else {
				logger.error("Entered password is incorrect. Throwing exception");
				throw new ApplicationException("Invalid Password. Enter correct Paassword");
			}
		} else {
			logger.error("No user found with user Name  : " +admin.getName() + " Thrrowing Exception");
			throw new ApplicationException("No such user with this username : " + admin.getName()
					+ " Found. Register or use correct username");
		}

	}
	
	@Override
	public Admin signOut(Admin admin) {
		return null;
	}


}