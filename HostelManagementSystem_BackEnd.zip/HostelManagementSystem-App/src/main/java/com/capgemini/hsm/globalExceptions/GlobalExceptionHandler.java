package com.capgemini.hsm.globalExceptions;

import java.util.Date;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.capgemini.hsm.exception.ApplicationException;
import com.capgemini.hsm.exception.DatabaseException;
import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;

@ControllerAdvice
public class GlobalExceptionHandler {
	/** Exception handler for showing Record Not Found Exception
	 * 
	 * @param ex
	 * @return
	 */
	@ExceptionHandler(RecordNotFoundException.class)
	public ResponseEntity<?> exceptionHandler(RecordNotFoundException ex){
		  ErrorDetails error = new ErrorDetails(new Date(),HttpStatus.NOT_FOUND.getReasonPhrase(),ex.getMessage());
		  return new ResponseEntity<>(error,HttpStatus.NOT_FOUND);
	}
	
	/** Exception handler for showing Duplicate Record Exception
	 * 
	 * @param ex
	 * @return
	 */
	@ExceptionHandler(value = DuplicateRecordException.class)
	public ResponseEntity<?> handleException(DuplicateRecordException ex){
		ErrorDetails error = new ErrorDetails(new Date(),HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),ex.getMessage());
		return new ResponseEntity<>(error,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	/** Exception handler for showing Database Exception
	 * 
	 * @param ex
	 * @return
	 */
	@ExceptionHandler(value = DatabaseException.class)
	public ResponseEntity<?> handleException(DatabaseException ex){
		ErrorDetails error = new ErrorDetails(new Date(),HttpStatus.NOT_MODIFIED.getReasonPhrase(),ex.getMessage());
		return new ResponseEntity<>(error,HttpStatus.NOT_MODIFIED);
	}
	
	/** Exception handler for showing Application Exception
	 * 
	 * @param ex
	 * @return
	 */
	@ExceptionHandler(value = ApplicationException.class)
	public ResponseEntity<?> handleException(ApplicationException e){
		ErrorDetails error = new ErrorDetails(new Date(),HttpStatus.NOT_ACCEPTABLE.getReasonPhrase(),e.getMessage());
		return new ResponseEntity<>(error,HttpStatus.NOT_ACCEPTABLE);
	}
	
	 /** Exception handler for showing validation error messages
	 * 
	 * @param ex
	 * @return
	 */
	  @ExceptionHandler(MethodArgumentNotValidException.class)
	  public ResponseEntity<Object>methodArgumentNotValidException(MethodArgumentNotValidException ex) {
	     ErrorDetails errorDetails = new ErrorDetails(new Date(), "Validation error",ex.getBindingResult().getFieldError().getDefaultMessage());
	     return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	  }
	  
	  /** Exception handler for showing validation error messages
	  * 
	  * @param ex
	  * @return
	  */
	  @ExceptionHandler(ConstraintViolationException.class) 
	  public ResponseEntity<Object>  constraintViolationException(ConstraintViolationException ex) { 
		  StringBuilder message = new StringBuilder(); 
		  Set<ConstraintViolation<?>> violations = ex.getConstraintViolations();
	      for (ConstraintViolation<?> violation :violations) { 
	        	message.append(violation.getMessage().concat(", ")); 
	         } 
	       ErrorDetails errorDetails = new ErrorDetails(new Date(), "Validation Error", message.toString()); 
	       return new ResponseEntity<>(errorDetails,HttpStatus.BAD_REQUEST); }
	 
}
