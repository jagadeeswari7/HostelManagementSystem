package com.capgemini.hsm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Hostels")
public class Hostel implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "HOSTEL_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long hostelId;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "TYPE")
	private String type;
	
	@Column(name = "CONTACT")
	private String contact;
	
	@Column(name = "ADDRESS")
	private String address;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "FEE")
	private String fee;

	public Hostel(long hostelId, String name, String type, String contact, String address, String description,
			String fee) {
		super();
		this.hostelId = hostelId;
		this.name = name;
		this.type = type;
		this.contact = contact;
		this.address = address;
		this.description = description;
		this.fee = fee;
	}

	public Hostel() {
       super();
	}
	
	public long getHostelId() {
		return hostelId;
	}
	public void setHostelId(long hostelId) {
		this.hostelId = hostelId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFee() {
		return fee;
	}
	public void setFee(String fee) {
		this.fee = fee;
	}

	
	@Override
	public String toString() {
		return "Hostel [hostelId=" + hostelId + ", name=" + name + ", type=" + type + ", contact=" + contact
				+ ", address=" + address + ", description=" + description + ", fee=" + fee + "]";
	}
	
}
