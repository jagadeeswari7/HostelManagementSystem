package com.capgemini.hsm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.hsm.model.Admin;

public interface AdminDAO extends JpaRepository<Admin, String>{

	public Admin findByName(String name);

}
