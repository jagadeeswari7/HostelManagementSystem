package com.capgemini.hsm.controller;


import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.hsm.model.Allotment;
import com.capgemini.hsm.model.Application;
import com.capgemini.hsm.model.Fee;
import com.capgemini.hsm.model.Hostel;
import com.capgemini.hsm.model.Room;
import com.capgemini.hsm.model.User;
import com.capgemini.hsm.model.Visitor;
import com.capgemini.hsm.model.Warden;




@Component
public class GenerateId {

	
	Random random;

	public int generateID(Object obj) {
		if (obj instanceof User) {
			return random.nextInt(1000) + 1000;
		} else if (obj instanceof Allotment) {
			return (random.nextInt(100000) + 100000);
		} else if (obj instanceof Application) {
			return random.nextInt(1000) + 2000;
		} else if (obj instanceof Fee) {
			return random.nextInt(1000) + 4000;
		} else if (obj instanceof Hostel) {
			return random.nextInt(10000) + 50000;
		} else if (obj instanceof Room) {
			return random.nextInt(1000) + 3000;
		} else if (obj instanceof Visitor) {
			return random.nextInt(100000) + 600000;
		} else if (obj instanceof Warden) {
			return random.nextInt(10000) + 70000;
		}
		return 0;
	}

}