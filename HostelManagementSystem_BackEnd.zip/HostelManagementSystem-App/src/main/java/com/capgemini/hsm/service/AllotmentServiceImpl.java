package com.capgemini.hsm.service;
/** The AllotmentServiceImpl class provides access to repository methods to CRUD operations User details 
 * 
 * 
 * @author Maneesha's
 *
 */
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Allotment;
import com.capgemini.hsm.repository.AllotmentDAO;

@Transactional
@Service
public class AllotmentServiceImpl implements AllotmentService{

	@Autowired
	private AllotmentDAO dao;
	private static final Logger logger = LogManager.getLogger(AllotmentServiceImpl.class);
	

	public AllotmentDAO getDao() {
		return dao;
	}
	public void setDao(AllotmentDAO dao) {
		this.dao = dao;
	}

	@Override
	public Allotment add(Allotment entity) throws DuplicateRecordException{
		logger.info(" Start add allotment method in the service!");
		if(dao.existsById(entity.getAllotId())) {
			logger.error("The record already exists");
			throw new DuplicateRecordException("Duplicate User Found for this allotment.");
		}
		dao.save(entity);
		logger.info("Allotment Record Added Successfully...!");
		return entity;   
	}
	
	@Override
	public boolean delete(long allotId) throws RecordNotFoundException{
		logger.info(" Start delete allotment method in the service!");
		if(dao.existsById(allotId)) {
			dao.deleteById(allotId);
			logger.info("Allotment Record Removed Successfully...!");
			return true;
		}else {
			logger.error("No Allotment is identified with this id to delete");
			throw new RecordNotFoundException("Allotment not found for this id"+allotId);
		}
	}

	@Override
	public List<Allotment> findAllotmentByName(String name) throws RecordNotFoundException {
		logger.info(" Start reading allotment by Name method in the service!");
		List<Allotment> nameList= dao.findByName(name);
		if(!nameList.isEmpty()) {
			logger.info(" Retrieved Allotment by name successfully...!");	
			return nameList;
		}
		logger.error("No Allotment is identified with this name");
		throw new RecordNotFoundException("Allotment not found for this name"+name);
	}
	

	@Override
	public Allotment findByPk(long allotId) throws RecordNotFoundException {
		logger.info(" Start reading allotment by allotId method in the service!");
		Allotment allotedUser = dao.findByAllotId(allotId);
		if(allotedUser!=null) {
			logger.info(" Retrieved Allotment by id successfully...!");
			return allotedUser;
		}
		logger.error("No Allotment is identified with this id");
		   throw new RecordNotFoundException("Allotment not found for this id"+allotId);
	}
	
	@Override
	public List<Allotment> searchAllAllotedUsers() {
		logger.info("Start reading all allotment records method in the service!");
		List<Allotment> list = dao.findAll();
		logger.info(" Retrieved all the allotments successfully...!");
		return list;
	
	}
	@Override
	public Allotment update(long allotId, Allotment entity) throws RecordNotFoundException {
		logger.info(" Start update allotment method in the service!");
		Allotment allotedUser = dao.findByAllotId(allotId);
		if(allotedUser!=null) {
		allotedUser.setHostelId(entity.getHostelId());	
		allotedUser.setHostelName(entity.getHostelName());
		allotedUser.setUserId(entity.getUserId());
		allotedUser.setName(entity.getName());
		dao.save(allotedUser);
		logger.info("Allotment Data Updated Successfully...!");
		return allotedUser;
		}
		logger.error("The record already updated");
		 throw new RecordNotFoundException("Allotment not found for this id "+allotId);
	}

}