package com.capgemini.hsm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import com.capgemini.hsm.validations.ValidEmail;
import com.capgemini.hsm.validations.ValidPassword;

@Entity
@Table(name="Users")
public class User implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
    @Column(name="USER_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long userId;
    
    @Column(name="FIRST_NAME")
	private String firstName;
    
    @Column(name="LAST_NAME")
	private String lastName;
    
	@Column(name = "LOGIN", unique = true,nullable=false)
	@NotBlank(message = "Login must not be blank")
	@ValidEmail
	private String login;
	
	@Column(name="PASSWORD")
	@NotBlank(message = "Please provide password")
	@ValidPassword
	private String password;
	
	@Column(name="C_PASSWORD")
	@NotBlank(message = "Please provide password")
	@ValidPassword
	private String confirmPassword;
	
	@Column(name="DOB")
	private String dob;
	
	@Column(name="MOBILE_NUMBER")
	private String mobileNo;
	
	@Column(name="GENDER")
	private String gender;
	
	@Column(name="IMAGE")
	private String image;
	
	@Column(name="ROLE_NAME")
	private String roleName;
	
	@Column(name="U_ADDRESS")
	private String description;
	
	public User() {
		super();
	}

	public User(long userId, String firstName, String lastName,
			String login, String password, String confirmPassword, String dob,
			String mobileNo, String gender, String image,String roleName,String description) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.login = login;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.dob = dob;
		this.mobileNo = mobileNo;
		this.gender = gender;
		this.image = image;
		this.roleName = roleName;
		this.description = description;
	}
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
	
	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
