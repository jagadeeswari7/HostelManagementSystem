package com.capgemini.hsm.service;

import com.capgemini.hsm.exception.ApplicationException;
import com.capgemini.hsm.model.Admin;

public interface AdminService {

	public Admin authenticate(Admin admin) throws ApplicationException;

	public Admin signOut(Admin admin);

	
}
