package com.capgemini.hsm.service;
/** The RoomServiceImpl class provides access to repository methods to CRUD operations User details 
 * 
 * 
 * @author Deepthi's
 *
 */
import java.util.List;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Room;
import com.capgemini.hsm.repository.RoomDAO;

@Transactional
@Service
public class RoomServiceImpl implements RoomService {
    @Autowired
	private RoomDAO dao;
    
    private static final Logger logger = LogManager.getLogger(RoomServiceImpl.class);

    public RoomDAO getDao() {
		return dao;
	}

	public void setDao(RoomDAO dao) {
		this.dao = dao;
	}

	@Override
	public Room add(Room entity) throws DuplicateRecordException {
		logger.info(" Start add room user method in the service!");
		if(dao.existsById(entity.getRoomId())) {
			logger.error("Room user already exists");
			throw new DuplicateRecordException("Duplicate Room User Found");
		}
		dao.save(entity);
		logger.info(" Room User Record Added Successfully...!");
		return entity;
	}

	@Override
	public Room update(Room entity,long roomId) throws RecordNotFoundException{
		logger.info(" Start update room user method in the service!");
		Room currentRoom = dao.findByRoomId(roomId);
        if (currentRoom!=null) {
        	dao.save(currentRoom);
        	logger.info("Room User Data Updated Successfully...!");
        	return currentRoom;
        }
        else {
        	logger.error("Room user not present");
            throw new RecordNotFoundException("Room user not found for this id: "+roomId);
        }
	}

	@Override
	public boolean delete(long roomId) throws RecordNotFoundException {
		logger.info(" Start delete room user method in the service!");
		if(dao.existsById(roomId)) {
			dao.deleteById(roomId);
			logger.info("Room User Record Removed Successfully...!");
			return true;
		}else {
			logger.error("Room user not present");
			throw new RecordNotFoundException("Room user not found for this id : "+roomId);
		}
	}

	
	@Override
	public Room findByPk(long roomId) throws RecordNotFoundException{
		logger.info(" Start reading room user by roomId method in the service!");
		Room rooms=dao.findByRoomId(roomId);
		if(rooms!=null)
		{
			logger.info(" Retrieved Room User by id successfully...!");
			return rooms;
		}
		else {
			logger.error("Room user not present");
		   throw new RecordNotFoundException("Record Not Found for this id :"+roomId);
		}
	}

	@Override
	public List<Room> search(){
		logger.info("Start reading all room user records method in the service!");
		List<Room> roomList = dao.findAll();
		logger.info(" Retrieved all the room users successfully...!");
		return roomList;		
	}

}