package com.capgemini.hsm.service;

import java.util.List;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Room;

public interface RoomService {

	public Room add(Room entity) throws DuplicateRecordException;
	public Room update(Room entity, long id) throws RecordNotFoundException;
	public boolean delete(long id) throws RecordNotFoundException;

	public Room findByPk(long id) throws RecordNotFoundException;
	public List<Room> search();
	
	
}
