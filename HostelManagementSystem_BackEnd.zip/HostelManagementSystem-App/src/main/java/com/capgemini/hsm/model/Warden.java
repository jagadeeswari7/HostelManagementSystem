package com.capgemini.hsm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Wardens")
public class Warden implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "WARDEN_ID")
	private long wardenId;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "LOGIN",unique = true)
	private String login;
	
	

	public Warden(long wardenId, String name, String login) {
		super();
		this.wardenId = wardenId;
		this.name = name;
		this.login = login;
	}
	
	public Warden() {

	}
	public long getWardenId() {
		return wardenId;
	}
	public void setWardenId(long wardenId) {
		this.wardenId = wardenId;
	}	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
}
