package com.capgemini.hsm.service;
/** The HostelServiceImpl class provides access to repository methods to CRUD operations User details 
 * 
 * 
 * @author Maneesha's
 *
 */
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Hostel;
import com.capgemini.hsm.repository.HostelDAO;

@Transactional
@Service
public class HostelServiceImpl implements HostelService{

	@Autowired
	private HostelDAO dao;
	
	private static final Logger logger = LogManager.getLogger(HostelServiceImpl.class);
	
	public HostelDAO getDao() {
		return dao;
	}

	public void setDao(HostelDAO dao) {
		this.dao = dao;
	}

	@Override
	public Hostel add(Hostel entity) throws DuplicateRecordException{
		logger.info(" Start add hostel method in the service!");
		if(dao.existsById(entity.getHostelId())) {
			logger.error("The record already exists");
			throw new DuplicateRecordException("Duplicate Record Found");
		}
		dao.save(entity);
		logger.info("Hostel Record Added Successfully...!");
		return entity;
	}
	

	@Override
	public Hostel update(long hostelId, Hostel entity) throws RecordNotFoundException{
		logger.info(" Start update hostel method in the service!");
		if(dao.existsById(hostelId)) {
			Hostel currentHostel = dao.save(entity);
			logger.info("Hostel Data Updated Successfully...!");
			return currentHostel;
			
		}
		logger.error("The record already updated");
            throw new RecordNotFoundException("Hostel not found for this id"+hostelId);
        }
		
	
	@Override
	public boolean delete(long Id) throws RecordNotFoundException{
		logger.info(" Start delete hostel method in the service!");
		if(dao.existsById(Id)) {
			dao.deleteById(Id);
			logger.info("Hostel Record Removed Successfully...!");
			return true;
			}
		logger.error("No Hostel is identified with this id to delete");
			throw new RecordNotFoundException("Hostel record not found for this id");
		}
	

	
	@Override
	public Hostel findByPk(long id) throws RecordNotFoundException {
	
		logger.info(" Start reading hostel by hostelId method in the service!");
		Hostel hostel = dao.findByHostelId(id);
		if(hostel!=null) {
			logger.info(" Retrieved Hostel by id successfully...!");
			return hostel;
		}
		logger.error("No Hostel is identified with this id");
		   throw new RecordNotFoundException("Hostel not found for this id");
	}
		
	@Override
	public List<Hostel> search() {
		logger.info("Start reading all hostel records method in the service!");
			List<Hostel> list = dao.findAll();
			logger.info(" Retrieved all the hostels successfully...!");
			return list;
		}

	@Override
	public List<Hostel> findByName(String name) throws RecordNotFoundException {
		logger.info(" Start reading hostel by hostelName method in the service!");
		List<Hostel> listByName= dao.findByName(name);
		if(!listByName.isEmpty())
		{
			logger.info(" Retrieved Hostel by name successfully...!");
			return listByName;
		}
		logger.error("No Hostel is identified with this name");
		throw new RecordNotFoundException("Record Not Found Exception");
	}
}

