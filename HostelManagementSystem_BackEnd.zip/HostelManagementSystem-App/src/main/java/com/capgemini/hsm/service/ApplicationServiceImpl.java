package com.capgemini.hsm.service;
/** The ApplicationServiceImpl class provides access to repository methods to CRUD operations User details 
 * 
 * 
 * @author Tejaswi's
 *
 */
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Application;
import com.capgemini.hsm.repository.ApplicationDAO;

@Transactional
@Service
public class ApplicationServiceImpl implements ApplicationService {
	@Autowired
	public ApplicationDAO dao;
	private static final Logger logger = LogManager.getLogger(ApplicationServiceImpl.class);

	public  ApplicationDAO getDao() {
		return dao;
	}

	public void setDao( ApplicationDAO dao) {
		this.dao = dao;
	}
	

	@Override
	
	public Application add(Application entity) throws DuplicateRecordException {
		logger.info(" Start add Application method in the service!");
		if(dao.existsById(entity.getApplicationId())) {
			logger.error("Application already present");
			throw new DuplicateRecordException("Duplicate Application Found");
		}
		dao.save(entity);
		logger.info("Application Record Added Successfully...!");
		return entity;
	}

		@Override
		public Application update(Application entity,long applicationId) throws RecordNotFoundException{
			logger.info(" Start update application method in the service!");
			
			Application application = dao.findByApplicationId(entity.getApplicationId());
			 if(application!=null) {
		        	application.setName(entity.getName());
		        	application.setHostelName(entity.getHostelName());
		        	application.setQualification(entity.getQualification());
		        	application.setAddress(entity.getAddress());
		        	application.setDescription(entity.getDescription());
		        	 dao.save(application);
		        	 logger.info("Application Data Updated Successfully...!");
		        	return application;
		        }
			 else {
				 logger.error("No Application is identified with this id to update ");
		         throw new RecordNotFoundException("Application not found for this id "+applicationId);	
			 }
		}

	@Override
	public boolean delete(long applicationId) throws RecordNotFoundException{
		logger.info(" Start delete application method in the service!");
		if(dao.existsById(applicationId)) {
			dao.deleteById(applicationId);
			logger.info("Application Record Removed Successfully...!");
			return true;
		}
		 logger.error("No Application is identified with this id to delete ");
		throw new RecordNotFoundException("Record Not Found for id :"+applicationId);
	}

	@Override
	public List<Application> findApplicationByName(String name) throws RecordNotFoundException {
		logger.info(" Start reading application by  name in the service!");
		List<Application> application = dao.findByName(name);
		if(!application.isEmpty()) {
			logger.info(" Retrieved application by name successfully...!");
			return application;
		}
		 logger.error("No Application is identified with this name ");
		throw new RecordNotFoundException("Record Not Found");
	}

	@Override
	public Application findApplicationByPk(long applicationId) throws RecordNotFoundException {
		logger.info(" Start reading application by applicationId method in the service!");
		Application application=dao.findByApplicationId(applicationId);
		if(application!=null)
		{
			logger.info(" Retrieved application by id successfully...!");
			return application;
		}
		 logger.error("No Application is identified with this id  ");
		throw new RecordNotFoundException("Record Not Found");
	}

	
	@Override
	public List<Application> search() {
		List<Application> list = dao.findAll();
		return list;
	}

	
}