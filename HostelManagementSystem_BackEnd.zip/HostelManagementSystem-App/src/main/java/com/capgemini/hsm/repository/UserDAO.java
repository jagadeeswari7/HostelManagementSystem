package com.capgemini.hsm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.hsm.model.User;

public interface UserDAO extends JpaRepository<User, Long>{

	
	public User findByLogin(String login);

	public User findByUserId(long userId);
}
