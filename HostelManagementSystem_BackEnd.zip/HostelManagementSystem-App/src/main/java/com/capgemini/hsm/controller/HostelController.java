package com.capgemini.hsm.controller;
/** This is a Controller class for Hostel module 
 * 
 * @author Maneesha's
 *
 */
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hsm.exception.DuplicateRecordException;
import com.capgemini.hsm.exception.RecordNotFoundException;
import com.capgemini.hsm.model.Hostel;
import com.capgemini.hsm.service.HostelService;

@RestController
@RequestMapping(path="Hostel")  // Map a specific request path or pattern onto a controller
@CrossOrigin
public class HostelController {
	
	@Autowired
	HostelService service; // To establish a relationship with Fee service

	/** This method adds Hostel record in the database
	 *
	 * @param  Hostel
	 * @return Hostel object
	 */
	@PostMapping
	public ResponseEntity<Hostel> addHostel(@Valid @RequestBody Hostel entity) throws DuplicateRecordException {
		Hostel result = service.add(entity);
		if(result!=null) {
			return new ResponseEntity<Hostel>(result,HttpStatus.CREATED);
		}else {
			throw new DuplicateRecordException("Duplicate User");
		}
	}  
	
	/** This method updates Hostel Record Data in the database
    *
    * @param  HostelId
    * @param  Hostel
    * @return Hostel User object
    * @throws RecordNotFoundException 
    */
	@PutMapping("/Update/{HostelId}")  
	public ResponseEntity<Hostel> updateHostelDetails(@PathVariable("HostelId") long id, @RequestBody Hostel hostel) throws RecordNotFoundException{   
	{ 
		Hostel sample =service.update(id, hostel);
		  if (sample != null) 
			  return new ResponseEntity<Hostel>(sample,HttpStatus.OK);
		  
		  return new ResponseEntity<Hostel>(HttpStatus.NOT_FOUND);
		}
	}
		
	/** This method is to view Hostels by Name
	 *
	 * @param  HostelName
	 * @return Hostel object
	 * @throws RecordNotFoundException 
	 */
	
	@GetMapping("/Name/{HostelName}")
	private ResponseEntity<List<Hostel>> gethostelByName(@PathVariable("HostelName") String name) throws RecordNotFoundException {
		List<Hostel> list=service.findByName(name);
		if(list.isEmpty()) {
			return new ResponseEntity<List<Hostel>>(HttpStatus.NOT_FOUND) ;
		}
		else {
			return new ResponseEntity<List<Hostel>>(list,HttpStatus.OK) ;
		}
	}
	
	/** This method is to view Hostel by ID
    *
    * @param  HostelId
    * @return Hostel object
    * @throws RecordNotFoundException 
    */
	@GetMapping("/Id/{HostelId}")  
	private ResponseEntity<Hostel> getstudentByID(@PathVariable("HostelId") long hostelId)   throws RecordNotFoundException 
	{ 
		Hostel hostel= service.findByPk(hostelId);
		if(hostel!=null) {
			return new ResponseEntity<Hostel>(hostel,HttpStatus.OK);
		}
		return new ResponseEntity<Hostel>(HttpStatus.NOT_FOUND);
	}
	
	/** This method deletes Hostel record in the database
	 *
	 * @param  HostelId
	 * @throws RecordNotFoundException 
	 */
	@DeleteMapping("{HostelId}")  
	private ResponseEntity<String> deleteHostelByID(@PathVariable("HostelId") long id)  throws RecordNotFoundException  
	{  
			if(service.delete(id)) 
				return new ResponseEntity<String>("Application is deleted",HttpStatus.OK);
			return new ResponseEntity<String>("Hostel not found",HttpStatus.NOT_FOUND);
		
	}  
	
	/** This method returns the list of all Hostel records in the database
	 *
	 * @return list of all Hostels
	 */
	@GetMapping("/getAllHostels")
	private ResponseEntity<List<Hostel>> getDetailsOfAllHostels() throws RecordNotFoundException  
	{  	
		List<Hostel> app=service.search();
		if(app.isEmpty()) {
			return new ResponseEntity<List<Hostel>>(HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
		else {
			return new ResponseEntity<List<Hostel>>(app,HttpStatus.OK) ;
		}
	}  
	
}